import { Canvas } from "@react-three/fiber";
import { Suspense } from "react";
import { OrbitControls } from "@react-three/drei";
import "@fontsource/inter";
import FactoryScene from "./components/game/FactoryScene";
import GameUI from "./components/game/GameUI";

function App() {
  return (
    <div style={{ width: "100vw", height: "100vh", position: "relative", overflow: "hidden" }}>
      <Canvas
        shadows
        camera={{
          position: [0, 12, 16],
          fov: 50,
          near: 0.1,
          far: 100,
        }}
        gl={{
          antialias: true,
          powerPreference: "default",
        }}
      >
        <Suspense fallback={null}>
          <FactoryScene />
        </Suspense>
        <OrbitControls
          makeDefault
          minPolarAngle={0.3}
          maxPolarAngle={Math.PI / 2.2}
          minDistance={8}
          maxDistance={30}
          target={[0, 0, -2]}
        />
      </Canvas>
      <GameUI />
    </div>
  );
}

export default App;
