import { create } from "zustand";
import { subscribeWithSelector } from "zustand/middleware";

export type AgentType = "content" | "code" | "research";
export type ModelTier = "local" | "cloud";

export interface Agent {
  id: string;
  name: string;
  type: AgentType;
  tier: ModelTier;
  speed: number;
  quality: number;
  cost: number;
  progress: number;
  producing: boolean;
  hiredAt: number;
}

export interface Asset {
  id: string;
  type: AgentType;
  quality: number;
  value: number;
  createdAt: number;
}

export interface NewsItem {
  id: string;
  message: string;
  timestamp: number;
  type: "info" | "warning" | "success" | "danger";
}

export interface Upgrade {
  id: string;
  name: string;
  description: string;
  cost: number;
  purchased: boolean;
  effect: string;
  category: "speed" | "quality" | "capacity" | "revenue";
}

interface FactoryState {
  revenue: number;
  totalRevenue: number;
  agents: Agent[];
  assets: Asset[];
  news: NewsItem[];
  riskLevel: number;
  maxAgents: number;
  revenueMultiplier: number;
  speedMultiplier: number;
  qualityMultiplier: number;
  licensingIncome: number;
  clonedAgents: number;
  tickCount: number;
  gameStarted: boolean;
  upgrades: Upgrade[];

  startGame: () => void;
  hireAgent: (type: AgentType, tier: ModelTier) => void;
  fireAgent: (id: string) => void;
  toggleAgentTier: (id: string) => void;
  cloneAgent: (id: string) => void;
  purchaseUpgrade: (id: string) => void;
  tick: (delta: number) => void;
  assetsProduced: number;
}

const AGENT_NAMES = [
  "Atlas", "Nova", "Spark", "Helix", "Prism", "Cipher", "Nexus", "Flux",
  "Quark", "Zenith", "Echo", "Pulse", "Volt", "Apex", "Core", "Drift",
  "Ember", "Ghost", "Ion", "Jade", "Kite", "Lux", "Mist", "Neon",
];

const AGENT_BASE_COST: Record<AgentType, number> = {
  content: 50,
  code: 100,
  research: 150,
};

const ASSET_BASE_VALUE: Record<AgentType, number> = {
  content: 15,
  code: 30,
  research: 50,
};

const AGENT_BASE_SPEED: Record<AgentType, number> = {
  content: 1.2,
  code: 0.8,
  research: 0.5,
};

const NEWS_MESSAGES = {
  hire: [
    "New agent {name} joined the factory!",
    "{name} is ready to produce assets.",
    "Welcome aboard, {name}!",
  ],
  asset: [
    "{name} completed a {type} asset worth ${value}.",
    "Asset produced by {name}: {type} (${value})",
    "{name} delivered quality {type} work!",
  ],
  risk: [
    "Warning: Automation risk is climbing!",
    "Bug reports are increasing. Watch the risk meter!",
    "System instability detected. Consider slowing down.",
    "CRITICAL: Over-automation causing cascading failures!",
  ],
  upgrade: [
    "Upgrade purchased: {name}",
    "Factory improved with {name}!",
  ],
  clone: [
    "Agent {name} has been cloned! Licensing revenue activated.",
    "Clone of {name} generating passive income.",
  ],
};

function pickRandom<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

let nextId = 1;
function genId() {
  return `id_${nextId++}_${Date.now()}`;
}

const DEFAULT_UPGRADES: Upgrade[] = [
  { id: "u1", name: "Better Prompts", description: "All agents produce 25% faster", cost: 200, purchased: false, effect: "speed_content", category: "speed" },
  { id: "u2", name: "Code Linter", description: "All asset quality +30%", cost: 300, purchased: false, effect: "quality_code", category: "quality" },
  { id: "u3", name: "Research Database", description: "All asset values +40%", cost: 500, purchased: false, effect: "revenue_research", category: "revenue" },
  { id: "u4", name: "Server Rack", description: "Max agents +3", cost: 400, purchased: false, effect: "capacity_3", category: "capacity" },
  { id: "u5", name: "Cloud GPU Cluster", description: "All cloud agents 2x speed", cost: 800, purchased: false, effect: "speed_cloud", category: "speed" },
  { id: "u6", name: "Quality Assurance", description: "All asset values +20%", cost: 600, purchased: false, effect: "revenue_all", category: "revenue" },
  { id: "u7", name: "Load Balancer", description: "Risk accumulates 30% slower", cost: 700, purchased: false, effect: "risk_reduce", category: "quality" },
  { id: "u8", name: "Auto-Scaling", description: "Max agents +5", cost: 1200, purchased: false, effect: "capacity_5", category: "capacity" },
  { id: "u9", name: "Premium API", description: "All agents produce 50% faster", cost: 1500, purchased: false, effect: "speed_all", category: "speed" },
  { id: "u10", name: "Enterprise License", description: "Licensing income +100%", cost: 2000, purchased: false, effect: "licensing_boost", category: "revenue" },
];

export const useFactory = create<FactoryState>()(
  subscribeWithSelector((set, get) => ({
    revenue: 100,
    totalRevenue: 100,
    agents: [],
    assets: [],
    news: [{ id: genId(), message: "Welcome to Pocket Factory! Hire your first AI agent to begin.", timestamp: Date.now(), type: "info" }],
    riskLevel: 0,
    maxAgents: 5,
    revenueMultiplier: 1,
    speedMultiplier: 1,
    qualityMultiplier: 1,
    licensingIncome: 0,
    clonedAgents: 0,
    tickCount: 0,
    gameStarted: false,
    assetsProduced: 0,
    upgrades: DEFAULT_UPGRADES.map(u => ({ ...u })),

    startGame: () => set({ gameStarted: true }),

    hireAgent: (type, tier) => {
      const state = get();
      if (state.agents.length >= state.maxAgents) return;
      const baseCost = AGENT_BASE_COST[type];
      const cost = tier === "cloud" ? baseCost * 2 : baseCost;
      if (state.revenue < cost) return;

      const usedNames = new Set(state.agents.map(a => a.name));
      const availableNames = AGENT_NAMES.filter(n => !usedNames.has(n));
      const name = availableNames.length > 0 ? pickRandom(availableNames) : `Agent-${state.agents.length + 1}`;

      const agent: Agent = {
        id: genId(),
        name,
        type,
        tier,
        speed: AGENT_BASE_SPEED[type] * (tier === "cloud" ? 1.5 : 1),
        quality: tier === "cloud" ? 1.3 : 1.0,
        cost,
        progress: 0,
        producing: true,
        hiredAt: Date.now(),
      };

      const newsMsg = pickRandom(NEWS_MESSAGES.hire).replace("{name}", name);
      const newsItem: NewsItem = { id: genId(), message: newsMsg, timestamp: Date.now(), type: "success" };

      set({
        revenue: state.revenue - cost,
        agents: [...state.agents, agent],
        news: [newsItem, ...state.news].slice(0, 50),
      });
    },

    fireAgent: (id) => {
      const state = get();
      const agent = state.agents.find(a => a.id === id);
      if (!agent) return;
      const refund = Math.floor(agent.cost * 0.3);
      set({
        agents: state.agents.filter(a => a.id !== id),
        revenue: state.revenue + refund,
        news: [{ id: genId(), message: `${agent.name} was let go. Refund: $${refund}`, timestamp: Date.now(), type: "info" as const }, ...state.news].slice(0, 50),
      });
    },

    toggleAgentTier: (id) => {
      const state = get();
      set({
        agents: state.agents.map(a => {
          if (a.id !== id) return a;
          const newTier: ModelTier = a.tier === "local" ? "cloud" : "local";
          return {
            ...a,
            tier: newTier,
            speed: AGENT_BASE_SPEED[a.type] * (newTier === "cloud" ? 1.5 : 1) * state.speedMultiplier,
            quality: (newTier === "cloud" ? 1.3 : 1.0) * state.qualityMultiplier,
          };
        }),
      });
    },

    cloneAgent: (id) => {
      const state = get();
      const agent = state.agents.find(a => a.id === id);
      if (!agent) return;
      const cloneCost = agent.cost * 3;
      if (state.revenue < cloneCost) return;

      const newsMsg = pickRandom(NEWS_MESSAGES.clone).replace("{name}", agent.name);
      set({
        revenue: state.revenue - cloneCost,
        clonedAgents: state.clonedAgents + 1,
        licensingIncome: state.licensingIncome + Math.floor(ASSET_BASE_VALUE[agent.type] * 0.5),
        news: [{ id: genId(), message: newsMsg, timestamp: Date.now(), type: "success" as const }, ...state.news].slice(0, 50),
      });
    },

    purchaseUpgrade: (id) => {
      const state = get();
      const upgrade = state.upgrades.find(u => u.id === id);
      if (!upgrade || upgrade.purchased || state.revenue < upgrade.cost) return;

      let updates: Partial<FactoryState> = {
        revenue: state.revenue - upgrade.cost,
        upgrades: state.upgrades.map(u => u.id === id ? { ...u, purchased: true } : u),
      };

      switch (upgrade.effect) {
        case "speed_content":
          updates.speedMultiplier = state.speedMultiplier * 1.25;
          break;
        case "quality_code":
          updates.qualityMultiplier = state.qualityMultiplier * 1.3;
          break;
        case "revenue_research":
          updates.revenueMultiplier = state.revenueMultiplier * 1.4;
          break;
        case "capacity_3":
          updates.maxAgents = state.maxAgents + 3;
          break;
        case "speed_cloud":
          updates.speedMultiplier = state.speedMultiplier * 1.5;
          break;
        case "revenue_all":
          updates.revenueMultiplier = state.revenueMultiplier * 1.2;
          break;
        case "risk_reduce":
          updates.riskLevel = Math.max(0, state.riskLevel - 20);
          break;
        case "capacity_5":
          updates.maxAgents = state.maxAgents + 5;
          break;
        case "speed_all":
          updates.speedMultiplier = state.speedMultiplier * 1.5;
          break;
        case "licensing_boost":
          updates.licensingIncome = state.licensingIncome * 2;
          break;
      }

      const newsMsg = pickRandom(NEWS_MESSAGES.upgrade).replace("{name}", upgrade.name);
      updates.news = [{ id: genId(), message: newsMsg, timestamp: Date.now(), type: "success" as const }, ...state.news].slice(0, 50);

      set(updates as any);
    },

    tick: (delta) => {
      const state = get();
      if (!state.gameStarted) return;

      const newAgents = [...state.agents];
      const newNews = [...state.news];
      let newRevenue = state.revenue;
      let newTotalRevenue = state.totalRevenue;
      let newRisk = state.riskLevel;
      let newAssetsProduced = state.assetsProduced;
      const recentAssets = [...state.assets];
      const newTickCount = state.tickCount + 1;

      for (let i = 0; i < newAgents.length; i++) {
        const agent = { ...newAgents[i] };
        if (!agent.producing) {
          newAgents[i] = agent;
          continue;
        }

        agent.progress += agent.speed * state.speedMultiplier * delta * 0.5;

        if (agent.progress >= 100) {
          agent.progress = 0;
          const baseValue = ASSET_BASE_VALUE[agent.type];
          const value = Math.floor(baseValue * agent.quality * state.qualityMultiplier * state.revenueMultiplier);

          newRevenue += value;
          newTotalRevenue += value;
          newAssetsProduced += 1;

          recentAssets.unshift({
            id: genId(),
            type: agent.type,
            quality: agent.quality * state.qualityMultiplier,
            value,
            createdAt: Date.now(),
          });

          if (newNews.length < 50) {
            const msg = pickRandom(NEWS_MESSAGES.asset)
              .replace("{name}", agent.name)
              .replace("{type}", agent.type)
              .replace("{value}", String(value));
            newNews.unshift({ id: genId(), message: msg, timestamp: Date.now(), type: "info" });
          }
        }
        newAgents[i] = agent;
      }

      const agentCount = newAgents.length;
      const riskIncrease = agentCount > 3 ? (agentCount - 3) * 0.02 * delta : 0;
      const hasRiskUpgrade = state.upgrades.find(u => u.effect === "risk_reduce" && u.purchased);
      newRisk = Math.min(100, Math.max(0, newRisk + riskIncrease * (hasRiskUpgrade ? 0.7 : 1)));

      if (newRisk > 80 && Math.random() < 0.001 * delta) {
        const bugAgent = pickRandom(newAgents);
        if (bugAgent) {
          const lostValue = Math.floor(newRevenue * 0.05);
          newRevenue = Math.max(0, newRevenue - lostValue);
          newNews.unshift({
            id: genId(),
            message: `BUG: ${bugAgent.name} produced faulty output! Lost $${lostValue}`,
            timestamp: Date.now(),
            type: "danger",
          });
        }
      }

      if (newRisk > 50 && newTickCount % 300 === 0) {
        const riskMsg = pickRandom(NEWS_MESSAGES.risk);
        newNews.unshift({ id: genId(), message: riskMsg, timestamp: Date.now(), type: "warning" });
      }

      if (state.licensingIncome > 0 && newTickCount % 600 === 0) {
        newRevenue += state.licensingIncome;
        newTotalRevenue += state.licensingIncome;
        newNews.unshift({
          id: genId(),
          message: `Licensing royalties received: $${state.licensingIncome}`,
          timestamp: Date.now(),
          type: "success",
        });
      }

      if (newTickCount % 1800 === 0) {
        const reportLines = [
          `--- HOURLY REPORT ---`,
          `Agents: ${agentCount}/${state.maxAgents}`,
          `Revenue: $${Math.floor(newRevenue)}`,
          `Risk: ${Math.floor(newRisk)}%`,
          `Total assets: ${newAssetsProduced}`,
        ];
        newNews.unshift({
          id: genId(),
          message: reportLines.join(" | "),
          timestamp: Date.now(),
          type: "info",
        });
      }

      if (agentCount > 0) {
        newRisk = Math.max(0, newRisk - 0.005 * delta);
      }

      set({
        agents: newAgents,
        assets: recentAssets.slice(0, 20),
        news: newNews.slice(0, 50),
        revenue: newRevenue,
        totalRevenue: newTotalRevenue,
        riskLevel: newRisk,
        tickCount: newTickCount,
        assetsProduced: newAssetsProduced,
      });
    },
  }))
);
