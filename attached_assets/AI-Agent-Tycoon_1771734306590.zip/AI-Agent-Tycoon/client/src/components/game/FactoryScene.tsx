import { useRef, useMemo } from "react";
import { useFrame } from "@react-three/fiber";
import { useTexture, Text } from "@react-three/drei";
import * as THREE from "three";
import { useFactory } from "@/lib/stores/useFactory";

function Floor() {
  const texture = useTexture("/textures/asphalt.png");
  texture.wrapS = texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(10, 10);

  return (
    <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]} receiveShadow>
      <planeGeometry args={[40, 40]} />
      <meshStandardMaterial map={texture} />
    </mesh>
  );
}

function FactoryBuilding() {
  const woodTexture = useTexture("/textures/wood.jpg");

  return (
    <group position={[0, 0, -8]}>
      <mesh position={[0, 2.5, 0]} castShadow receiveShadow>
        <boxGeometry args={[12, 5, 6]} />
        <meshStandardMaterial color="#2a3a5c" metalness={0.3} roughness={0.7} />
      </mesh>
      <mesh position={[0, 5.5, 0]} castShadow>
        <boxGeometry args={[13, 1, 7]} />
        <meshStandardMaterial color="#1a2a4c" metalness={0.4} roughness={0.6} />
      </mesh>
      <mesh position={[0, 6.2, 0]}>
        <boxGeometry args={[4, 0.6, 3]} />
        <meshStandardMaterial color="#3a5a8c" metalness={0.5} roughness={0.5} />
      </mesh>
      {[-4, -1.5, 1.5, 4].map((x, i) => (
        <mesh key={i} position={[x, 2.5, 3.01]} castShadow>
          <boxGeometry args={[1.5, 2.5, 0.1]} />
          <meshStandardMaterial color="#88ccff" transparent opacity={0.6} emissive="#4488cc" emissiveIntensity={0.3} />
        </mesh>
      ))}
      <mesh position={[0, 6.5, 0]}>
        <boxGeometry args={[1, 0.3, 1]} />
        <meshStandardMaterial color="#ff4444" emissive="#ff2222" emissiveIntensity={0.5} />
      </mesh>
      <Text
        position={[0, 5.9, 3.55]}
        fontSize={0.6}
        color="#88ddff"
        anchorX="center"
        anchorY="middle"
      >
        POCKET FACTORY
      </Text>
    </group>
  );
}

function ServerRack({ position }: { position: [number, number, number] }) {
  return (
    <group position={position}>
      <mesh position={[0, 1, 0]} castShadow>
        <boxGeometry args={[0.8, 2, 0.6]} />
        <meshStandardMaterial color="#222222" metalness={0.6} roughness={0.4} />
      </mesh>
      {[0.3, 0.7, 1.1, 1.5].map((y, i) => (
        <mesh key={i} position={[0, y, 0.31]}>
          <boxGeometry args={[0.6, 0.15, 0.02]} />
          <meshStandardMaterial
            color={i % 2 === 0 ? "#00ff44" : "#44aaff"}
            emissive={i % 2 === 0 ? "#00ff44" : "#44aaff"}
            emissiveIntensity={0.8}
          />
        </mesh>
      ))}
    </group>
  );
}

const AGENT_COLORS: Record<string, string> = {
  content: "#ff8844",
  code: "#44aaff",
  research: "#44ff88",
};

const AGENT_EMISSIVE: Record<string, string> = {
  content: "#cc6622",
  code: "#2266cc",
  research: "#22cc66",
};

function AgentBot({ agent, index }: { agent: any; index: number }) {
  const meshRef = useRef<THREE.Mesh>(null);
  const particleRef = useRef<THREE.Points>(null);

  const col = Math.floor(index % 5);
  const row = Math.floor(index / 5);
  const baseX = -4 + col * 2;
  const baseZ = -2 + row * 2.5;

  const particleGeo = useMemo(() => {
    const geo = new THREE.BufferGeometry();
    const positions = new Float32Array(15 * 3);
    for (let i = 0; i < 15; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 1.5;
      positions[i * 3 + 1] = Math.random() * 2;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 1.5;
    }
    geo.setAttribute("position", new THREE.BufferAttribute(positions, 3));
    return geo;
  }, []);

  useFrame((_, delta) => {
    if (meshRef.current) {
      meshRef.current.position.y = 0.6 + Math.sin(Date.now() * 0.003 + index) * 0.1;
      if (agent.producing) {
        meshRef.current.rotation.y += delta * 0.5;
      }
    }
    if (particleRef.current && agent.producing) {
      const positions = particleRef.current.geometry.attributes.position.array as Float32Array;
      for (let i = 0; i < positions.length; i += 3) {
        positions[i + 1] += delta * 0.5;
        if (positions[i + 1] > 2.5) {
          positions[i + 1] = 0;
        }
      }
      particleRef.current.geometry.attributes.position.needsUpdate = true;
    }
  });

  const color = AGENT_COLORS[agent.type] || "#ffffff";
  const emissive = AGENT_EMISSIVE[agent.type] || "#888888";
  const isCloud = agent.tier === "cloud";

  return (
    <group position={[baseX, 0, baseZ]}>
      <mesh position={[0, 0.15, 0]} receiveShadow>
        <cylinderGeometry args={[0.5, 0.6, 0.3, 6]} />
        <meshStandardMaterial color="#333" metalness={0.8} roughness={0.3} />
      </mesh>

      <mesh ref={meshRef} position={[0, 0.6, 0]} castShadow>
        <boxGeometry args={[0.6, 0.6, 0.6]} />
        <meshStandardMaterial
          color={color}
          emissive={emissive}
          emissiveIntensity={agent.producing ? 0.4 : 0.1}
          metalness={isCloud ? 0.7 : 0.3}
          roughness={isCloud ? 0.2 : 0.6}
        />
      </mesh>

      {isCloud && (
        <mesh position={[0, 1.3, 0]}>
          <sphereGeometry args={[0.2, 8, 8]} />
          <meshStandardMaterial
            color="#aaddff"
            transparent
            opacity={0.6}
            emissive="#88bbff"
            emissiveIntensity={0.6}
          />
        </mesh>
      )}

      <mesh position={[0, 0.01, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <ringGeometry args={[0.6, 0.8, 32]} />
        <meshStandardMaterial
          color={color}
          emissive={emissive}
          emissiveIntensity={0.3}
          transparent
          opacity={0.4 + (agent.progress / 100) * 0.6}
        />
      </mesh>

      {agent.progress > 0 && (
        <mesh position={[0, 0.02, 0]} rotation={[-Math.PI / 2, 0, 0]}>
          <ringGeometry args={[0.65, 0.75, 32, 1, 0, (agent.progress / 100) * Math.PI * 2]} />
          <meshStandardMaterial
            color="#ffffff"
            emissive="#ffffff"
            emissiveIntensity={0.8}
          />
        </mesh>
      )}

      {agent.producing && (
        <points ref={particleRef} position={[0, 0.5, 0]}>
          <primitive object={particleGeo} attach="geometry" />
          <pointsMaterial
            color={color}
            size={0.05}
            transparent
            opacity={0.6}
          />
        </points>
      )}

      <Text
        position={[0, 1.6, 0]}
        fontSize={0.2}
        color="#ffffff"
        anchorX="center"
        anchorY="middle"
        outlineWidth={0.02}
        outlineColor="#000000"
      >
        {agent.name}
      </Text>
      <Text
        position={[0, 1.35, 0]}
        fontSize={0.13}
        color={color}
        anchorX="center"
        anchorY="middle"
        outlineWidth={0.01}
        outlineColor="#000000"
      >
        {agent.type.toUpperCase()} {isCloud ? "☁" : "⚙"}
      </Text>
    </group>
  );
}

function Lights() {
  return (
    <>
      <ambientLight intensity={0.3} />
      <directionalLight
        position={[10, 15, 10]}
        intensity={1}
        castShadow
        shadow-mapSize={[2048, 2048]}
        shadow-camera-far={50}
        shadow-camera-left={-20}
        shadow-camera-right={20}
        shadow-camera-top={20}
        shadow-camera-bottom={-20}
      />
      <pointLight position={[0, 8, -5]} intensity={0.5} color="#4488ff" />
      <pointLight position={[-5, 3, 2]} intensity={0.3} color="#ff8844" />
      <pointLight position={[5, 3, 2]} intensity={0.3} color="#44ff88" />
    </>
  );
}

function GameTicker() {
  const tick = useFactory(state => state.tick);

  useFrame((_, delta) => {
    tick(delta * 60);
  });

  return null;
}

export default function FactoryScene() {
  const agents = useFactory(state => state.agents);

  const serverPositions = useMemo<[number, number, number][]>(() => [
    [-7, 0, -6], [-7, 0, -4], [-7, 0, -2],
    [7, 0, -6], [7, 0, -4], [7, 0, -2],
  ], []);

  return (
    <>
      <Lights />
      <color attach="background" args={["#0a0a1a"]} />
      <fog attach="fog" args={["#0a0a1a", 15, 40]} />

      <Floor />
      <FactoryBuilding />

      {serverPositions.map((pos, i) => (
        <ServerRack key={i} position={pos} />
      ))}

      {agents.map((agent, i) => (
        <AgentBot key={agent.id} agent={agent} index={i} />
      ))}

      <GameTicker />
    </>
  );
}
