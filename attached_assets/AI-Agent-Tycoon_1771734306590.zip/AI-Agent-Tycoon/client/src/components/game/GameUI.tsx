import { useState } from "react";
import { useFactory, type AgentType, type ModelTier } from "@/lib/stores/useFactory";

function HUD() {
  const revenue = useFactory(s => s.revenue);
  const totalRevenue = useFactory(s => s.totalRevenue);
  const agents = useFactory(s => s.agents);
  const maxAgents = useFactory(s => s.maxAgents);
  const riskLevel = useFactory(s => s.riskLevel);
  const licensingIncome = useFactory(s => s.licensingIncome);
  const clonedAgents = useFactory(s => s.clonedAgents);
  const assetsProduced = useFactory(s => s.assetsProduced);

  const riskColor = riskLevel < 30 ? "#44ff88" : riskLevel < 60 ? "#ffaa44" : riskLevel < 80 ? "#ff6644" : "#ff2222";

  return (
    <div style={{
      position: "absolute",
      top: 10,
      left: 10,
      right: 10,
      display: "flex",
      justifyContent: "space-between",
      alignItems: "flex-start",
      pointerEvents: "none",
      zIndex: 10,
    }}>
      <div style={{
        background: "rgba(0,0,0,0.85)",
        border: "1px solid rgba(100,150,255,0.3)",
        borderRadius: 12,
        padding: "12px 18px",
        color: "#fff",
        fontFamily: "'Inter', sans-serif",
        minWidth: 220,
      }}>
        <div style={{ fontSize: 11, color: "#8899bb", textTransform: "uppercase", letterSpacing: 1, marginBottom: 6 }}>Revenue</div>
        <div style={{ fontSize: 28, fontWeight: 700, color: "#44ff88" }}>${Math.floor(revenue).toLocaleString()}</div>
        <div style={{ fontSize: 11, color: "#6677aa", marginTop: 2 }}>Total earned: ${Math.floor(totalRevenue).toLocaleString()}</div>
        {licensingIncome > 0 && (
          <div style={{ fontSize: 11, color: "#88aaff", marginTop: 4 }}>
            Licensing: +${licensingIncome}/cycle ({clonedAgents} clones)
          </div>
        )}
      </div>

      <div style={{
        background: "rgba(0,0,0,0.85)",
        border: "1px solid rgba(100,150,255,0.3)",
        borderRadius: 12,
        padding: "12px 18px",
        color: "#fff",
        fontFamily: "'Inter', sans-serif",
        textAlign: "center",
      }}>
        <div style={{ fontSize: 11, color: "#8899bb", textTransform: "uppercase", letterSpacing: 1, marginBottom: 6 }}>Agents</div>
        <div style={{ fontSize: 22, fontWeight: 700 }}>{agents.length} / {maxAgents}</div>
        <div style={{ fontSize: 11, color: "#6677aa", marginTop: 2 }}>Assets: {assetsProduced}</div>
      </div>

      <div style={{
        background: "rgba(0,0,0,0.85)",
        border: "1px solid rgba(100,150,255,0.3)",
        borderRadius: 12,
        padding: "12px 18px",
        color: "#fff",
        fontFamily: "'Inter', sans-serif",
        minWidth: 180,
      }}>
        <div style={{ fontSize: 11, color: "#8899bb", textTransform: "uppercase", letterSpacing: 1, marginBottom: 6 }}>Risk Meter</div>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <div style={{
            flex: 1,
            height: 12,
            background: "rgba(255,255,255,0.1)",
            borderRadius: 6,
            overflow: "hidden",
          }}>
            <div style={{
              width: `${riskLevel}%`,
              height: "100%",
              background: riskColor,
              borderRadius: 6,
              transition: "width 0.3s, background 0.3s",
              boxShadow: riskLevel > 60 ? `0 0 8px ${riskColor}` : "none",
            }} />
          </div>
          <span style={{ fontSize: 14, fontWeight: 700, color: riskColor }}>{Math.floor(riskLevel)}%</span>
        </div>
        <div style={{ fontSize: 10, color: "#6677aa", marginTop: 4 }}>
          {riskLevel < 30 ? "Stable" : riskLevel < 60 ? "Elevated" : riskLevel < 80 ? "High Risk" : "CRITICAL"}
        </div>
      </div>
    </div>
  );
}

function HirePanel({ onClose }: { onClose: () => void }) {
  const revenue = useFactory(s => s.revenue);
  const agents = useFactory(s => s.agents);
  const maxAgents = useFactory(s => s.maxAgents);
  const hireAgent = useFactory(s => s.hireAgent);

  const agentTypes: { type: AgentType; label: string; desc: string; icon: string }[] = [
    { type: "content", label: "Content Agent", desc: "Generates posts, articles, social media content", icon: "📝" },
    { type: "code", label: "Code Agent", desc: "Produces code, scripts, automations", icon: "💻" },
    { type: "research", label: "Research Agent", desc: "Delivers insights, analysis, reports", icon: "🔬" },
  ];

  const tiers: { tier: ModelTier; label: string; multiplier: number; badge: string }[] = [
    { tier: "local", label: "Local Model", multiplier: 1, badge: "⚙ Local" },
    { tier: "cloud", label: "Cloud Model", multiplier: 2, badge: "☁ Cloud" },
  ];

  const baseCosts = { content: 50, code: 100, research: 150 };

  return (
    <div style={{
      position: "absolute",
      top: "50%",
      left: "50%",
      transform: "translate(-50%, -50%)",
      background: "rgba(10,15,30,0.95)",
      border: "1px solid rgba(100,150,255,0.4)",
      borderRadius: 16,
      padding: 24,
      color: "#fff",
      fontFamily: "'Inter', sans-serif",
      zIndex: 100,
      minWidth: 420,
      maxHeight: "80vh",
      overflowY: "auto",
      pointerEvents: "auto",
    }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
        <h2 style={{ fontSize: 20, fontWeight: 700, margin: 0 }}>Hire Agent</h2>
        <button onClick={onClose} style={{
          background: "rgba(255,255,255,0.1)",
          border: "none",
          color: "#aaa",
          fontSize: 18,
          cursor: "pointer",
          borderRadius: 8,
          width: 32,
          height: 32,
        }}>✕</button>
      </div>
      <div style={{ fontSize: 12, color: "#6677aa", marginBottom: 16 }}>
        Slots: {agents.length}/{maxAgents} | Budget: ${Math.floor(revenue)}
      </div>

      {agentTypes.map(at => (
        <div key={at.type} style={{
          background: "rgba(255,255,255,0.05)",
          borderRadius: 12,
          padding: 16,
          marginBottom: 12,
        }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
            <span style={{ fontSize: 24 }}>{at.icon}</span>
            <div>
              <div style={{ fontWeight: 600 }}>{at.label}</div>
              <div style={{ fontSize: 11, color: "#8899bb" }}>{at.desc}</div>
            </div>
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            {tiers.map(t => {
              const cost = baseCosts[at.type] * t.multiplier;
              const canAfford = revenue >= cost && agents.length < maxAgents;
              return (
                <button
                  key={t.tier}
                  onClick={() => { hireAgent(at.type, t.tier); }}
                  disabled={!canAfford}
                  style={{
                    flex: 1,
                    padding: "8px 12px",
                    background: canAfford ? "rgba(68,170,255,0.2)" : "rgba(255,255,255,0.05)",
                    border: `1px solid ${canAfford ? "rgba(68,170,255,0.5)" : "rgba(255,255,255,0.1)"}`,
                    borderRadius: 8,
                    color: canAfford ? "#fff" : "#555",
                    cursor: canAfford ? "pointer" : "not-allowed",
                    fontSize: 12,
                    fontFamily: "'Inter', sans-serif",
                  }}
                >
                  <div style={{ fontWeight: 600 }}>{t.badge}</div>
                  <div style={{ color: canAfford ? "#44ff88" : "#555", marginTop: 4 }}>${cost}</div>
                </button>
              );
            })}
          </div>
        </div>
      ))}
    </div>
  );
}

function AgentList({ onClose }: { onClose: () => void }) {
  const agents = useFactory(s => s.agents);
  const revenue = useFactory(s => s.revenue);
  const fireAgent = useFactory(s => s.fireAgent);
  const toggleAgentTier = useFactory(s => s.toggleAgentTier);
  const cloneAgent = useFactory(s => s.cloneAgent);

  const baseCosts = { content: 50, code: 100, research: 150 };
  const typeColors: Record<string, string> = { content: "#ff8844", code: "#44aaff", research: "#44ff88" };

  return (
    <div style={{
      position: "absolute",
      top: "50%",
      left: "50%",
      transform: "translate(-50%, -50%)",
      background: "rgba(10,15,30,0.95)",
      border: "1px solid rgba(100,150,255,0.4)",
      borderRadius: 16,
      padding: 24,
      color: "#fff",
      fontFamily: "'Inter', sans-serif",
      zIndex: 100,
      minWidth: 450,
      maxHeight: "80vh",
      overflowY: "auto",
      pointerEvents: "auto",
    }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
        <h2 style={{ fontSize: 20, fontWeight: 700, margin: 0 }}>Your Agents ({agents.length})</h2>
        <button onClick={onClose} style={{
          background: "rgba(255,255,255,0.1)",
          border: "none",
          color: "#aaa",
          fontSize: 18,
          cursor: "pointer",
          borderRadius: 8,
          width: 32,
          height: 32,
        }}>✕</button>
      </div>

      {agents.length === 0 && (
        <div style={{ textAlign: "center", color: "#6677aa", padding: 20 }}>No agents hired yet.</div>
      )}

      {agents.map(agent => {
        const cloneCost = (agent.tier === "cloud" ? baseCosts[agent.type] * 2 : baseCosts[agent.type]) * 3;
        return (
          <div key={agent.id} style={{
            background: "rgba(255,255,255,0.05)",
            borderRadius: 12,
            padding: 14,
            marginBottom: 10,
            borderLeft: `3px solid ${typeColors[agent.type]}`,
          }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <div>
                <span style={{ fontWeight: 600, marginRight: 8 }}>{agent.name}</span>
                <span style={{
                  fontSize: 10,
                  padding: "2px 6px",
                  borderRadius: 4,
                  background: typeColors[agent.type] + "33",
                  color: typeColors[agent.type],
                  textTransform: "uppercase",
                }}>{agent.type}</span>
                <span style={{
                  fontSize: 10,
                  padding: "2px 6px",
                  borderRadius: 4,
                  background: agent.tier === "cloud" ? "rgba(68,170,255,0.2)" : "rgba(255,255,255,0.1)",
                  color: agent.tier === "cloud" ? "#88ccff" : "#888",
                  marginLeft: 4,
                }}>{agent.tier === "cloud" ? "☁ Cloud" : "⚙ Local"}</span>
              </div>
              <div style={{ fontSize: 12, color: "#88aaff" }}>
                {Math.floor(agent.progress)}%
              </div>
            </div>

            <div style={{
              height: 4,
              background: "rgba(255,255,255,0.1)",
              borderRadius: 2,
              marginTop: 8,
              overflow: "hidden",
            }}>
              <div style={{
                width: `${agent.progress}%`,
                height: "100%",
                background: typeColors[agent.type],
                borderRadius: 2,
                transition: "width 0.1s",
              }} />
            </div>

            <div style={{ display: "flex", gap: 6, marginTop: 10 }}>
              <button onClick={() => toggleAgentTier(agent.id)} style={{
                padding: "4px 10px",
                background: "rgba(255,255,255,0.08)",
                border: "1px solid rgba(255,255,255,0.15)",
                borderRadius: 6,
                color: "#aabbdd",
                cursor: "pointer",
                fontSize: 11,
                fontFamily: "'Inter', sans-serif",
              }}>
                Switch to {agent.tier === "cloud" ? "Local" : "Cloud"}
              </button>
              <button
                onClick={() => cloneAgent(agent.id)}
                disabled={revenue < cloneCost}
                style={{
                  padding: "4px 10px",
                  background: revenue >= cloneCost ? "rgba(68,255,136,0.15)" : "rgba(255,255,255,0.05)",
                  border: `1px solid ${revenue >= cloneCost ? "rgba(68,255,136,0.3)" : "rgba(255,255,255,0.1)"}`,
                  borderRadius: 6,
                  color: revenue >= cloneCost ? "#44ff88" : "#555",
                  cursor: revenue >= cloneCost ? "pointer" : "not-allowed",
                  fontSize: 11,
                  fontFamily: "'Inter', sans-serif",
                }}
              >
                Clone (${cloneCost})
              </button>
              <button onClick={() => fireAgent(agent.id)} style={{
                padding: "4px 10px",
                background: "rgba(255,68,68,0.15)",
                border: "1px solid rgba(255,68,68,0.3)",
                borderRadius: 6,
                color: "#ff6644",
                cursor: "pointer",
                fontSize: 11,
                marginLeft: "auto",
                fontFamily: "'Inter', sans-serif",
              }}>
                Fire
              </button>
            </div>
          </div>
        );
      })}
    </div>
  );
}

function UpgradeShop({ onClose }: { onClose: () => void }) {
  const upgrades = useFactory(s => s.upgrades);
  const revenue = useFactory(s => s.revenue);
  const purchaseUpgrade = useFactory(s => s.purchaseUpgrade);

  const categoryColors: Record<string, string> = {
    speed: "#ffaa44",
    quality: "#44aaff",
    capacity: "#aa44ff",
    revenue: "#44ff88",
  };

  return (
    <div style={{
      position: "absolute",
      top: "50%",
      left: "50%",
      transform: "translate(-50%, -50%)",
      background: "rgba(10,15,30,0.95)",
      border: "1px solid rgba(100,150,255,0.4)",
      borderRadius: 16,
      padding: 24,
      color: "#fff",
      fontFamily: "'Inter', sans-serif",
      zIndex: 100,
      minWidth: 420,
      maxHeight: "80vh",
      overflowY: "auto",
      pointerEvents: "auto",
    }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
        <h2 style={{ fontSize: 20, fontWeight: 700, margin: 0 }}>Upgrades</h2>
        <button onClick={onClose} style={{
          background: "rgba(255,255,255,0.1)",
          border: "none",
          color: "#aaa",
          fontSize: 18,
          cursor: "pointer",
          borderRadius: 8,
          width: 32,
          height: 32,
        }}>✕</button>
      </div>

      {upgrades.map(upgrade => {
        const canAfford = revenue >= upgrade.cost && !upgrade.purchased;
        const catColor = categoryColors[upgrade.category] || "#888";
        return (
          <div key={upgrade.id} style={{
            background: upgrade.purchased ? "rgba(68,255,136,0.05)" : "rgba(255,255,255,0.05)",
            borderRadius: 10,
            padding: 14,
            marginBottom: 8,
            opacity: upgrade.purchased ? 0.6 : 1,
            borderLeft: `3px solid ${upgrade.purchased ? "#44ff88" : catColor}`,
          }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <div>
                <span style={{ fontWeight: 600, marginRight: 8 }}>{upgrade.name}</span>
                <span style={{
                  fontSize: 10,
                  padding: "2px 6px",
                  borderRadius: 4,
                  background: catColor + "33",
                  color: catColor,
                  textTransform: "uppercase",
                }}>{upgrade.category}</span>
              </div>
              {!upgrade.purchased ? (
                <button
                  onClick={() => purchaseUpgrade(upgrade.id)}
                  disabled={!canAfford}
                  style={{
                    padding: "6px 14px",
                    background: canAfford ? "rgba(68,255,136,0.2)" : "rgba(255,255,255,0.05)",
                    border: `1px solid ${canAfford ? "rgba(68,255,136,0.4)" : "rgba(255,255,255,0.1)"}`,
                    borderRadius: 8,
                    color: canAfford ? "#44ff88" : "#555",
                    cursor: canAfford ? "pointer" : "not-allowed",
                    fontSize: 12,
                    fontWeight: 600,
                    fontFamily: "'Inter', sans-serif",
                  }}
                >
                  ${upgrade.cost}
                </button>
              ) : (
                <span style={{ fontSize: 12, color: "#44ff88" }}>✓ Purchased</span>
              )}
            </div>
            <div style={{ fontSize: 11, color: "#8899bb", marginTop: 4 }}>{upgrade.description}</div>
          </div>
        );
      })}
    </div>
  );
}

function NewsFeed({ onClose }: { onClose: () => void }) {
  const news = useFactory(s => s.news);

  const typeColors: Record<string, string> = {
    info: "#88aadd",
    warning: "#ffaa44",
    success: "#44ff88",
    danger: "#ff4444",
  };

  return (
    <div style={{
      position: "absolute",
      top: "50%",
      left: "50%",
      transform: "translate(-50%, -50%)",
      background: "rgba(10,15,30,0.95)",
      border: "1px solid rgba(100,150,255,0.4)",
      borderRadius: 16,
      padding: 24,
      color: "#fff",
      fontFamily: "'Inter', sans-serif",
      zIndex: 100,
      minWidth: 450,
      maxWidth: 550,
      maxHeight: "70vh",
      overflowY: "auto",
      pointerEvents: "auto",
    }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
        <h2 style={{ fontSize: 20, fontWeight: 700, margin: 0 }}>News Feed</h2>
        <button onClick={onClose} style={{
          background: "rgba(255,255,255,0.1)",
          border: "none",
          color: "#aaa",
          fontSize: 18,
          cursor: "pointer",
          borderRadius: 8,
          width: 32,
          height: 32,
        }}>✕</button>
      </div>

      {news.map(item => (
        <div key={item.id} style={{
          padding: "8px 12px",
          marginBottom: 4,
          borderLeft: `2px solid ${typeColors[item.type]}`,
          fontSize: 12,
          color: typeColors[item.type],
          background: "rgba(255,255,255,0.03)",
          borderRadius: "0 6px 6px 0",
        }}>
          {item.message}
        </div>
      ))}
    </div>
  );
}

function BottomBar({ onOpenPanel }: { onOpenPanel: (panel: string) => void }) {
  const news = useFactory(s => s.news);
  const latestNews = news[0];

  return (
    <div style={{
      position: "absolute",
      bottom: 10,
      left: 10,
      right: 10,
      display: "flex",
      alignItems: "center",
      gap: 8,
      zIndex: 10,
      pointerEvents: "none",
    }}>
      <div style={{
        flex: 1,
        background: "rgba(0,0,0,0.85)",
        border: "1px solid rgba(100,150,255,0.3)",
        borderRadius: 12,
        padding: "8px 16px",
        color: "#8899bb",
        fontFamily: "'Inter', sans-serif",
        fontSize: 12,
        overflow: "hidden",
        whiteSpace: "nowrap",
        textOverflow: "ellipsis",
        pointerEvents: "auto",
        cursor: "pointer",
      }} onClick={() => onOpenPanel("news")}>
        {latestNews ? latestNews.message : "No news yet..."}
      </div>

      <div style={{ display: "flex", gap: 6, pointerEvents: "auto" }}>
        {[
          { key: "hire", label: "➕ Hire", color: "#44aaff" },
          { key: "agents", label: "🤖 Agents", color: "#ff8844" },
          { key: "upgrades", label: "⬆ Upgrades", color: "#aa44ff" },
          { key: "news", label: "📰 News", color: "#44ff88" },
        ].map(btn => (
          <button
            key={btn.key}
            onClick={() => onOpenPanel(btn.key)}
            style={{
              padding: "8px 16px",
              background: "rgba(0,0,0,0.85)",
              border: `1px solid ${btn.color}44`,
              borderRadius: 10,
              color: btn.color,
              cursor: "pointer",
              fontSize: 13,
              fontWeight: 600,
              fontFamily: "'Inter', sans-serif",
              whiteSpace: "nowrap",
              transition: "background 0.2s",
            }}
            onMouseEnter={e => { (e.target as HTMLElement).style.background = btn.color + "22"; }}
            onMouseLeave={e => { (e.target as HTMLElement).style.background = "rgba(0,0,0,0.85)"; }}
          >
            {btn.label}
          </button>
        ))}
      </div>
    </div>
  );
}

function StartScreen() {
  const startGame = useFactory(s => s.startGame);

  return (
    <div style={{
      position: "absolute",
      inset: 0,
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      background: "rgba(5,8,20,0.92)",
      zIndex: 200,
      fontFamily: "'Inter', sans-serif",
      color: "#fff",
    }}>
      <div style={{ fontSize: 48, fontWeight: 800, marginBottom: 8, letterSpacing: -1 }}>
        <span style={{ color: "#44aaff" }}>POCKET</span> <span style={{ color: "#44ff88" }}>FACTORY</span>
      </div>
      <div style={{ fontSize: 16, color: "#6688bb", marginBottom: 32, letterSpacing: 4, textTransform: "uppercase" }}>
        AI Automation Simulator
      </div>

      <div style={{
        maxWidth: 400,
        textAlign: "center",
        color: "#8899bb",
        fontSize: 13,
        lineHeight: 1.6,
        marginBottom: 32,
      }}>
        Build your AI factory. Hire agents to generate content, code, and research.
        Manage risk, upgrade your infrastructure, and clone your best agents for licensing revenue.
      </div>

      <button
        onClick={startGame}
        style={{
          padding: "14px 48px",
          background: "linear-gradient(135deg, #44aaff, #44ff88)",
          border: "none",
          borderRadius: 12,
          color: "#000",
          fontSize: 18,
          fontWeight: 700,
          cursor: "pointer",
          fontFamily: "'Inter', sans-serif",
          letterSpacing: 1,
          transition: "transform 0.2s",
        }}
        onMouseEnter={e => { (e.target as HTMLElement).style.transform = "scale(1.05)"; }}
        onMouseLeave={e => { (e.target as HTMLElement).style.transform = "scale(1)"; }}
      >
        START FACTORY
      </button>

      <div style={{ marginTop: 24, fontSize: 11, color: "#445566" }}>
        Strategy / Idle / Automation
      </div>
    </div>
  );
}

export default function GameUI() {
  const [openPanel, setOpenPanel] = useState<string | null>(null);
  const gameStarted = useFactory(s => s.gameStarted);

  const closePanel = () => setOpenPanel(null);

  if (!gameStarted) {
    return <StartScreen />;
  }

  return (
    <>
      <HUD />
      <BottomBar onOpenPanel={(p) => setOpenPanel(openPanel === p ? null : p)} />

      {openPanel === "hire" && <HirePanel onClose={closePanel} />}
      {openPanel === "agents" && <AgentList onClose={closePanel} />}
      {openPanel === "upgrades" && <UpgradeShop onClose={closePanel} />}
      {openPanel === "news" && <NewsFeed onClose={closePanel} />}

      {openPanel && (
        <div
          style={{
            position: "absolute",
            inset: 0,
            zIndex: 50,
          }}
          onClick={closePanel}
        />
      )}
    </>
  );
}
