# Pocket Factory Simulator

## Overview
A 3D idle/strategy/automation game built with React Three Fiber. Players hire AI agents that generate assets (content, code, research) which auto-convert to revenue. Revenue unlocks better upgrades, faster agents, and cloud infrastructure.

## Project Architecture
- **Frontend**: React + React Three Fiber (3D scene) + Zustand (state management) + Tailwind CSS
- **Backend**: Node.js + Express (serves the client)
- **Game State**: `client/src/lib/stores/useFactory.tsx` - core game simulation store
- **3D Scene**: `client/src/components/game/FactoryScene.tsx` - factory floor, agents, server racks
- **UI Overlay**: `client/src/components/game/GameUI.tsx` - HUD, hire panel, agent list, upgrade shop, news feed

## Key Features
- Hire AI agents (content, code, research) with local or cloud model tiers
- Agents produce assets that auto-convert to revenue
- Risk meter that rises with over-automation
- Upgrade shop (speed, quality, capacity, revenue upgrades)
- Agent cloning for passive licensing income
- News feed with hourly reports
- 3D factory visualization with animated agent bots

## Recent Changes
- 2026-02-22: Initial build of Pocket Factory Simulator with full game loop, 3D scene, and UI overlay
