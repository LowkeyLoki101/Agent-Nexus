interface YouTubeTranscriptResult {
  title: string;
  transcript: string;
  metadata: {
    videoId: string;
    channel: string;
    duration: string;
    viewCount?: string;
    description?: string;
  };
}

interface CaptionTrack {
  baseUrl: string;
  languageCode: string;
  name: string;
}

export class YouTubeTranscriptError extends Error {
  constructor(message: string, public code: string) {
    super(message);
    this.name = 'YouTubeTranscriptError';
  }
}

function extractVideoId(url: string): string {
  const patterns = [
    /(?:youtube\.com\/watch\?v=|youtube\.com\/watch\?.+&v=)([^&]+)/,
    /youtu\.be\/([^?&]+)/,
    /youtube\.com\/embed\/([^?&]+)/,
    /youtube\.com\/v\/([^?&]+)/,
    /youtube\.com\/shorts\/([^?&]+)/,
    /^([a-zA-Z0-9_-]{11})$/,
  ];

  for (const pattern of patterns) {
    const match = url.match(pattern);
    if (match && match[1]) {
      return match[1];
    }
  }

  throw new YouTubeTranscriptError(
    'Invalid YouTube URL. Supported formats: youtube.com/watch?v=, youtu.be/, youtube.com/embed/, youtube.com/shorts/',
    'INVALID_URL'
  );
}

function decodeHtmlEntities(text: string): string {
  return text
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&apos;/g, "'")
    .replace(/&#(\d+);/g, (_, code) => String.fromCharCode(parseInt(code, 10)))
    .replace(/\\n/g, '\n')
    .replace(/\s+/g, ' ')
    .trim();
}

function parseTranscriptXml(xml: string): string {
  const textMatches = xml.match(/<text[^>]*>([^<]*)<\/text>/g);
  if (!textMatches) {
    return '';
  }

  const lines: string[] = [];
  for (const match of textMatches) {
    const textContent = match.replace(/<text[^>]*>/, '').replace(/<\/text>/, '');
    const decoded = decodeHtmlEntities(textContent);
    if (decoded) {
      lines.push(decoded);
    }
  }

  return lines.join(' ');
}

async function fetchVideoPage(videoId: string): Promise<string> {
  const url = `https://www.youtube.com/watch?v=${videoId}`;
  
  const response = await fetch(url, {
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      'Accept-Language': 'en-US,en;q=0.9',
      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    },
  });

  if (!response.ok) {
    throw new YouTubeTranscriptError(
      `Failed to fetch video page: ${response.status} ${response.statusText}`,
      'FETCH_ERROR'
    );
  }

  return response.text();
}

function extractPlayerResponse(html: string): any {
  const patterns = [
    /var ytInitialPlayerResponse\s*=\s*({.+?});/,
    /ytInitialPlayerResponse\s*=\s*({.+?});/,
  ];

  for (const pattern of patterns) {
    const match = html.match(pattern);
    if (match && match[1]) {
      try {
        return JSON.parse(match[1]);
      } catch {
        continue;
      }
    }
  }

  const scriptMatch = html.match(/ytInitialPlayerResponse\s*=\s*({[\s\S]*?"responseContext"[\s\S]*?});/);
  if (scriptMatch && scriptMatch[1]) {
    try {
      const cleanJson = scriptMatch[1].replace(/\n/g, '');
      return JSON.parse(cleanJson);
    } catch {
    }
  }

  throw new YouTubeTranscriptError(
    'Could not extract video data from page',
    'PARSE_ERROR'
  );
}

function extractInitialData(html: string): any {
  const patterns = [
    /var ytInitialData\s*=\s*({.+?});/,
    /ytInitialData\s*=\s*({.+?});/,
  ];

  for (const pattern of patterns) {
    const match = html.match(pattern);
    if (match && match[1]) {
      try {
        return JSON.parse(match[1]);
      } catch {
        continue;
      }
    }
  }

  return null;
}

function extractCaptionTracks(playerResponse: any): CaptionTrack[] {
  const captions = playerResponse?.captions?.playerCaptionsTracklistRenderer?.captionTracks;
  
  if (!captions || !Array.isArray(captions)) {
    return [];
  }

  return captions.map((track: any) => ({
    baseUrl: track.baseUrl,
    languageCode: track.languageCode,
    name: track.name?.simpleText || track.languageCode,
  }));
}

function extractVideoMetadata(playerResponse: any, initialData: any): {
  title: string;
  channel: string;
  duration: string;
  viewCount?: string;
  description?: string;
} {
  const videoDetails = playerResponse?.videoDetails || {};
  
  let duration = 'Unknown';
  const lengthSeconds = parseInt(videoDetails.lengthSeconds, 10);
  if (!isNaN(lengthSeconds)) {
    const hours = Math.floor(lengthSeconds / 3600);
    const minutes = Math.floor((lengthSeconds % 3600) / 60);
    const seconds = lengthSeconds % 60;
    
    if (hours > 0) {
      duration = `${hours}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    } else {
      duration = `${minutes}:${seconds.toString().padStart(2, '0')}`;
    }
  }

  return {
    title: videoDetails.title || 'Unknown Title',
    channel: videoDetails.author || 'Unknown Channel',
    duration,
    viewCount: videoDetails.viewCount,
    description: videoDetails.shortDescription?.substring(0, 500),
  };
}

async function fetchTranscript(captionUrl: string): Promise<string> {
  const response = await fetch(captionUrl, {
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    },
  });

  if (!response.ok) {
    throw new YouTubeTranscriptError(
      `Failed to fetch transcript: ${response.status}`,
      'TRANSCRIPT_FETCH_ERROR'
    );
  }

  const xml = await response.text();
  return parseTranscriptXml(xml);
}

export async function extractYouTubeTranscript(url: string): Promise<YouTubeTranscriptResult> {
  const videoId = extractVideoId(url);
  
  const html = await fetchVideoPage(videoId);
  
  const playerResponse = extractPlayerResponse(html);
  const initialData = extractInitialData(html);
  
  const metadata = extractVideoMetadata(playerResponse, initialData);
  
  const captionTracks = extractCaptionTracks(playerResponse);
  
  if (captionTracks.length === 0) {
    throw new YouTubeTranscriptError(
      'No captions available for this video. The video may not have subtitles or they may be disabled.',
      'NO_CAPTIONS'
    );
  }

  const englishTrack = captionTracks.find(
    (t) => t.languageCode === 'en' || t.languageCode.startsWith('en-')
  );
  const selectedTrack = englishTrack || captionTracks[0];

  const transcript = await fetchTranscript(selectedTrack.baseUrl);

  if (!transcript) {
    throw new YouTubeTranscriptError(
      'Failed to parse transcript content',
      'PARSE_ERROR'
    );
  }

  return {
    title: metadata.title,
    transcript,
    metadata: {
      videoId,
      channel: metadata.channel,
      duration: metadata.duration,
      viewCount: metadata.viewCount,
      description: metadata.description,
    },
  };
}

export function isValidYouTubeUrl(url: string): boolean {
  try {
    extractVideoId(url);
    return true;
  } catch {
    return false;
  }
}
