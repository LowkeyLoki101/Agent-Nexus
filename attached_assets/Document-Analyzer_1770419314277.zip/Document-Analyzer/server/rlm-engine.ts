import OpenAI from "openai";
import type { SearchStep } from "@shared/schema";

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY || process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

export interface RLMContext {
  content: string;
  fileName: string;
  fileType: string;
  language: string | null;
}

export interface SearchResult {
  lineNumber?: number;
  content: string;
  relevance?: number;
}

type QueryIntent = "search" | "analysis" | "mixed";

interface IntentClassification {
  intent: QueryIntent;
  reasoning: string;
  focusHints: string[];
}

async function classifyIntent(question: string, contentPreview: string): Promise<IntentClassification> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: `You classify user questions about documents into three intent types:

1. "search" - User wants to FIND specific things (code, terms, functions, specific text)
   Examples: "Where is the login function?", "Find all API endpoints", "What line has the error?"

2. "analysis" - User wants to UNDERSTAND, SUMMARIZE, or get INSIGHTS about content
   Examples: "What patterns exist?", "Summarize this", "What are the main themes?", "Explain what this is about"

3. "mixed" - User wants both - find specific things AND understand them
   Examples: "Find the auth code and explain how it works", "What are the main functions and what do they do?"

Respond with JSON only:
{"intent": "search|analysis|mixed", "reasoning": "brief explanation", "focusHints": ["key topics to focus on"]}`
        },
        {
          role: "user",
          content: `Question: "${question}"\n\nDocument preview:\n${contentPreview.slice(0, 500)}`
        }
      ],
      max_completion_tokens: 200,
    });

    const content = response.choices[0]?.message?.content || "";
    const jsonMatch = content.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      return JSON.parse(jsonMatch[0]);
    }
  } catch (error) {
    console.error("Intent classification failed:", error);
  }

  return {
    intent: "mixed",
    reasoning: "Defaulting to mixed approach",
    focusHints: []
  };
}

function executeRegexSearch(content: string, pattern: string): SearchResult[] {
  const results: SearchResult[] = [];
  const lines = content.split("\n");

  try {
    const regex = new RegExp(pattern, "gi");
    lines.forEach((line, index) => {
      if (regex.test(line)) {
        results.push({
          lineNumber: index + 1,
          content: line.trim(),
        });
        regex.lastIndex = 0;
      }
    });
  } catch {
    const lowerPattern = pattern.toLowerCase();
    lines.forEach((line, index) => {
      if (line.toLowerCase().includes(lowerPattern)) {
        results.push({
          lineNumber: index + 1,
          content: line.trim(),
        });
      }
    });
  }

  return results.slice(0, 50);
}

function getContentChunk(content: string, startLine: number, endLine: number): string {
  const lines = content.split("\n");
  return lines.slice(startLine - 1, endLine).join("\n");
}

function chunkContent(content: string, chunkSize: number = 3000): string[] {
  const chunks: string[] = [];
  const lines = content.split("\n");
  let currentChunk: string[] = [];
  let currentSize = 0;

  for (const line of lines) {
    if (currentSize + line.length > chunkSize && currentChunk.length > 0) {
      chunks.push(currentChunk.join("\n"));
      currentChunk = [];
      currentSize = 0;
    }
    currentChunk.push(line);
    currentSize += line.length;
  }

  if (currentChunk.length > 0) {
    chunks.push(currentChunk.join("\n"));
  }

  return chunks;
}

function findCodeStructures(content: string, language: string | null): SearchResult[] {
  const results: SearchResult[] = [];
  const lines = content.split("\n");

  const patterns: Record<string, RegExp[]> = {
    javascript: [
      /^\s*(async\s+)?function\s+\w+/,
      /^\s*const\s+\w+\s*=\s*(async\s+)?\(/,
      /^\s*class\s+\w+/,
      /^\s*export\s+(default\s+)?(function|class|const)/,
    ],
    typescript: [
      /^\s*(async\s+)?function\s+\w+/,
      /^\s*const\s+\w+\s*=\s*(async\s+)?\(/,
      /^\s*class\s+\w+/,
      /^\s*export\s+(default\s+)?(function|class|const)/,
      /^\s*interface\s+\w+/,
      /^\s*type\s+\w+\s*=/,
    ],
    python: [
      /^\s*def\s+\w+\s*\(/,
      /^\s*class\s+\w+/,
      /^\s*async\s+def\s+\w+/,
    ],
    default: [
      /^\s*(function|def|class|interface|type|struct)\s+\w+/,
    ],
  };

  const langPatterns = patterns[language || ""] || patterns.default;

  lines.forEach((line, index) => {
    for (const pattern of langPatterns) {
      if (pattern.test(line)) {
        results.push({
          lineNumber: index + 1,
          content: line.trim(),
        });
        break;
      }
    }
  });

  return results;
}

async function* processAnalysisQuery(
  context: RLMContext,
  question: string,
  focusHints: string[]
): AsyncGenerator<{ type: "step" | "answer" | "complete" | "error"; data?: SearchStep | string; query?: any }> {
  const startTime = Date.now();
  const searchHistory: SearchStep[] = [];

  const chunks = chunkContent(context.content, 4000);
  const chunkSummaries: string[] = [];

  const step1: SearchStep = {
    depth: 1,
    action: "analyze",
    query: `Reading and understanding content (${chunks.length} sections)`,
    results: [{ content: `Document has ${context.content.length} characters, split into ${chunks.length} sections for analysis` }],
    reasoning: "Reading content to understand themes, patterns, and key ideas",
    duration: 0,
  };
  searchHistory.push(step1);
  yield { type: "step", data: step1 };

  const maxChunksToAnalyze = Math.min(chunks.length, 5);

  for (let i = 0; i < maxChunksToAnalyze; i++) {
    const chunkStartTime = Date.now();
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o-mini",
        messages: [
          {
            role: "system",
            content: `You are analyzing a section of a document to help answer a user's question.
Extract key themes, patterns, ideas, and relevant information.
Be concise but thorough. Focus on what's meaningful, not structural formatting.
${focusHints.length > 0 ? `Pay special attention to: ${focusHints.join(", ")}` : ""}`
          },
          {
            role: "user",
            content: `Question: "${question}"\n\nSection ${i + 1} of ${chunks.length}:\n\n${chunks[i]}\n\nSummarize key points relevant to the question.`
          }
        ],
        max_completion_tokens: 500,
      });

      const summary = response.choices[0]?.message?.content || "";
      chunkSummaries.push(summary);

      const stepN: SearchStep = {
        depth: i + 2,
        action: "read",
        query: `Analyzing section ${i + 1} of ${maxChunksToAnalyze}`,
        results: [{ content: summary.slice(0, 200) + (summary.length > 200 ? "..." : "") }],
        reasoning: `Understanding content in section ${i + 1}`,
        duration: Date.now() - chunkStartTime,
      };
      searchHistory.push(stepN);
      yield { type: "step", data: stepN };

    } catch (error) {
      console.error(`Error analyzing chunk ${i}:`, error);
    }
  }

  // RECURSIVE REFINEMENT LOOP - Multiple passes to build deep understanding
  let currentAnswer = "";
  let stepDepth = maxChunksToAnalyze + 2;
  const totalPasses = 7;

  // Pass 1: Document Identification - What IS this document?
  const docIdStartTime = Date.now();
  const docIdStep: SearchStep = {
    depth: stepDepth,
    action: "analyze",
    query: `Document identification (Pass 1 of ${totalPasses})`,
    results: [],
    reasoning: "Understanding what type of document this is",
    duration: 0,
  };
  searchHistory.push(docIdStep);
  yield { type: "step", data: docIdStep };

  let documentContext = "";
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: `You are analyzing a document to understand its fundamental nature.
Determine:
1. **DOCUMENT TYPE**: What kind of document is this? (conversation, report, article, code, list, etc.)
2. **PURPOSE**: Why was this document created? What's its intended use?
3. **FORMAT**: How is the information structured? (chronological, categorical, narrative, etc.)
4. **SOURCE**: Where did this likely come from? (chat app, email, formal document, etc.)
5. **TIME PERIOD**: When does this document cover? Is it historical, recent, ongoing?

Be specific and concise.`
        },
        {
          role: "user",
          content: `Analyze this document:

File: "${context.fileName}" (${context.fileType})

Content samples:
${chunkSummaries.slice(0, 3).map((s, i) => `--- Sample ${i + 1} ---\n${s}`).join("\n\n")}

What type of document is this?`
        }
      ],
      max_completion_tokens: 500,
    });

    documentContext = response.choices[0]?.message?.content || "";
  } catch (error) {
    documentContext = "Unable to identify document type";
  }

  docIdStep.duration = Date.now() - docIdStartTime;
  docIdStep.results = [{ content: documentContext.slice(0, 250) + "..." }];

  // Pass 2: Participants & Speakers - Who is involved?
  stepDepth++;
  const participantsStartTime = Date.now();
  const participantsStep: SearchStep = {
    depth: stepDepth,
    action: "analyze",
    query: `Participants & speakers (Pass 2 of ${totalPasses})`,
    results: [],
    reasoning: "Identifying who is involved and their roles",
    duration: 0,
  };
  searchHistory.push(participantsStep);
  yield { type: "step", data: participantsStep };

  let participants = "";
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: `You are identifying all participants, speakers, or contributors in a document.
For each person/entity found, determine:
1. **NAME/IDENTIFIER**: Who are they?
2. **ROLE**: What is their role? (sender, receiver, author, subject, customer, employee, etc.)
3. **RELATIONSHIP**: How do they relate to others in the document?
4. **FREQUENCY**: How often do they appear? (primary speaker, occasional mention, etc.)

If this is a conversation, identify who is speaking to whom.
If this is a report, identify authors, subjects, and stakeholders.`
        },
        {
          role: "user",
          content: `Document type: ${documentContext.slice(0, 200)}

Content:
${chunkSummaries.map((s, i) => `--- Section ${i + 1} ---\n${s}`).join("\n\n")}

Who are the participants, speakers, or key people involved?`
        }
      ],
      max_completion_tokens: 800,
    });

    participants = response.choices[0]?.message?.content || "";
  } catch (error) {
    participants = "Unable to identify participants";
  }

  participantsStep.duration = Date.now() - participantsStartTime;
  participantsStep.results = [{ content: participants.slice(0, 250) + "..." }];

  // Pass 3: Topics & Themes - What are they talking about?
  stepDepth++;
  const topicsStartTime = Date.now();
  const topicsStep: SearchStep = {
    depth: stepDepth,
    action: "analyze",
    query: `Topics & themes (Pass 3 of ${totalPasses})`,
    results: [],
    reasoning: "Understanding what subjects are discussed",
    duration: 0,
  };
  searchHistory.push(topicsStep);
  yield { type: "step", data: topicsStep };

  let topics = "";
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: `You are analyzing the topics, themes, and subject matter of a document.
Identify:
1. **MAIN TOPICS**: What are the primary subjects discussed?
2. **RECURRING THEMES**: What patterns or themes repeat throughout?
3. **KEY ACTIVITIES**: What actions, events, or processes are described?
4. **DOMAIN/INDUSTRY**: What field or area does this relate to?
5. **CONTEXT CLUES**: What background knowledge helps understand this content?

Think about what someone would need to know to fully understand this document.`
        },
        {
          role: "user",
          content: `Document type: ${documentContext.slice(0, 200)}
Participants: ${participants.slice(0, 300)}

Content:
${chunkSummaries.map((s, i) => `--- Section ${i + 1} ---\n${s}`).join("\n\n")}

What topics and themes are present?`
        }
      ],
      max_completion_tokens: 800,
    });

    topics = response.choices[0]?.message?.content || "";
  } catch (error) {
    topics = "Unable to identify topics";
  }

  topicsStep.duration = Date.now() - topicsStartTime;
  topicsStep.results = [{ content: topics.slice(0, 250) + "..." }];

  // Pass 4: Entity Extraction - Specific data points
  stepDepth++;
  const extractionStartTime = Date.now();
  const extractionStep: SearchStep = {
    depth: stepDepth,
    action: "analyze",
    query: `Entity extraction (Pass 4 of ${totalPasses})`,
    results: [],
    reasoning: "Extracting names, numbers, dates, and key items",
    duration: 0,
  };
  searchHistory.push(extractionStep);
  yield { type: "step", data: extractionStep };

  let extractedEntities = "";
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: `You are extracting structured data from document content.
Extract and list ALL of the following found in the content:

**PEOPLE**: Names of individuals mentioned
**PLACES**: Locations, addresses, cities, countries
**ORGANIZATIONS**: Companies, teams, groups
**DATES/TIMES**: Any dates, times, schedules, deadlines
**NUMBERS**: Quantities, prices, percentages, measurements, phone numbers
**KEY ITEMS**: Products, topics, important nouns, action items

Format as organized lists. Be thorough - capture everything mentioned.`
        },
        {
          role: "user",
          content: `Extract all entities from this document:

${chunkSummaries.map((s, i) => `--- Section ${i + 1} ---\n${s}`).join("\n\n")}

List everything found in organized categories.`
        }
      ],
      max_completion_tokens: 1500,
    });

    extractedEntities = response.choices[0]?.message?.content || "";
  } catch (error) {
    extractedEntities = `Error extracting entities: ${error instanceof Error ? error.message : "Unknown error"}`;
  }

  extractionStep.duration = Date.now() - extractionStartTime;
  extractionStep.results = [{ content: extractedEntities.slice(0, 300) + "..." }];

  // Pass 5: Initial synthesis using all context
  stepDepth++;
  const synthesisStartTime = Date.now();
  const synthesisStep: SearchStep = {
    depth: stepDepth,
    action: "refine",
    query: `Initial synthesis (Pass 5 of ${totalPasses})`,
    results: [],
    reasoning: "Creating first answer using full context",
    duration: 0,
  };
  searchHistory.push(synthesisStep);
  yield { type: "step", data: synthesisStep };

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `You are providing an initial answer based on comprehensive document analysis.
You have deep context about:
- What type of document this is
- Who the participants/speakers are
- What topics and themes are present
- Specific entities (names, dates, numbers)

Synthesize all this context to answer the question. Focus on capturing the main points.
You will have a chance to refine this answer, so don't worry about perfection yet.`
        },
        {
          role: "user",
          content: `Question: "${question}"

DOCUMENT CONTEXT:
${documentContext}

PARTICIPANTS & SPEAKERS:
${participants}

TOPICS & THEMES:
${topics}

EXTRACTED ENTITIES:
${extractedEntities}

Using all this context, provide your initial answer.`
        }
      ],
      max_completion_tokens: 1000,
    });

    currentAnswer = response.choices[0]?.message?.content || "";
  } catch (error) {
    currentAnswer = `Error in initial synthesis: ${error instanceof Error ? error.message : "Unknown error"}`;
  }

  synthesisStep.duration = Date.now() - synthesisStartTime;
  synthesisStep.results = [{ content: currentAnswer.slice(0, 150) + "..." }];

  // Pass 6: Self-critique and identify gaps
  stepDepth++;
  const critiqueStartTime = Date.now();
  const critiqueStep: SearchStep = {
    depth: stepDepth,
    action: "analyze",
    query: `Self-critique (Pass 6 of ${totalPasses})`,
    results: [],
    reasoning: "Identifying gaps, errors, and areas to improve",
    duration: 0,
  };
  searchHistory.push(critiqueStep);
  yield { type: "step", data: critiqueStep };

  let critique = "";
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: `You are critically reviewing an answer. Identify:
1. What important points were missed?
2. What could be explained more clearly?
3. What patterns or connections weren't mentioned?
4. Is the answer actually addressing the question?
Be specific and constructive.`
        },
        {
          role: "user",
          content: `Original question: "${question}"

Current answer:
${currentAnswer}

Source material summaries:
${chunkSummaries.map((s, i) => `Section ${i + 1}: ${s.slice(0, 300)}`).join("\n")}

What's missing or could be improved?`
        }
      ],
      max_completion_tokens: 500,
    });

    critique = response.choices[0]?.message?.content || "";
  } catch (error) {
    critique = "Unable to generate critique";
  }

  critiqueStep.duration = Date.now() - critiqueStartTime;
  critiqueStep.results = [{ content: critique.slice(0, 200) + "..." }];

  // Pass 7: Final refined answer incorporating all context and critique
  stepDepth++;
  const refineStartTime = Date.now();
  const refineStep: SearchStep = {
    depth: stepDepth,
    action: "refine",
    query: `Final refinement (Pass 7 of ${totalPasses})`,
    results: [],
    reasoning: "Producing best answer using all gathered context",
    duration: 0,
  };
  searchHistory.push(refineStep);
  yield { type: "step", data: refineStep };

  let finalAnswer = "";
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `You are providing the FINAL, refined answer after comprehensive document analysis.

You have gathered:
- Document identification (what type of document this is)
- Participant analysis (who is involved and their roles)
- Topic and theme analysis (what subjects are discussed)
- Entity extraction (specific names, dates, numbers)
- Initial answer synthesis
- Self-critique identifying gaps

Now produce the best possible answer that:
1. Addresses all points in the critique
2. Uses specific names, dates, and numbers accurately
3. Reflects understanding of who the participants are and their relationships
4. Shows awareness of the document's purpose and context
5. Is comprehensive, insightful, and well-organized`
        },
        {
          role: "user",
          content: `Question: "${question}"

DOCUMENT CONTEXT:
${documentContext}

PARTICIPANTS:
${participants}

TOPICS & THEMES:
${topics}

EXTRACTED ENTITIES:
${extractedEntities}

Your initial answer:
${currentAnswer}

Your self-critique:
${critique}

Now provide your final, improved answer that synthesizes all this understanding.`
        }
      ],
      max_completion_tokens: 1500,
    });

    finalAnswer = response.choices[0]?.message?.content || currentAnswer;
  } catch (error) {
    finalAnswer = currentAnswer || `Error: ${error instanceof Error ? error.message : "Unknown error"}`;
  }

  refineStep.duration = Date.now() - refineStartTime;

  // Stream the final answer
  const words = finalAnswer.split(" ");
  for (let i = 0; i < words.length; i += 3) {
    const chunk = words.slice(i, i + 3).join(" ") + " ";
    yield { type: "answer", data: chunk };
    await new Promise((r) => setTimeout(r, 20));
  }

  const totalDuration = Date.now() - startTime;
  yield {
    type: "complete",
    query: {
      answer: finalAnswer,
      searchHistory,
      status: "completed",
      totalDepth: searchHistory.length,
      totalDuration,
    },
  };
}

async function* processSearchQuery(
  context: RLMContext,
  question: string
): AsyncGenerator<{ type: "step" | "answer" | "complete" | "error"; data?: SearchStep | string; query?: any }> {
  const startTime = Date.now();
  const searchHistory: SearchStep[] = [];
  let depth = 0;
  const maxDepth = 5;

  const systemPrompt = `You are an AI assistant searching through a ${context.fileType} file${context.language ? ` written in ${context.language}` : ""}.
The file is named "${context.fileName}" and contains ${context.content.length} characters.

Your job is to FIND specific content the user is asking about.

Available tools:
1. SEARCH(pattern) - Search for a regex pattern
2. READ(startLine, endLine) - Read specific lines
3. ANSWER(response) - Provide the final answer with what you found

Respond with JSON:
- To search: {"action": "search", "pattern": "regex-pattern", "reasoning": "why"}
- To read: {"action": "read", "startLine": N, "endLine": M, "reasoning": "why"}
- To answer: {"action": "answer", "content": "what you found and where"}

Search efficiently. Find the specific content the user wants.`;

  const messages: OpenAI.ChatCompletionMessageParam[] = [
    { role: "system", content: systemPrompt },
    {
      role: "user",
      content: `File preview (first 2000 chars):\n\n${context.content.slice(0, 2000)}\n\n---\n\nFind: ${question}\n\nStart searching. Respond with a JSON action.`,
    },
  ];

  let currentAnswer = "";

  while (depth < maxDepth) {
    depth++;
    const stepStartTime = Date.now();

    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages,
        max_completion_tokens: 1024,
      });

      const content = response.choices[0]?.message?.content || "";
      messages.push({ role: "assistant", content });

      let action: any;
      try {
        const jsonMatch = content.match(/\{[\s\S]*\}/);
        if (jsonMatch) {
          action = JSON.parse(jsonMatch[0]);
        }
      } catch {
        action = { action: "answer", content };
      }

      const stepDuration = Date.now() - stepStartTime;

      if (action.action === "search") {
        const results = executeRegexSearch(context.content, action.pattern);
        const step: SearchStep = {
          depth,
          action: "search",
          pattern: action.pattern,
          query: action.reasoning || `Searching for: ${action.pattern}`,
          results,
          reasoning: action.reasoning,
          duration: stepDuration,
        };
        searchHistory.push(step);
        yield { type: "step", data: step };

        messages.push({
          role: "user",
          content: `Search results for "${action.pattern}":\n${results
            .slice(0, 10)
            .map((r) => `L${r.lineNumber}: ${r.content}`)
            .join("\n")}\n\n${results.length > 10 ? `(${results.length - 10} more results)` : ""}\n\nContinue searching or provide your answer.`,
        });
      } else if (action.action === "read") {
        const chunk = getContentChunk(
          context.content,
          action.startLine || 1,
          action.endLine || 50
        );
        const results: SearchResult[] = [{ content: chunk }];
        const step: SearchStep = {
          depth,
          action: "read",
          query: action.reasoning || `Reading lines ${action.startLine}-${action.endLine}`,
          results,
          reasoning: action.reasoning,
          duration: stepDuration,
        };
        searchHistory.push(step);
        yield { type: "step", data: step };

        messages.push({
          role: "user",
          content: `Lines ${action.startLine}-${action.endLine}:\n\n${chunk}\n\nContinue or provide your answer.`,
        });
      } else if (action.action === "answer" || depth >= maxDepth) {
        currentAnswer = action.content || content;

        const step: SearchStep = {
          depth,
          action: "refine",
          query: "Providing answer",
          results: [],
          reasoning: "Summarizing what was found",
          duration: stepDuration,
        };
        searchHistory.push(step);
        yield { type: "step", data: step };

        const words = currentAnswer.split(" ");
        for (let i = 0; i < words.length; i += 3) {
          const chunk = words.slice(i, i + 3).join(" ") + " ";
          yield { type: "answer", data: chunk };
          await new Promise((r) => setTimeout(r, 30));
        }

        break;
      }
    } catch (error) {
      yield {
        type: "error",
        data: error instanceof Error ? error.message : "Unknown error occurred",
      };
      break;
    }
  }

  const totalDuration = Date.now() - startTime;
  const maxDepthReached = Math.max(...searchHistory.map((s) => s.depth), 0);

  yield {
    type: "complete",
    query: {
      answer: currentAnswer,
      searchHistory,
      status: "completed",
      totalDepth: maxDepthReached,
      totalDuration,
    },
  };
}

export async function* processRLMQuery(
  context: RLMContext,
  question: string
): AsyncGenerator<{ type: "step" | "answer" | "complete" | "error"; data?: SearchStep | string; query?: any }> {
  
  const intentStep: SearchStep = {
    depth: 0,
    action: "analyze",
    query: "Understanding your question...",
    results: [],
    reasoning: "Determining the best approach to answer",
    duration: 0,
  };

  const intentStartTime = Date.now();
  const classification = await classifyIntent(question, context.content.slice(0, 1000));
  intentStep.duration = Date.now() - intentStartTime;
  intentStep.results = [{ 
    content: `Intent: ${classification.intent} - ${classification.reasoning}` 
  }];

  yield { type: "step", data: intentStep };

  if (classification.intent === "analysis") {
    yield* processAnalysisQuery(context, question, classification.focusHints);
  } else if (classification.intent === "search") {
    yield* processSearchQuery(context, question);
  } else {
    const searchResults: SearchResult[] = [];
    const searchStep: SearchStep = {
      depth: 1,
      action: "search",
      query: "Quick scan for relevant content",
      pattern: classification.focusHints.join("|") || question.split(" ").slice(0, 3).join("|"),
      results: [],
      reasoning: "Finding relevant sections before analysis",
      duration: 0,
    };
    
    const searchStartTime = Date.now();
    const pattern = classification.focusHints.join("|") || question.split(" ").slice(0, 3).join("|");
    const results = executeRegexSearch(context.content, pattern);
    searchStep.results = results.slice(0, 10);
    searchStep.duration = Date.now() - searchStartTime;
    
    yield { type: "step", data: searchStep };

    yield* processAnalysisQuery(context, question, classification.focusHints);
  }
}
