import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { processRLMQuery } from "./rlm-engine";
import { insertDocumentSchema, insertQuerySchema } from "@shared/schema";
import { z } from "zod";
import { extractYouTubeTranscript, YouTubeTranscriptError } from "./youtube-import";
import { scrapeWebsite, WebsiteScraperError } from "./website-import";
import JSZip from "jszip";

const youtubeImportSchema = z.object({
  url: z.string().url(),
});

const websiteImportSchema = z.object({
  url: z.string().url(),
  maxPages: z.number().min(1).max(50).optional(),
  maxDepth: z.number().min(1).max(5).optional(),
});

const zipImportSchema = z.object({
  data: z.string(), // base64 encoded zip file
  filename: z.string(),
});

// Helper to detect file type from extension
function detectFileType(filename: string): string {
  const ext = filename.split(".").pop()?.toLowerCase();
  if (ext === "json") return "json";
  if (ext === "md" || ext === "markdown") return "markdown";
  const codeExtensions = [
    "js", "jsx", "ts", "tsx", "py", "rb", "go", "rs", "java",
    "cpp", "c", "cs", "php", "swift", "kt", "scala", "sql",
    "sh", "bash", "zsh", "vue", "svelte", "html", "css", "scss", "less",
  ];
  if (codeExtensions.includes(ext || "")) return "code";
  return "text";
}

// Helper to detect language from extension
function detectLanguage(filename: string): string | null {
  const ext = filename.split(".").pop()?.toLowerCase();
  const languageMap: Record<string, string> = {
    js: "javascript", jsx: "javascript", ts: "typescript", tsx: "typescript",
    py: "python", rb: "ruby", go: "go", rs: "rust", java: "java",
    cpp: "cpp", c: "c", cs: "csharp", php: "php", swift: "swift",
    kt: "kotlin", scala: "scala", sql: "sql", sh: "bash", bash: "bash",
    zsh: "zsh", yml: "yaml", yaml: "yaml", json: "json", xml: "xml",
    html: "html", css: "css", scss: "scss", less: "less", md: "markdown",
    vue: "vue", svelte: "svelte",
  };
  return languageMap[ext || ""] || null;
}

// Allowed extensions for zip extraction
const ALLOWED_EXTENSIONS = new Set([
  "txt", "md", "markdown", "json", "xml", "yaml", "yml", "csv",
  "js", "jsx", "ts", "tsx", "py", "rb", "go", "rs", "java",
  "cpp", "c", "h", "hpp", "cs", "php", "swift", "kt", "scala",
  "sql", "sh", "bash", "zsh", "vue", "svelte", "html", "css",
  "scss", "less", "env", "gitignore", "dockerfile", "makefile",
]);

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Document routes
  app.get("/api/documents", async (req: Request, res: Response) => {
    try {
      const documents = await storage.getAllDocuments();
      res.json(documents);
    } catch (error) {
      console.error("Error fetching documents:", error);
      res.status(500).json({ error: "Failed to fetch documents" });
    }
  });

  app.get("/api/documents/:id", async (req: Request, res: Response) => {
    try {
      const idParam = req.params.id;
      const id = parseInt(Array.isArray(idParam) ? idParam[0] : idParam);
      const document = await storage.getDocument(id);
      if (!document) {
        return res.status(404).json({ error: "Document not found" });
      }
      res.json(document);
    } catch (error) {
      console.error("Error fetching document:", error);
      res.status(500).json({ error: "Failed to fetch document" });
    }
  });

  app.post("/api/documents", async (req: Request, res: Response) => {
    try {
      const validated = insertDocumentSchema.parse(req.body);
      const document = await storage.createDocument(validated);
      res.status(201).json(document);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      console.error("Error creating document:", error);
      res.status(500).json({ error: "Failed to create document" });
    }
  });

  app.delete("/api/documents/:id", async (req: Request, res: Response) => {
    try {
      const idParam = req.params.id;
      const id = parseInt(Array.isArray(idParam) ? idParam[0] : idParam);
      await storage.deleteDocument(id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting document:", error);
      res.status(500).json({ error: "Failed to delete document" });
    }
  });

  // Query request validation schema
  const queryRequestSchema = z.object({
    documentId: z.number(),
    question: z.string().min(1).max(2000),
  });

  // Query routes with streaming
  app.post("/api/queries", async (req: Request, res: Response) => {
    try {
      // Validate request body with Zod
      const parseResult = queryRequestSchema.safeParse(req.body);
      if (!parseResult.success) {
        return res.status(400).json({ error: parseResult.error.errors });
      }
      const { documentId, question } = parseResult.data;

      const document = await storage.getDocument(documentId);
      if (!document) {
        return res.status(404).json({ error: "Document not found" });
      }

      // Create query record
      const query = await storage.createQuery({ documentId, question });
      await storage.updateQuery(query.id, { status: "processing" });

      // Set up SSE
      res.setHeader("Content-Type", "text/event-stream");
      res.setHeader("Cache-Control", "no-cache");
      res.setHeader("Connection", "keep-alive");

      // Track client disconnect
      let clientDisconnected = false;
      req.on("close", () => {
        clientDisconnected = true;
      });

      // Process with RLM engine
      const context = {
        content: document.content,
        fileName: document.name,
        fileType: document.type,
        language: document.language,
      };

      let fullAnswer = "";

      for await (const event of processRLMQuery(context, question)) {
        // Stop processing if client disconnected
        if (clientDisconnected) {
          await storage.updateQuery(query.id, { status: "error" });
          break;
        }

        if (event.type === "step") {
          res.write(`data: ${JSON.stringify({ type: "step", data: event.data })}\n\n`);
        } else if (event.type === "answer") {
          fullAnswer += event.data;
          res.write(`data: ${JSON.stringify({ type: "answer", data: event.data })}\n\n`);
        } else if (event.type === "complete") {
          // Update query with final results
          const queryData = event.query as any;
          const updatedQuery = await storage.updateQuery(query.id, {
            answer: queryData.answer,
            searchHistory: queryData.searchHistory,
            status: "completed",
            totalDepth: queryData.totalDepth,
            totalDuration: queryData.totalDuration,
          });
          res.write(`data: ${JSON.stringify({ type: "complete", query: updatedQuery })}\n\n`);
        } else if (event.type === "error") {
          await storage.updateQuery(query.id, { status: "error" });
          res.write(`data: ${JSON.stringify({ type: "error", message: event.data })}\n\n`);
        }
      }

      res.end();
    } catch (error) {
      console.error("Error processing query:", error);
      if (!res.headersSent) {
        res.status(500).json({ error: "Failed to process query" });
      } else {
        res.write(`data: ${JSON.stringify({ type: "error", message: "Query processing failed" })}\n\n`);
        res.end();
      }
    }
  });

  // Multi-document query validation schema
  const multiQueryRequestSchema = z.object({
    documentIds: z.array(z.number()).min(1),
    question: z.string().min(1).max(2000),
  });

  // Multi-document query route with streaming
  app.post("/api/queries/multi", async (req: Request, res: Response) => {
    try {
      const parseResult = multiQueryRequestSchema.safeParse(req.body);
      if (!parseResult.success) {
        return res.status(400).json({ error: parseResult.error.errors });
      }
      const { documentIds, question } = parseResult.data;

      // Fetch all documents
      const docs = await Promise.all(documentIds.map(id => storage.getDocument(id)));
      const validDocs = docs.filter((d): d is NonNullable<typeof d> => d !== undefined);
      
      if (validDocs.length === 0) {
        return res.status(404).json({ error: "No valid documents found" });
      }

      // Create query record (use first document for now)
      const query = await storage.createQuery({ documentId: validDocs[0].id, question });
      await storage.updateQuery(query.id, { status: "processing" });

      // Set up SSE
      res.setHeader("Content-Type", "text/event-stream");
      res.setHeader("Cache-Control", "no-cache");
      res.setHeader("Connection", "keep-alive");

      let clientDisconnected = false;
      req.on("close", () => {
        clientDisconnected = true;
      });

      // Combine all document content with markers
      const combinedContent = validDocs.map(doc => 
        `=== DOCUMENT: ${doc.name} (${doc.type}) ===\n${doc.content}\n=== END DOCUMENT ===`
      ).join("\n\n");

      const context = {
        content: combinedContent,
        fileName: validDocs.length === 1 ? validDocs[0].name : `${validDocs.length} documents`,
        fileType: validDocs.length === 1 ? validDocs[0].type : "multiple",
        language: validDocs.length === 1 ? validDocs[0].language : null,
      };

      for await (const event of processRLMQuery(context, question)) {
        if (clientDisconnected) {
          await storage.updateQuery(query.id, { status: "error" });
          break;
        }

        if (event.type === "step") {
          res.write(`data: ${JSON.stringify({ type: "step", data: event.data })}\n\n`);
        } else if (event.type === "answer") {
          res.write(`data: ${JSON.stringify({ type: "answer", data: event.data })}\n\n`);
        } else if (event.type === "complete") {
          const queryData = event.query as any;
          const updatedQuery = await storage.updateQuery(query.id, {
            answer: queryData.answer,
            searchHistory: queryData.searchHistory,
            status: "completed",
            totalDepth: queryData.totalDepth,
            totalDuration: queryData.totalDuration,
          });
          res.write(`data: ${JSON.stringify({ type: "complete", query: updatedQuery })}\n\n`);
        } else if (event.type === "error") {
          await storage.updateQuery(query.id, { status: "error" });
          res.write(`data: ${JSON.stringify({ type: "error", message: event.data })}\n\n`);
        }
      }

      res.end();
    } catch (error) {
      console.error("Error processing multi-document query:", error);
      if (!res.headersSent) {
        res.status(500).json({ error: "Failed to process query" });
      } else {
        res.write(`data: ${JSON.stringify({ type: "error", message: "Query processing failed" })}\n\n`);
        res.end();
      }
    }
  });

  // Get queries for a document
  app.get("/api/documents/:id/queries", async (req: Request, res: Response) => {
    try {
      const idParam = req.params.id;
      const documentId = parseInt(Array.isArray(idParam) ? idParam[0] : idParam);
      const queries = await storage.getQueriesByDocument(documentId);
      res.json(queries);
    } catch (error) {
      console.error("Error fetching queries:", error);
      res.status(500).json({ error: "Failed to fetch queries" });
    }
  });

  // YouTube import route
  app.post("/api/import/youtube", async (req: Request, res: Response) => {
    try {
      const validated = youtubeImportSchema.parse(req.body);
      
      const result = await extractYouTubeTranscript(validated.url);
      
      const document = await storage.createDocument({
        name: result.title,
        content: result.transcript,
        type: "text",
        size: result.transcript.length,
        sourceType: "youtube",
        sourceUrl: validated.url,
        sourceTitle: result.title,
      });
      
      res.status(201).json(document);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      if (error instanceof YouTubeTranscriptError) {
        return res.status(400).json({ error: error.message, code: error.code });
      }
      console.error("Error importing YouTube video:", error);
      res.status(500).json({ error: "Failed to import YouTube video" });
    }
  });

  // Website import route
  app.post("/api/import/website", async (req: Request, res: Response) => {
    try {
      const validated = websiteImportSchema.parse(req.body);
      
      const result = await scrapeWebsite(validated.url, {
        maxPages: validated.maxPages,
        maxDepth: validated.maxDepth,
      });
      
      const document = await storage.createDocument({
        name: result.title,
        content: result.content,
        type: "text",
        size: result.content.length,
        sourceType: "website",
        sourceUrl: validated.url,
        sourceTitle: result.title,
      });
      
      res.status(201).json(document);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      if (error instanceof WebsiteScraperError) {
        return res.status(400).json({ error: error.message, code: error.code });
      }
      console.error("Error importing website:", error);
      res.status(500).json({ error: "Failed to import website" });
    }
  });

  // Zip file import route
  app.post("/api/import/zip", async (req: Request, res: Response) => {
    try {
      const validated = zipImportSchema.parse(req.body);
      
      // Decode base64 data
      const buffer = Buffer.from(validated.data, "base64");
      
      // Load the zip file
      const zip = await JSZip.loadAsync(buffer);
      
      const createdDocuments: any[] = [];
      const skippedFiles: string[] = [];
      const errors: string[] = [];
      
      // Process each file in the zip
      const filePromises: Promise<void>[] = [];
      
      zip.forEach((relativePath, zipEntry) => {
        // Skip directories and hidden files
        if (zipEntry.dir || relativePath.startsWith("__MACOSX") || relativePath.startsWith(".")) {
          return;
        }
        
        // Get file extension
        const ext = relativePath.split(".").pop()?.toLowerCase() || "";
        const filename = relativePath.split("/").pop() || relativePath;
        
        // Skip files without allowed extensions
        if (!ALLOWED_EXTENSIONS.has(ext)) {
          skippedFiles.push(relativePath);
          return;
        }
        
        filePromises.push(
          (async () => {
            try {
              const content = await zipEntry.async("text");
              
              // Skip empty files or binary content that couldn't be decoded
              if (!content || content.length === 0) {
                skippedFiles.push(relativePath);
                return;
              }
              
              // Skip files that look like binary (contain null bytes)
              if (content.includes("\0")) {
                skippedFiles.push(relativePath);
                return;
              }
              
              const type = detectFileType(filename);
              const language = detectLanguage(filename);
              
              const document = await storage.createDocument({
                name: relativePath, // Use full path for context
                content,
                type,
                size: content.length,
                language,
                sourceType: "zip",
                sourceTitle: validated.filename,
              });
              
              createdDocuments.push(document);
            } catch (err) {
              errors.push(`Failed to process ${relativePath}`);
            }
          })()
        );
      });
      
      await Promise.all(filePromises);
      
      if (createdDocuments.length === 0) {
        return res.status(400).json({ 
          error: "No valid files found in zip",
          skipped: skippedFiles.length,
        });
      }
      
      res.status(201).json({
        documents: createdDocuments,
        count: createdDocuments.length,
        skipped: skippedFiles.length,
        errors: errors.length,
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      console.error("Error importing zip:", error);
      res.status(500).json({ error: "Failed to import zip file" });
    }
  });

  return httpServer;
}
