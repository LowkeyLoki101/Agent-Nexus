interface ScrapedPage {
  url: string;
  title: string;
  content: string;
}

interface ScrapeResult {
  title: string;
  content: string;
  pages: ScrapedPage[];
  metadata: {
    url: string;
    domain: string;
    pagesScraped: number;
    maxDepthReached: number;
    scrapedAt: string;
  };
}

interface ScrapeOptions {
  maxPages?: number;
  maxDepth?: number;
  timeout?: number;
}

export class WebsiteScraperError extends Error {
  constructor(message: string, public code: string) {
    super(message);
    this.name = 'WebsiteScraperError';
  }
}

function isPrivateOrReservedHostname(hostname: string): boolean {
  const lowerHostname = hostname.toLowerCase();
  
  // Block localhost and common local hostnames
  if (lowerHostname === 'localhost' || 
      lowerHostname === 'localhost.localdomain' ||
      lowerHostname.endsWith('.localhost') ||
      lowerHostname.endsWith('.local') ||
      lowerHostname.endsWith('.internal')) {
    return true;
  }
  
  // Block cloud metadata endpoints
  const metadataHosts = [
    '169.254.169.254',  // AWS/GCP/Azure metadata
    'metadata.google.internal',
    'metadata.goog',
    '100.100.100.200',  // Alibaba Cloud
  ];
  if (metadataHosts.includes(lowerHostname)) {
    return true;
  }
  
  // Check for IP addresses
  const ipv4Match = hostname.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/);
  if (ipv4Match) {
    const [, a, b, c, d] = ipv4Match.map(Number);
    
    // Block private IP ranges (RFC 1918)
    if (a === 10) return true;  // 10.0.0.0/8
    if (a === 172 && b >= 16 && b <= 31) return true;  // 172.16.0.0/12
    if (a === 192 && b === 168) return true;  // 192.168.0.0/16
    
    // Block loopback (127.0.0.0/8)
    if (a === 127) return true;
    
    // Block link-local (169.254.0.0/16)
    if (a === 169 && b === 254) return true;
    
    // Block 0.0.0.0
    if (a === 0 && b === 0 && c === 0 && d === 0) return true;
    
    // Block broadcast
    if (a === 255 && b === 255 && c === 255 && d === 255) return true;
  }
  
  // Block IPv6 loopback and private ranges
  if (hostname === '::1' || 
      hostname.startsWith('fe80:') ||  // Link-local
      hostname.startsWith('fc') ||      // Unique local
      hostname.startsWith('fd')) {      // Unique local
    return true;
  }
  
  return false;
}

function validateUrl(url: string): URL {
  try {
    const parsed = new URL(url);
    if (!['http:', 'https:'].includes(parsed.protocol)) {
      throw new WebsiteScraperError(
        'Invalid URL protocol. Only HTTP and HTTPS are supported.',
        'INVALID_PROTOCOL'
      );
    }
    
    // SSRF protection: block internal/private/metadata URLs
    if (isPrivateOrReservedHostname(parsed.hostname)) {
      throw new WebsiteScraperError(
        'Cannot access internal or private network addresses.',
        'SSRF_BLOCKED'
      );
    }
    
    return parsed;
  } catch (error) {
    if (error instanceof WebsiteScraperError) {
      throw error;
    }
    throw new WebsiteScraperError(
      'Invalid URL format. Please provide a valid website URL.',
      'INVALID_URL'
    );
  }
}

function decodeHtmlEntities(text: string): string {
  return text
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&apos;/g, "'")
    .replace(/&nbsp;/g, ' ')
    .replace(/&#(\d+);/g, (_, code) => String.fromCharCode(parseInt(code, 10)))
    .replace(/&#x([0-9a-fA-F]+);/g, (_, code) => String.fromCharCode(parseInt(code, 16)));
}

function removeTagsWithContent(html: string, tags: string[]): string {
  let result = html;
  for (const tag of tags) {
    const regex = new RegExp(`<${tag}[^>]*>[\\s\\S]*?<\\/${tag}>`, 'gi');
    result = result.replace(regex, '');
  }
  return result;
}

function extractTitle(html: string): string {
  const titleMatch = html.match(/<title[^>]*>([^<]*)<\/title>/i);
  if (titleMatch && titleMatch[1]) {
    return decodeHtmlEntities(titleMatch[1].trim());
  }
  
  const h1Match = html.match(/<h1[^>]*>([^<]*)<\/h1>/i);
  if (h1Match && h1Match[1]) {
    return decodeHtmlEntities(h1Match[1].trim());
  }
  
  const ogTitleMatch = html.match(/<meta[^>]*property=["']og:title["'][^>]*content=["']([^"']+)["']/i);
  if (ogTitleMatch && ogTitleMatch[1]) {
    return decodeHtmlEntities(ogTitleMatch[1].trim());
  }
  
  return 'Untitled Page';
}

function extractHeadings(html: string): string[] {
  const headings: string[] = [];
  const headingRegex = /<(h[1-6])[^>]*>([\s\S]*?)<\/\1>/gi;
  let match;
  
  while ((match = headingRegex.exec(html)) !== null) {
    const level = match[1];
    const text = match[2]
      .replace(/<[^>]+>/g, '')
      .trim();
    if (text) {
      const prefix = '#'.repeat(parseInt(level[1]));
      headings.push(`${prefix} ${decodeHtmlEntities(text)}`);
    }
  }
  
  return headings;
}

function extractTextContent(html: string): string {
  let cleaned = html;
  
  const tagsToRemove = [
    'script', 'style', 'noscript', 'iframe', 'svg', 'canvas',
    'nav', 'footer', 'header', 'aside', 'form', 'button',
    'menu', 'menuitem', 'template'
  ];
  cleaned = removeTagsWithContent(cleaned, tagsToRemove);
  
  cleaned = cleaned.replace(/<!--[\s\S]*?-->/g, '');
  
  const headings = extractHeadings(cleaned);
  
  cleaned = cleaned.replace(/<br\s*\/?>/gi, '\n');
  cleaned = cleaned.replace(/<\/p>/gi, '\n\n');
  cleaned = cleaned.replace(/<\/div>/gi, '\n');
  cleaned = cleaned.replace(/<\/li>/gi, '\n');
  cleaned = cleaned.replace(/<\/h[1-6]>/gi, '\n\n');
  cleaned = cleaned.replace(/<\/tr>/gi, '\n');
  cleaned = cleaned.replace(/<\/td>/gi, ' | ');
  cleaned = cleaned.replace(/<\/th>/gi, ' | ');
  
  cleaned = cleaned.replace(/<[^>]+>/g, ' ');
  
  cleaned = decodeHtmlEntities(cleaned);
  
  cleaned = cleaned.replace(/[ \t]+/g, ' ');
  cleaned = cleaned.replace(/\n\s*\n\s*\n/g, '\n\n');
  cleaned = cleaned.split('\n').map(line => line.trim()).join('\n');
  cleaned = cleaned.trim();
  
  if (headings.length > 0) {
    const headingsSection = headings.join('\n');
    return `## Document Structure\n${headingsSection}\n\n## Content\n${cleaned}`;
  }
  
  return cleaned;
}

function extractLinks(html: string, baseUrl: URL): string[] {
  const links: string[] = [];
  const linkRegex = /<a[^>]+href=["']([^"'#]+)["'][^>]*>/gi;
  let match;
  
  while ((match = linkRegex.exec(html)) !== null) {
    try {
      const href = match[1];
      
      if (href.startsWith('javascript:') || 
          href.startsWith('mailto:') || 
          href.startsWith('tel:') ||
          href.startsWith('data:')) {
        continue;
      }
      
      const absoluteUrl = new URL(href, baseUrl);
      
      if (absoluteUrl.origin === baseUrl.origin) {
        const cleanUrl = `${absoluteUrl.origin}${absoluteUrl.pathname}`;
        if (!links.includes(cleanUrl)) {
          links.push(cleanUrl);
        }
      }
    } catch {
    }
  }
  
  return links;
}

async function fetchPage(url: string, timeout: number): Promise<string> {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeout);
  
  try {
    const response = await fetch(url, {
      signal: controller.signal,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9',
        'Accept-Encoding': 'gzip, deflate',
      },
    });
    
    if (!response.ok) {
      throw new WebsiteScraperError(
        `Failed to fetch page: ${response.status} ${response.statusText}`,
        'FETCH_ERROR'
      );
    }
    
    const contentType = response.headers.get('content-type') || '';
    if (!contentType.includes('text/html') && !contentType.includes('application/xhtml')) {
      throw new WebsiteScraperError(
        'URL does not point to an HTML page',
        'INVALID_CONTENT_TYPE'
      );
    }
    
    return await response.text();
  } catch (error) {
    if (error instanceof WebsiteScraperError) {
      throw error;
    }
    if (error instanceof Error && error.name === 'AbortError') {
      throw new WebsiteScraperError(
        `Request timeout after ${timeout}ms`,
        'TIMEOUT'
      );
    }
    throw new WebsiteScraperError(
      `Failed to fetch page: ${error instanceof Error ? error.message : 'Unknown error'}`,
      'FETCH_ERROR'
    );
  } finally {
    clearTimeout(timeoutId);
  }
}

export async function scrapeWebsite(
  url: string,
  options: ScrapeOptions = {}
): Promise<ScrapeResult> {
  const { maxPages = 10, maxDepth = 2, timeout = 10000 } = options;
  
  const baseUrl = validateUrl(url);
  
  const visited = new Set<string>();
  const pages: ScrapedPage[] = [];
  let maxDepthReached = 0;
  
  interface QueueItem {
    url: string;
    depth: number;
  }
  
  const queue: QueueItem[] = [{ url: url, depth: 0 }];
  
  while (queue.length > 0 && pages.length < maxPages) {
    const current = queue.shift();
    if (!current) break;
    
    const normalizedUrl = current.url.replace(/\/$/, '');
    
    if (visited.has(normalizedUrl)) {
      continue;
    }
    visited.add(normalizedUrl);
    
    try {
      const html = await fetchPage(current.url, timeout);
      const title = extractTitle(html);
      const content = extractTextContent(html);
      
      pages.push({
        url: current.url,
        title,
        content,
      });
      
      maxDepthReached = Math.max(maxDepthReached, current.depth);
      
      if (current.depth < maxDepth && pages.length < maxPages) {
        const links = extractLinks(html, new URL(current.url));
        
        for (const link of links) {
          const normalizedLink = link.replace(/\/$/, '');
          if (!visited.has(normalizedLink) && 
              !queue.some(q => q.url.replace(/\/$/, '') === normalizedLink)) {
            queue.push({ url: link, depth: current.depth + 1 });
          }
        }
      }
    } catch (error) {
      if (pages.length === 0) {
        throw error;
      }
      console.warn(`Failed to scrape ${current.url}:`, error);
    }
  }
  
  if (pages.length === 0) {
    throw new WebsiteScraperError(
      'Failed to scrape any pages from the website',
      'NO_CONTENT'
    );
  }
  
  const mainPage = pages[0];
  const allContent = pages.map(p => `### ${p.title}\n${p.content}`).join('\n\n---\n\n');
  
  return {
    title: mainPage.title,
    content: allContent,
    pages,
    metadata: {
      url: url,
      domain: baseUrl.hostname,
      pagesScraped: pages.length,
      maxDepthReached,
      scrapedAt: new Date().toISOString(),
    },
  };
}

export function isValidWebsiteUrl(url: string): boolean {
  try {
    validateUrl(url);
    return true;
  } catch {
    return false;
  }
}
