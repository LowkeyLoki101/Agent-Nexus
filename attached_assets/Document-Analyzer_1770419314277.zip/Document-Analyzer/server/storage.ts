import { eq, desc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/node-postgres";
import pg from "pg";
import type {
  User,
  InsertUser,
  Document,
  InsertDocument,
  Query,
  InsertQuery,
  SearchStep,
} from "@shared/schema";
import { users, documents, queries } from "@shared/schema";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  getDocument(id: number): Promise<Document | undefined>;
  getAllDocuments(): Promise<Document[]>;
  createDocument(doc: InsertDocument): Promise<Document>;
  deleteDocument(id: number): Promise<void>;

  getQuery(id: number): Promise<Query | undefined>;
  getQueriesByDocument(documentId: number): Promise<Query[]>;
  createQuery(query: InsertQuery): Promise<Query>;
  updateQuery(
    id: number,
    updates: Partial<{
      answer: string;
      searchHistory: SearchStep[];
      status: string;
      totalDepth: number;
      totalDuration: number;
    }>
  ): Promise<Query>;
}

const pool = new pg.Pool({
  connectionString: process.env.DATABASE_URL,
});

const db = drizzle(pool);

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username)).limit(1);
    return result[0];
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const result = await db.insert(users).values(insertUser).returning();
    return result[0];
  }

  async getDocument(id: number): Promise<Document | undefined> {
    const result = await db.select().from(documents).where(eq(documents.id, id)).limit(1);
    return result[0];
  }

  async getAllDocuments(): Promise<Document[]> {
    return db.select().from(documents).orderBy(desc(documents.createdAt));
  }

  async createDocument(doc: InsertDocument): Promise<Document> {
    const result = await db.insert(documents).values(doc).returning();
    return result[0];
  }

  async deleteDocument(id: number): Promise<void> {
    await db.delete(queries).where(eq(queries.documentId, id));
    await db.delete(documents).where(eq(documents.id, id));
  }

  async getQuery(id: number): Promise<Query | undefined> {
    const result = await db.select().from(queries).where(eq(queries.id, id)).limit(1);
    return result[0];
  }

  async getQueriesByDocument(documentId: number): Promise<Query[]> {
    return db.select().from(queries)
      .where(eq(queries.documentId, documentId))
      .orderBy(desc(queries.createdAt));
  }

  async createQuery(insertQuery: InsertQuery): Promise<Query> {
    const result = await db.insert(queries).values({
      ...insertQuery,
      status: "pending",
      totalDepth: 0,
    }).returning();
    return result[0];
  }

  async updateQuery(
    id: number,
    updates: Partial<{
      answer: string;
      searchHistory: SearchStep[];
      status: string;
      totalDepth: number;
      totalDuration: number;
    }>
  ): Promise<Query> {
    const result = await db.update(queries)
      .set(updates)
      .where(eq(queries.id, id))
      .returning();
    if (!result[0]) {
      throw new Error("Query not found");
    }
    return result[0];
  }
}

export const storage = new DatabaseStorage();
