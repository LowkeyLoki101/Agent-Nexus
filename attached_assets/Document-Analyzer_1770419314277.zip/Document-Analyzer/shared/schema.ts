import { sql } from "drizzle-orm";
import { pgTable, text, varchar, serial, integer, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table (kept from original)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Documents table - stores uploaded files/content for RLM processing
export const documents = pgTable("documents", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  content: text("content").notNull(),
  type: text("type").notNull(), // 'code', 'text', 'json', 'markdown'
  size: integer("size").notNull(),
  language: text("language"), // programming language if code
  sourceType: text("source_type").default("upload"), // 'upload', 'youtube', 'website'
  sourceUrl: text("source_url"), // original URL for YouTube/website sources
  sourceTitle: text("source_title"), // video title or page title
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
});

export const insertDocumentSchema = createInsertSchema(documents).omit({
  id: true,
  createdAt: true,
});

export type InsertDocument = z.infer<typeof insertDocumentSchema>;
export type Document = typeof documents.$inferSelect;

// Search step - represents one step in the recursive search
export const searchStepSchema = z.object({
  depth: z.number(),
  action: z.string(), // 'search', 'read', 'refine', 'analyze'
  pattern: z.string().optional(),
  query: z.string(),
  results: z.array(z.object({
    lineNumber: z.number().optional(),
    content: z.string(),
    relevance: z.number().optional(),
  })),
  reasoning: z.string().optional(),
  duration: z.number().optional(), // ms
});

export type SearchStep = z.infer<typeof searchStepSchema>;

// Queries table - stores user queries and their results
export const queries = pgTable("queries", {
  id: serial("id").primaryKey(),
  documentId: integer("document_id").notNull(),
  question: text("question").notNull(),
  answer: text("answer"),
  searchHistory: jsonb("search_history").$type<SearchStep[]>(),
  status: text("status").notNull().default("pending"), // 'pending', 'processing', 'completed', 'error'
  totalDepth: integer("total_depth").default(0),
  totalDuration: integer("total_duration"), // ms
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
});

export const insertQuerySchema = createInsertSchema(queries).omit({
  id: true,
  createdAt: true,
  answer: true,
  searchHistory: true,
  status: true,
  totalDepth: true,
  totalDuration: true,
});

export type InsertQuery = z.infer<typeof insertQuerySchema>;
export type Query = typeof queries.$inferSelect;

// Re-export chat models if needed
export * from "./models/chat";
