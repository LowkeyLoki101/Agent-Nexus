# Database Schema Reference

Complete database schema documentation for RLM Explorer.

## Overview

RLM Explorer uses PostgreSQL with Drizzle ORM. The schema is defined in `shared/schema.ts`.

## Entity Relationship Diagram

```
┌───────────────────────────────────────────────────────────────────┐
│                            users                                   │
├───────────────────────────────────────────────────────────────────┤
│ id         VARCHAR    PK   (UUID, auto-generated)                 │
│ username   TEXT       NOT NULL, UNIQUE                            │
│ password   TEXT       NOT NULL                                    │
└───────────────────────────────────────────────────────────────────┘


┌───────────────────────────────────────────────────────────────────┐
│                          documents                                 │
├───────────────────────────────────────────────────────────────────┤
│ id           SERIAL    PK   (auto-increment)                      │
│ name         TEXT      NOT NULL                                   │
│ content      TEXT      NOT NULL                                   │
│ type         TEXT      NOT NULL   ('code'|'text'|'json'|'md')     │
│ size         INTEGER   NOT NULL   (bytes)                         │
│ language     TEXT      NULLABLE   (programming language)          │
│ source_type  TEXT      DEFAULT 'upload'  ('upload'|'youtube'|     │
│                                           'website')              │
│ source_url   TEXT      NULLABLE   (original URL)                  │
│ source_title TEXT      NULLABLE   (video/page title)              │
│ created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP                  │
└───────────────────────────────────────────────────────────────────┘
                                    │
                                    │ 1:N
                                    ▼
┌───────────────────────────────────────────────────────────────────┐
│                           queries                                  │
├───────────────────────────────────────────────────────────────────┤
│ id              SERIAL    PK   (auto-increment)                   │
│ document_id     INTEGER   NOT NULL  (FK → documents.id)           │
│ question        TEXT      NOT NULL                                │
│ answer          TEXT      NULLABLE                                │
│ search_history  JSONB     NULLABLE  (Array<SearchStep>)           │
│ status          TEXT      DEFAULT 'pending'                       │
│                           ('pending'|'processing'|'completed'|    │
│                            'error')                               │
│ total_depth     INTEGER   DEFAULT 0                               │
│ total_duration  INTEGER   NULLABLE  (milliseconds)                │
│ created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP               │
└───────────────────────────────────────────────────────────────────┘
```

## Table Definitions

### users

Basic user authentication table.

```typescript
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});
```

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | VARCHAR | PK, UUID default | Unique user identifier |
| username | TEXT | NOT NULL, UNIQUE | Login username |
| password | TEXT | NOT NULL | Hashed password |

### documents

Stores uploaded/imported content for RLM processing.

```typescript
export const documents = pgTable("documents", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  content: text("content").notNull(),
  type: text("type").notNull(),
  size: integer("size").notNull(),
  language: text("language"),
  sourceType: text("source_type").default("upload"),
  sourceUrl: text("source_url"),
  sourceTitle: text("source_title"),
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
});
```

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | SERIAL | PK | Auto-increment identifier |
| name | TEXT | NOT NULL | Display name (filename or title) |
| content | TEXT | NOT NULL | Full document content |
| type | TEXT | NOT NULL | Content type: 'code', 'text', 'json', 'markdown' |
| size | INTEGER | NOT NULL | Content size in bytes |
| language | TEXT | NULLABLE | Programming language (if code) |
| source_type | TEXT | DEFAULT 'upload' | Source: 'upload', 'youtube', 'website' |
| source_url | TEXT | NULLABLE | Original URL for imported content |
| source_title | TEXT | NULLABLE | Original title (video/page title) |
| created_at | TIMESTAMP | NOT NULL, DEFAULT NOW | Creation timestamp |

### queries

Stores search queries and their results.

```typescript
export const queries = pgTable("queries", {
  id: serial("id").primaryKey(),
  documentId: integer("document_id").notNull(),
  question: text("question").notNull(),
  answer: text("answer"),
  searchHistory: jsonb("search_history").$type<SearchStep[]>(),
  status: text("status").notNull().default("pending"),
  totalDepth: integer("total_depth").default(0),
  totalDuration: integer("total_duration"),
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
});
```

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | SERIAL | PK | Auto-increment identifier |
| document_id | INTEGER | NOT NULL | Foreign key to documents |
| question | TEXT | NOT NULL | User's question |
| answer | TEXT | NULLABLE | Final answer (null until complete) |
| search_history | JSONB | NULLABLE | Array of SearchStep objects |
| status | TEXT | NOT NULL, DEFAULT 'pending' | Query status |
| total_depth | INTEGER | DEFAULT 0 | Max recursion depth reached |
| total_duration | INTEGER | NULLABLE | Total processing time (ms) |
| created_at | TIMESTAMP | NOT NULL, DEFAULT NOW | Creation timestamp |

## JSONB Types

### SearchStep

Stored in `queries.search_history` as a JSON array.

```typescript
interface SearchStep {
  depth: number;           // Recursion depth (0, 1, 2...)
  action: string;          // 'search' | 'read' | 'refine' | 'analyze'
  pattern?: string;        // Regex pattern used
  query: string;           // What we're searching for
  results: Array<{
    lineNumber?: number;   // Line number in document
    content: string;       // Matching content
    relevance?: number;    // 0-1 relevance score
  }>;
  reasoning?: string;      // AI's reasoning for this step
  duration?: number;       // Step duration in ms
}
```

## Zod Validation Schemas

### insertDocumentSchema

```typescript
export const insertDocumentSchema = createInsertSchema(documents).omit({
  id: true,
  createdAt: true,
});

// Validates:
{
  name: string,
  content: string,
  type: string,
  size: number,
  language?: string,
  sourceType?: string,
  sourceUrl?: string,
  sourceTitle?: string,
}
```

### insertQuerySchema

```typescript
export const insertQuerySchema = createInsertSchema(queries).omit({
  id: true,
  createdAt: true,
  answer: true,
  searchHistory: true,
  status: true,
  totalDepth: true,
  totalDuration: true,
});

// Validates:
{
  documentId: number,
  question: string,
}
```

### searchStepSchema

```typescript
export const searchStepSchema = z.object({
  depth: z.number(),
  action: z.string(),
  pattern: z.string().optional(),
  query: z.string(),
  results: z.array(z.object({
    lineNumber: z.number().optional(),
    content: z.string(),
    relevance: z.number().optional(),
  })),
  reasoning: z.string().optional(),
  duration: z.number().optional(),
});
```

## TypeScript Types

```typescript
// Inferred from Drizzle schema
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Document = typeof documents.$inferSelect;
export type InsertDocument = z.infer<typeof insertDocumentSchema>;

export type Query = typeof queries.$inferSelect;
export type InsertQuery = z.infer<typeof insertQuerySchema>;

export type SearchStep = z.infer<typeof searchStepSchema>;
```

## Database Commands

```bash
# Push schema changes to database
npm run db:push

# Force push (use carefully)
npm run db:push --force

# Generate SQL migrations (not typically used)
npm run db:generate
```

## Storage Interface

The storage layer implements this interface:

```typescript
interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Documents
  getDocument(id: number): Promise<Document | undefined>;
  getAllDocuments(): Promise<Document[]>;
  createDocument(doc: InsertDocument): Promise<Document>;
  deleteDocument(id: number): Promise<void>;

  // Queries
  getQuery(id: number): Promise<Query | undefined>;
  getQueriesByDocument(documentId: number): Promise<Query[]>;
  createQuery(query: InsertQuery): Promise<Query>;
  updateQuery(id: number, updates: Partial<Query>): Promise<Query>;
}
```

## Sample Data

### Document (File Upload)
```json
{
  "id": 1,
  "name": "server.ts",
  "content": "import express from 'express';\n...",
  "type": "code",
  "size": 2048,
  "language": "typescript",
  "sourceType": "upload",
  "sourceUrl": null,
  "sourceTitle": null,
  "createdAt": "2026-01-19T02:00:00.000Z"
}
```

### Document (YouTube Import)
```json
{
  "id": 2,
  "name": "How RLMs Work - Tutorial",
  "content": "In this video we'll explore...",
  "type": "text",
  "size": 15000,
  "language": null,
  "sourceType": "youtube",
  "sourceUrl": "https://www.youtube.com/watch?v=abc123",
  "sourceTitle": "How RLMs Work - Tutorial",
  "createdAt": "2026-01-19T02:00:00.000Z"
}
```

### Document (Website Scrape)
```json
{
  "id": 3,
  "name": "Example Documentation",
  "content": "### Documentation\n\n## Getting Started\n...",
  "type": "text",
  "size": 8500,
  "language": null,
  "sourceType": "website",
  "sourceUrl": "https://docs.example.com",
  "sourceTitle": "Example Documentation",
  "createdAt": "2026-01-19T02:00:00.000Z"
}
```

### Query
```json
{
  "id": 1,
  "documentId": 1,
  "question": "How does the authentication work?",
  "answer": "The authentication system uses JWT tokens...",
  "searchHistory": [
    {
      "depth": 0,
      "action": "search",
      "pattern": "auth|login|token",
      "query": "Finding authentication-related code",
      "results": [...],
      "reasoning": "Starting with broad auth search",
      "duration": 234
    }
  ],
  "status": "completed",
  "totalDepth": 3,
  "totalDuration": 5234,
  "createdAt": "2026-01-19T02:00:00.000Z"
}
```
