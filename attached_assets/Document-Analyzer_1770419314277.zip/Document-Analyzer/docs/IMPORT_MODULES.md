# Knowledge Import Modules

This document explains the YouTube and Website import systems for aggregating knowledge from external sources.

## Overview

RLM Explorer supports three content sources:

| Source | Method | Use Case |
|--------|--------|----------|
| **File Upload** | Drag & drop or paste | Code, documents, data files |
| **YouTube** | URL input | Video transcripts, lectures, tutorials |
| **Website** | URL input | Articles, documentation, blog posts |

---

## YouTube Transcript Import

### How It Works

```
┌─────────────────────────────────────────────────────────────────┐
│  User enters YouTube URL                                        │
└─────────────────────────────────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│  parseYouTubeUrl(url)                                           │
│  - Extracts video ID from various URL formats                   │
│  - Validates it's a real YouTube URL                            │
└─────────────────────────────────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│  Fetch YouTube video page HTML                                  │
│  - GET https://www.youtube.com/watch?v={videoId}                │
└─────────────────────────────────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│  Extract caption track URL from ytInitialPlayerResponse         │
│  - Parse JSON embedded in page                                  │
│  - Find captions.playerCaptionsTracklistRenderer                │
│  - Get baseUrl for transcript                                   │
└─────────────────────────────────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│  Fetch transcript XML                                           │
│  - GET {captionTrackUrl}                                        │
│  - Returns timed transcript in XML format                       │
└─────────────────────────────────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│  Parse and clean transcript                                     │
│  - Extract text from <text> elements                            │
│  - Decode HTML entities                                         │
│  - Join into readable paragraphs                                │
└─────────────────────────────────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│  Create document in database                                    │
│  - sourceType: "youtube"                                        │
│  - sourceUrl: original YouTube URL                              │
│  - sourceTitle: video title                                     │
└─────────────────────────────────────────────────────────────────┘
```

### Supported URL Formats

```javascript
// All these formats are supported:
"https://www.youtube.com/watch?v=dQw4w9WgXcQ"
"https://youtu.be/dQw4w9WgXcQ"
"https://www.youtube.com/embed/dQw4w9WgXcQ"
"https://m.youtube.com/watch?v=dQw4w9WgXcQ"
"https://youtube.com/watch?v=dQw4w9WgXcQ&list=PLxxx"  // With playlist
"https://www.youtube.com/watch?v=dQw4w9WgXcQ&t=120"   // With timestamp
```

### Key Implementation Details

**File:** `server/youtube-import.ts`

```typescript
// URL parsing regex
const patterns = [
  /(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([a-zA-Z0-9_-]{11})/
];

// Transcript extraction
// 1. Fetch page HTML
// 2. Find ytInitialPlayerResponse in script tags
// 3. Parse JSON to find captions
// 4. Fetch caption track URL
// 5. Parse XML transcript
```

### Error Cases

| Error | Cause | Response |
|-------|-------|----------|
| `INVALID_URL` | Not a YouTube URL | 400 Bad Request |
| `NO_VIDEO_ID` | Can't extract video ID | 400 Bad Request |
| `NO_TRANSCRIPT` | Video has no captions | 404 Not Found |
| `PRIVATE_VIDEO` | Video is private/deleted | 403 Forbidden |
| `FETCH_FAILED` | Network error | 500 Internal Error |

### Limitations

- Only works with videos that have captions (auto-generated or manual)
- Private/unlisted videos may not work
- Age-restricted videos may require authentication
- No API key required (scrapes public data)

---

## Website Scraper

### How It Works

```
┌─────────────────────────────────────────────────────────────────┐
│  User enters website URL                                        │
└─────────────────────────────────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│  validateUrl(url)                                               │
│  - Check URL format                                             │
│  - Verify HTTP/HTTPS protocol                                   │
│  - SSRF protection check                                        │
└─────────────────────────────────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│  scrapeWebsite(url, options)                                    │
│  - Initialize queue with starting URL                           │
│  - Set visited = {}, depth = 0                                  │
└─────────────────────────────────────────────────────────────────┘
                                │
                                ▼
        ┌───────────────────────────────────────────┐
        │           Crawl Loop                       │
        │                                            │
        │  while (queue.length > 0 &&                │
        │         visited.size < maxPages) {         │
        │                                            │
        │    1. Pop URL from queue                   │
        │    2. Fetch page HTML                      │
        │    3. Extract text content                 │
        │    4. Extract links (same domain only)     │
        │    5. Add new links to queue if depth OK   │
        │    6. Store page content                   │
        │  }                                         │
        └───────────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│  Combine all pages into single document                         │
│  - Headings preserved as markdown                               │
│  - Pages separated by source URL headers                        │
└─────────────────────────────────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│  Create document in database                                    │
│  - sourceType: "website"                                        │
│  - sourceUrl: starting URL                                      │
│  - sourceTitle: main page title                                 │
└─────────────────────────────────────────────────────────────────┘
```

### SSRF Protection

**File:** `server/website-import.ts` - `isPrivateOrReservedHostname()`

Blocks these dangerous destinations:

```javascript
// Localhost variations
"localhost"
"127.0.0.1"
"::1"
"localhost.localdomain"
"*.localhost"
"*.local"
"*.internal"

// Private IP ranges (RFC 1918)
"10.x.x.x"        // 10.0.0.0/8
"172.16-31.x.x"   // 172.16.0.0/12
"192.168.x.x"     // 192.168.0.0/16

// Link-local
"169.254.x.x"     // 169.254.0.0/16

// Cloud metadata endpoints
"169.254.169.254" // AWS/GCP/Azure
"metadata.google.internal"
"metadata.goog"
"100.100.100.200" // Alibaba Cloud

// IPv6 private
"fe80:*"          // Link-local
"fc*", "fd*"      // Unique local
```

### Text Extraction

The scraper removes non-content elements:

```javascript
const tagsToRemove = [
  'script',    // JavaScript
  'style',     // CSS
  'noscript',  // No-JS fallbacks
  'iframe',    // Embedded content
  'svg',       // Graphics
  'canvas',    // Graphics
  'nav',       // Navigation
  'footer',    // Footer links
  'header',    // Site header
  'aside',     // Sidebars
  'form',      // Forms
  'button',    // Buttons
  'menu',      // Menus
  'template'   // Templates
];
```

### Crawl Configuration

```typescript
interface ScrapeOptions {
  maxPages?: number;   // Default: 10, max pages to crawl
  maxDepth?: number;   // Default: 2, max link depth from start
  timeout?: number;    // Per-page fetch timeout
}
```

### Output Format

```markdown
### Example Website

## Document Structure
# Main Page Title

## Content
Main page content here...

---

## Page: /about
# About Us

About page content...

---

## Page: /features
# Features

Features page content...
```

### Error Cases

| Error | Cause | Response |
|-------|-------|----------|
| `INVALID_URL` | Malformed URL | 400 Bad Request |
| `INVALID_PROTOCOL` | Not HTTP/HTTPS | 400 Bad Request |
| `SSRF_BLOCKED` | Internal/private URL | 403 Forbidden |
| `FETCH_FAILED` | Network/timeout | 500 Internal Error |
| `NO_CONTENT` | Page has no text | 400 Bad Request |

---

## Frontend Implementation

**File:** `client/src/components/document-upload.tsx`

The upload component has 4 tabs:

```tsx
<Tabs defaultValue="file">
  <TabsList>
    <TabsTrigger value="file">File</TabsTrigger>
    <TabsTrigger value="paste">Paste</TabsTrigger>
    <TabsTrigger value="youtube">YouTube</TabsTrigger>
    <TabsTrigger value="website">Website</TabsTrigger>
  </TabsList>

  <TabsContent value="youtube">
    <Input placeholder="https://youtube.com/watch?v=..." />
    <Button>Import Transcript</Button>
  </TabsContent>

  <TabsContent value="website">
    <Input placeholder="https://example.com" />
    <Button>Scrape Website</Button>
  </TabsContent>
</Tabs>
```

### API Calls

```typescript
// YouTube import
const response = await fetch('/api/import/youtube', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ url: youtubeUrl })
});

// Website import
const response = await fetch('/api/import/website', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ 
    url: websiteUrl,
    maxPages: 10,
    maxDepth: 2
  })
});
```

---

## Use Cases

### Marketing Analysis
1. Import competitor's blog posts via website scraper
2. Import their YouTube content strategy
3. Use RLM to analyze messaging, keywords, positioning

### Content Creation
1. Import research papers via file upload
2. Import expert YouTube lectures
3. Query for specific insights and quotes

### Website Understanding
1. Scrape entire documentation site
2. Query "How do I configure X?"
3. Get answer synthesized from multiple pages

### Learning & Research
1. Import course lecture transcripts
2. Import related blog posts
3. Create study guides by querying key concepts
