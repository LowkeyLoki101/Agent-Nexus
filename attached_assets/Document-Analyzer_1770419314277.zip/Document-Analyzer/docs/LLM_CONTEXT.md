# RLM Explorer - Complete Context for LLMs

This single document provides everything another LLM needs to understand, modify, or extend the RLM Explorer system.

## Quick Summary

**RLM Explorer** is a web app that lets users analyze massive documents (10M+ tokens) using AI-powered recursive search. Instead of stuffing everything into context, the AI recursively searches, reads, and refines until it can answer.

**Key Features:**
- Upload files (code, text, JSON, markdown) up to 500MB
- Import YouTube video transcripts (no API key needed)
- Scrape website content (with SSRF protection)
- Ask questions - AI recursively searches to find answers
- Real-time visualization of search process
- Mobile-first design optimized for iPhone

---

## Tech Stack

| Layer | Technology |
|-------|------------|
| Frontend | React 18, Vite, TypeScript |
| UI | shadcn/ui, Tailwind CSS, Framer Motion |
| State | TanStack Query v5 |
| Routing | wouter |
| Backend | Express.js v5, TypeScript |
| Database | PostgreSQL (Neon) via Drizzle ORM |
| AI | OpenAI API (via Replit integrations) |

---

## File Structure (Important Files Only)

```
/
├── shared/schema.ts          # Database schema + types (START HERE)
├── server/
│   ├── routes.ts             # API endpoints
│   ├── storage.ts            # Database operations
│   ├── rlm-engine.ts         # AI recursive search logic
│   ├── youtube-import.ts     # YouTube transcript extraction
│   └── website-import.ts     # Website scraping + SSRF protection
├── client/src/
│   ├── App.tsx               # Root component
│   ├── pages/home.tsx        # Main page
│   └── components/
│       ├── document-upload.tsx    # File/URL upload UI
│       ├── query-interface.tsx    # Search input
│       └── search-visualization.tsx # Animated results
└── docs/                     # This documentation folder
```

---

## Database Tables

```sql
-- Documents: uploaded/imported content
documents (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  content TEXT NOT NULL,
  type TEXT NOT NULL,           -- 'code'|'text'|'json'|'markdown'
  size INTEGER NOT NULL,
  language TEXT,                -- for code files
  source_type TEXT DEFAULT 'upload',  -- 'upload'|'youtube'|'website'
  source_url TEXT,              -- original URL
  source_title TEXT,            -- video/page title
  created_at TIMESTAMP
)

-- Queries: search sessions
queries (
  id SERIAL PRIMARY KEY,
  document_id INTEGER NOT NULL,
  question TEXT NOT NULL,
  answer TEXT,                  -- null until complete
  search_history JSONB,         -- Array<SearchStep>
  status TEXT DEFAULT 'pending', -- 'pending'|'processing'|'completed'|'error'
  total_depth INTEGER,
  total_duration INTEGER,       -- milliseconds
  created_at TIMESTAMP
)
```

---

## API Endpoints

```
GET  /api/documents              - List all documents
GET  /api/documents/:id          - Get one document
POST /api/documents              - Upload new document
DELETE /api/documents/:id        - Delete document

GET  /api/documents/:id/queries  - Get queries for document
POST /api/queries                - Start new search
GET  /api/queries/:id/stream     - SSE stream for real-time updates

POST /api/import/youtube         - Import YouTube transcript
     Body: { "url": "https://youtube.com/watch?v=..." }

POST /api/import/website         - Scrape website
     Body: { "url": "https://...", "maxPages": 10, "maxDepth": 2 }
```

---

## How RLM Search Works

```
1. User asks: "How does authentication work?"
   
2. AI generates search pattern: /auth|login|token/
   
3. System searches document, returns matches

4. AI analyzes results:
   - If confident: Generate answer
   - If not: Generate new pattern, repeat

5. Stream each step to frontend via SSE

6. After max depth or confidence: Return final answer
```

**SearchStep Structure:**
```typescript
{
  depth: 0,              // recursion level
  action: "search",      // search|read|refine|analyze
  pattern: "auth.*",     // regex used
  query: "Finding auth", // description
  results: [{ lineNumber: 42, content: "..." }],
  reasoning: "Starting with broad search",
  duration: 234          // ms
}
```

---

## YouTube Import Flow

1. Parse video ID from URL (supports youtube.com, youtu.be, embed)
2. Fetch YouTube page HTML
3. Extract `ytInitialPlayerResponse` JSON
4. Find caption track URL
5. Fetch and parse XML transcript
6. Store as document with `sourceType: "youtube"`

**No API key required** - scrapes public caption data.

---

## Website Scraper Flow

1. Validate URL (HTTP/HTTPS only)
2. **SSRF Check** - Block internal IPs, localhost, metadata endpoints
3. Fetch page, extract text (remove scripts, nav, footer)
4. Find links on same domain
5. Crawl up to maxPages (default 10) and maxDepth (default 2)
6. Combine all pages, store with `sourceType: "website"`

**SSRF Blocked:**
- `localhost`, `127.0.0.1`, `::1`
- `10.x.x.x`, `172.16-31.x.x`, `192.168.x.x`
- `169.254.x.x` (link-local)
- `169.254.169.254` (cloud metadata)

---

## Environment Variables

```
DATABASE_URL                     - PostgreSQL connection string
AI_INTEGRATIONS_OPENAI_API_KEY   - OpenAI API key (via Replit)
AI_INTEGRATIONS_OPENAI_BASE_URL  - OpenAI base URL
SESSION_SECRET                   - Express session secret
```

---

## Common Tasks

### Add a new API endpoint

1. Edit `server/routes.ts`
2. Add route handler
3. Use `storage` for database operations
4. Validate input with Zod

### Add a new database table

1. Edit `shared/schema.ts`
2. Define table with `pgTable()`
3. Create insert schema with `createInsertSchema().omit(...)`
4. Export types
5. Run `npm run db:push`
6. Add storage methods in `server/storage.ts`

### Add a new import source

1. Create `server/xxx-import.ts`
2. Implement extraction logic
3. Add endpoint in `server/routes.ts`
4. Add tab in `client/src/components/document-upload.tsx`

### Modify the AI search logic

1. Edit `server/rlm-engine.ts`
2. Modify prompts in `generateSearchPrompt()` or `generateAnalysisPrompt()`
3. Adjust recursion limits in config

---

## Known Patterns

### API Request (Frontend)
```typescript
import { apiRequest } from "@/lib/queryClient";

const result = await apiRequest('/api/documents', {
  method: 'POST',
  body: { name, content, type, size }
});
```

### TanStack Query
```typescript
const { data, isLoading } = useQuery({
  queryKey: ['/api/documents'],
});
```

### SSE Streaming
```typescript
const eventSource = new EventSource(`/api/queries/${id}/stream`);
eventSource.addEventListener('step', (e) => {
  const step = JSON.parse(e.data);
});
```

### Database Operation
```typescript
import { storage } from './storage';

const doc = await storage.createDocument({
  name: 'example.txt',
  content: 'Hello world',
  type: 'text',
  size: 11,
  sourceType: 'upload'
});
```

---

## Gotchas & Tips

1. **Restart workflow after backend changes** - Uses tsx, not hot reload
2. **SSE needs explicit headers** - Set `Content-Type: text/event-stream`
3. **Zod validation** - All API inputs validated, errors return 400
4. **SSRF protection** - Website scraper blocks internal URLs
5. **Large files** - 500MB limit, stored as TEXT in Postgres
6. **Mobile design** - 44px touch targets, auto-collapse sidebar
7. **Dark mode** - Uses `class` strategy, toggle in header

---

## Useful Commands

```bash
npm run dev        # Start development server
npm run build      # Build for production
npm run db:push    # Push schema to database
```

---

## Current State (January 2026)

- Core RLM functionality: Working
- File upload: Working (500MB limit)
- YouTube import: Working (no API key)
- Website scrape: Working (SSRF protected)
- Mobile optimization: Complete
- Dark/light theme: Complete
- Database persistence: Complete (PostgreSQL)
