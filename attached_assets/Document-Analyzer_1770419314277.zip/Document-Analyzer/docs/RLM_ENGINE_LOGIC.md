# RLM Engine - Recursive Search Logic

This document explains how the Recursive Language Model (RLM) engine works - the core AI-powered search system.

## What is RLM?

Traditional LLMs are limited by their context window. If you have a 10 million token codebase, you can't fit it all in a single prompt. RLM solves this by treating the context as an **external environment** that the AI interacts with through **symbolic searches**.

Think of it like a human developer exploring a new codebase:
1. Start with a broad search for relevant terms
2. Read the results
3. Refine the search based on what you learned
4. Repeat until you find what you need
5. Synthesize an answer

## Core Algorithm

```
┌─────────────────────────────────────────────────────────────────┐
│                     processQuery(document, question)            │
└─────────────────────────────────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│  1. Initialize: depth=0, maxDepth=5, context=[]                 │
└─────────────────────────────────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│  2. Ask AI: "Given this question and current context,           │
│      what search pattern should we use?"                        │
│      → AI generates regex pattern + reasoning                   │
└─────────────────────────────────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│  3. Execute Search: Run regex against document content          │
│      → Returns matching lines with line numbers                 │
└─────────────────────────────────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│  4. Stream Step: Send search results to client via SSE          │
└─────────────────────────────────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│  5. Ask AI: "Based on these results, do you have enough         │
│      information to answer? Or need another search?"            │
│                                                                  │
│      Options:                                                    │
│      A) CONFIDENT → Generate final answer, exit loop             │
│      B) NEED_MORE → Generate new pattern, continue               │
│      C) REFINE → Narrow down with more specific pattern          │
└─────────────────────────────────────────────────────────────────┘
                                │
                    ┌───────────┴───────────┐
                    │                       │
                    ▼                       ▼
            [CONFIDENT]              [NEED_MORE / REFINE]
                    │                       │
                    ▼                       ▼
        ┌───────────────────┐     ┌───────────────────┐
        │ Generate Answer   │     │ depth++           │
        │ Return to client  │     │ if depth < max    │
        └───────────────────┘     │   → Go to step 2  │
                                  │ else              │
                                  │   → Force answer  │
                                  └───────────────────┘
```

## Search Actions

The AI can perform different types of actions at each step:

| Action | Description | Example |
|--------|-------------|---------|
| `search` | Regex search across document | `function.*async` |
| `read` | Read specific lines around a match | Lines 100-150 |
| `refine` | Narrow previous results | Add filter conditions |
| `analyze` | Synthesize findings | Connect the dots |

## AI Prompts

### Initial Search Prompt

```
You are analyzing a document to answer a user's question.

Document type: {type}
Document name: {name}
Document preview (first 2000 chars): {preview}

User question: {question}

Generate a regex search pattern to find relevant content.
Respond with JSON:
{
  "pattern": "regex pattern here",
  "reasoning": "why this pattern will help"
}
```

### Analysis Prompt

```
You searched for: {pattern}
Found {count} results:

{results with line numbers}

User question: {question}

Decide your next action:
1. If you have enough information: {"action": "answer", "answer": "..."}
2. If you need more: {"action": "search", "pattern": "...", "reasoning": "..."}
3. If you want to refine: {"action": "refine", "pattern": "...", "reasoning": "..."}
```

### Final Answer Prompt

```
Based on your search through the document:

Search history:
{formatted steps with patterns and results}

User question: {question}

Provide a comprehensive answer based on what you found.
```

## Example Walkthrough

**Question:** "How does the authentication system work?"

**Step 0 (depth: 0):**
- AI generates pattern: `auth|login|session|token`
- Finds 45 matches across files
- Decides: NEED_MORE - too broad

**Step 1 (depth: 1):**
- AI generates pattern: `function.*auth.*\{`
- Finds 8 function definitions
- Decides: NEED_MORE - want to see implementations

**Step 2 (depth: 2):**
- AI generates pattern: `validateToken|checkSession`
- Finds 3 specific functions
- Decides: REFINE - focus on token validation

**Step 3 (depth: 3):**
- AI reads lines around `validateToken` function
- Sees JWT verification logic
- Decides: CONFIDENT

**Final Answer:**
"The authentication system uses JWT tokens. The `validateToken` function in auth.ts verifies tokens by checking the signature against the secret key, then extracts the user ID from the payload..."

## Configuration

```typescript
const RLM_CONFIG = {
  maxDepth: 5,           // Maximum recursion depth
  maxResultsPerSearch: 50,  // Limit results to prevent context overflow
  contextWindow: 8000,   // Tokens reserved for AI context
  searchTimeout: 10000,  // Per-search timeout in ms
};
```

## Performance Considerations

1. **Result Limiting:** Each search returns max 50 results to fit in AI context
2. **Content Truncation:** Large matches are truncated with `...`
3. **Caching:** Previous search results are cached during a query session
4. **Early Exit:** AI can confidently answer early if pattern is specific enough

## Error Handling

| Error | Handling |
|-------|----------|
| Invalid regex | Escape special characters, retry |
| No results | Broaden pattern or try synonyms |
| Max depth reached | Force answer with available context |
| AI timeout | Return partial results with disclaimer |
| SSE disconnect | Store results in database for later retrieval |

## Extending the Engine

To add new search capabilities:

1. **Add new action type** in `searchStepSchema`
2. **Implement handler** in `RLMEngine.executeAction()`
3. **Update AI prompts** to know about new action
4. **Add streaming** for new action type

Example: Adding a "summarize" action that condenses long results before continuing.
