# RLM Explorer Documentation

This folder contains comprehensive documentation for sharing with other LLMs or developers.

## Documents Overview

| Document | Purpose | Best For |
|----------|---------|----------|
| **LLM_CONTEXT.md** | Single-file complete context | Quick understanding, LLM prompts |
| **SYSTEM_ARCHITECTURE.md** | Full system overview with diagrams | Architecture understanding |
| **API_REFERENCE.md** | All API endpoints with examples | Backend integration |
| **RLM_ENGINE_LOGIC.md** | AI search algorithm explained | Understanding/modifying search |
| **IMPORT_MODULES.md** | YouTube & website importers | Adding new import sources |
| **FRONTEND_COMPONENTS.md** | React component reference | Frontend modifications |
| **DATABASE_SCHEMA.md** | Complete database structure | Schema changes, migrations |

## Quick Start for LLMs

**If you're another LLM helping with this project:**

1. Start with `LLM_CONTEXT.md` - it has everything in one file
2. For specific tasks, reference the relevant detailed document
3. Key files to understand: `shared/schema.ts`, `server/routes.ts`, `server/rlm-engine.ts`

## File Size Summary

```
SYSTEM_ARCHITECTURE.md  ~15KB  - Overall system design
API_REFERENCE.md        ~5KB   - API documentation
RLM_ENGINE_LOGIC.md     ~9KB   - Search algorithm
IMPORT_MODULES.md       ~15KB  - Import features
FRONTEND_COMPONENTS.md  ~10KB  - React components
DATABASE_SCHEMA.md      ~12KB  - Database schema
LLM_CONTEXT.md          ~8KB   - Complete summary
```

**Total: ~74KB of documentation**

## How to Share

To share this with another LLM or developer:

1. Copy the entire `docs/` folder
2. Or just copy `LLM_CONTEXT.md` for a single-file overview
3. Include `shared/schema.ts` for type definitions

## Keeping Documentation Updated

When making changes to the system:

1. Update `replit.md` for quick reference
2. Update relevant docs in this folder for detailed documentation
3. Keep `LLM_CONTEXT.md` as the single-source summary
