# Frontend Components Reference

Complete guide to all React components in RLM Explorer.

## Component Hierarchy

```
App.tsx
├── SidebarProvider
│   ├── AppSidebar (sidebar navigation)
│   └── Main Content
│       ├── Header (SidebarTrigger + ThemeToggle)
│       └── Router
│           ├── Home (main page)
│           │   ├── DocumentUpload
│           │   ├── QueryInterface
│           │   └── SearchVisualization
│           └── NotFound (404)
└── Toaster (notifications)
```

---

## Core Components

### App.tsx

Root component with routing and providers.

```tsx
// Location: client/src/App.tsx

<QueryClientProvider>
  <TooltipProvider>
    <SidebarProvider>
      <AppSidebar />
      <main>
        <Header />
        <Router />
      </main>
    </SidebarProvider>
    <Toaster />
  </TooltipProvider>
</QueryClientProvider>
```

**Key features:**
- TanStack Query for API state management
- shadcn/ui sidebar for navigation
- Theme provider for dark/light mode
- wouter for client-side routing

---

### DocumentUpload

**Location:** `client/src/components/document-upload.tsx`

4-tab interface for adding content:

```tsx
interface Props {
  onDocumentCreated: (doc: Document) => void;
}

<Tabs defaultValue="file">
  <TabsList className="grid grid-cols-4">
    <TabsTrigger value="file">File</TabsTrigger>
    <TabsTrigger value="paste">Paste</TabsTrigger>
    <TabsTrigger value="youtube">YouTube</TabsTrigger>
    <TabsTrigger value="website">Website</TabsTrigger>
  </TabsList>

  {/* File Drop Zone */}
  <TabsContent value="file">
    <div onDrop={handleFileDrop} onDragOver={...}>
      Drop files here (up to 500MB)
    </div>
  </TabsContent>

  {/* Paste Content */}
  <TabsContent value="paste">
    <Textarea placeholder="Paste content here..." />
    <Input placeholder="Document name" />
    <Button onClick={handlePaste}>Add Document</Button>
  </TabsContent>

  {/* YouTube Import */}
  <TabsContent value="youtube">
    <Input placeholder="https://youtube.com/watch?v=..." />
    <Button onClick={handleYoutubeImport}>Import Transcript</Button>
  </TabsContent>

  {/* Website Scrape */}
  <TabsContent value="website">
    <Input placeholder="https://example.com" />
    <Button onClick={handleWebsiteImport}>Scrape Website</Button>
  </TabsContent>
</Tabs>
```

**API Calls:**
- `POST /api/documents` - File upload
- `POST /api/import/youtube` - YouTube import
- `POST /api/import/website` - Website scrape

**Mobile Optimization:**
- 44px minimum touch targets
- Full-width inputs on mobile
- Responsive grid layout

---

### QueryInterface

**Location:** `client/src/components/query-interface.tsx`

Search input and query history for a document.

```tsx
interface Props {
  document: Document;
  onQueryStart: (query: Query) => void;
}

// State
const [question, setQuestion] = useState("");
const [isLoading, setIsLoading] = useState(false);

// Fetch existing queries
const { data: queries } = useQuery({
  queryKey: ['/api/documents', document.id, 'queries'],
});

// Submit new query
const handleSubmit = async () => {
  const response = await apiRequest('/api/queries', {
    method: 'POST',
    body: { documentId: document.id, question }
  });
  onQueryStart(response);
};
```

**Features:**
- Query history display
- Loading state during search
- Real-time status updates
- Mobile-friendly input

---

### SearchVisualization

**Location:** `client/src/components/search-visualization.tsx`

Animated display of recursive search steps.

```tsx
interface Props {
  queryId: number;
}

// SSE connection for streaming
useEffect(() => {
  const eventSource = new EventSource(`/api/queries/${queryId}/stream`);

  eventSource.addEventListener('step', (e) => {
    const step = JSON.parse(e.data);
    setSteps(prev => [...prev, step]);
  });

  eventSource.addEventListener('complete', (e) => {
    const result = JSON.parse(e.data);
    setAnswer(result.answer);
    setIsComplete(true);
  });

  return () => eventSource.close();
}, [queryId]);

// Render
<AnimatePresence>
  {steps.map((step, index) => (
    <motion.div
      key={index}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
    >
      <SearchStepCard step={step} />
    </motion.div>
  ))}
</AnimatePresence>
```

**SearchStepCard subcomponent:**
```tsx
function SearchStepCard({ step }: { step: SearchStep }) {
  return (
    <Card>
      <CardHeader>
        <Badge>Depth {step.depth}</Badge>
        <Badge>{step.action}</Badge>
      </CardHeader>
      <CardContent>
        {step.pattern && (
          <code>Pattern: {step.pattern}</code>
        )}
        <p>{step.reasoning}</p>
        <div className="results">
          {step.results.map((result, i) => (
            <div key={i}>
              {result.lineNumber && <span>L{result.lineNumber}</span>}
              <code>{result.content}</code>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
```

**Animations:**
- Framer Motion for step transitions
- Staggered entry animations
- Smooth scroll to latest step

---

### ThemeToggle

**Location:** `client/src/components/theme-toggle.tsx`

Dark/light mode toggle button.

```tsx
function ThemeToggle() {
  const [theme, setTheme] = useState<"light" | "dark">("dark");

  useEffect(() => {
    document.documentElement.classList.toggle("dark", theme === "dark");
    localStorage.setItem("theme", theme);
  }, [theme]);

  return (
    <Button
      variant="ghost"
      size="icon"
      onClick={() => setTheme(theme === "light" ? "dark" : "light")}
    >
      {theme === "light" ? <Moon /> : <Sun />}
    </Button>
  );
}
```

---

## Pages

### Home Page

**Location:** `client/src/pages/home.tsx`

Main application page with document explorer.

```tsx
function Home() {
  const [selectedDoc, setSelectedDoc] = useState<Document | null>(null);
  const [activeQuery, setActiveQuery] = useState<Query | null>(null);

  const { data: documents, isLoading } = useQuery({
    queryKey: ['/api/documents'],
  });

  return (
    <div className="flex flex-col lg:flex-row h-full">
      {/* Document List */}
      <aside className="w-full lg:w-80 border-r">
        <DocumentUpload onDocumentCreated={refetch} />
        <ScrollArea>
          {documents?.map(doc => (
            <DocumentCard
              key={doc.id}
              document={doc}
              selected={selectedDoc?.id === doc.id}
              onClick={() => setSelectedDoc(doc)}
            />
          ))}
        </ScrollArea>
      </aside>

      {/* Main Content */}
      <main className="flex-1">
        {selectedDoc ? (
          <>
            <QueryInterface
              document={selectedDoc}
              onQueryStart={setActiveQuery}
            />
            {activeQuery && (
              <SearchVisualization queryId={activeQuery.id} />
            )}
          </>
        ) : (
          <EmptyState message="Select a document to start" />
        )}
      </main>
    </div>
  );
}
```

### Not Found Page

**Location:** `client/src/pages/not-found.tsx`

404 error page.

```tsx
function NotFound() {
  return (
    <div className="flex flex-col items-center justify-center h-full">
      <h1 className="text-4xl font-bold">404</h1>
      <p>Page not found</p>
      <Link href="/">
        <Button>Go Home</Button>
      </Link>
    </div>
  );
}
```

---

## UI Components (shadcn/ui)

All located in `client/src/components/ui/`:

| Component | Usage |
|-----------|-------|
| `Button` | Actions, submit buttons |
| `Card` | Content containers |
| `Input` | Text inputs |
| `Textarea` | Multi-line inputs |
| `Tabs` | Tab navigation |
| `Badge` | Labels, status indicators |
| `ScrollArea` | Scrollable containers |
| `Dialog` | Modal dialogs |
| `Tooltip` | Hover hints |
| `Skeleton` | Loading placeholders |
| `Toast` | Notifications |
| `Sidebar` | Navigation sidebar |

---

## Hooks

### use-toast

**Location:** `client/src/hooks/use-toast.ts`

Toast notification system.

```tsx
import { useToast } from "@/hooks/use-toast";

function MyComponent() {
  const { toast } = useToast();

  const handleError = (error: Error) => {
    toast({
      title: "Error",
      description: error.message,
      variant: "destructive"
    });
  };

  const handleSuccess = () => {
    toast({
      title: "Success",
      description: "Document uploaded successfully"
    });
  };
}
```

### use-mobile

**Location:** `client/src/hooks/use-mobile.tsx`

Mobile detection hook.

```tsx
import { useIsMobile } from "@/hooks/use-mobile";

function MyComponent() {
  const isMobile = useIsMobile();

  return isMobile ? <MobileLayout /> : <DesktopLayout />;
}
```

---

## Styling

### Tailwind CSS

Configuration in `tailwind.config.ts`:
- Custom colors via CSS variables
- Dark mode via `class` strategy
- Typography plugin for content
- Animation utilities

### CSS Variables

Defined in `client/src/index.css`:

```css
:root {
  --background: 0 0% 100%;
  --foreground: 240 10% 3.9%;
  --primary: 262 83% 58%;      /* Purple accent */
  --secondary: 240 5% 96%;
  --muted: 240 5% 96%;
  --accent: 240 5% 96%;
  --destructive: 0 84% 60%;
  --border: 240 6% 90%;
  --radius: 0.5rem;
}

.dark {
  --background: 240 10% 3.9%;
  --foreground: 0 0% 98%;
  /* ... dark variants */
}
```

---

## Data Fetching

Using TanStack Query with default fetcher:

```tsx
// Queries
const { data, isLoading, error, refetch } = useQuery({
  queryKey: ['/api/documents'],
});

// Mutations
const mutation = useMutation({
  mutationFn: (data) => apiRequest('/api/documents', {
    method: 'POST',
    body: data
  }),
  onSuccess: () => {
    queryClient.invalidateQueries({ queryKey: ['/api/documents'] });
  }
});
```

**API Request Helper:**
```tsx
// Location: client/src/lib/queryClient.ts

export async function apiRequest(url: string, options?: RequestInit) {
  const response = await fetch(url, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...options?.headers,
    },
    body: options?.body ? JSON.stringify(options.body) : undefined,
  });

  if (!response.ok) {
    throw new Error(await response.text());
  }

  return response.json();
}
```
