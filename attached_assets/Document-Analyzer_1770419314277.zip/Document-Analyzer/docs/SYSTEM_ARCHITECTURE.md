# RLM Explorer - Complete System Architecture

This document provides a comprehensive overview of the RLM Explorer system for sharing with other LLMs or developers.

## Project Purpose

RLM Explorer implements **Recursive Language Models (RLMs)** - a technique for processing massive documents (10M+ tokens) by treating the AI's context window as an external environment that the model interacts with through symbolic, code-driven searches. Instead of stuffing everything into context, the AI recursively searches, reads, and refines its understanding.

## High-Level Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              CLIENT (React + Vite)                         │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐   │
│  │   Home Page  │  │  Document    │  │   Query      │  │   Search     │   │
│  │   /          │  │   Upload     │  │   Interface  │  │   Visualizer │   │
│  └──────────────┘  └──────────────┘  └──────────────┘  └──────────────┘   │
│         │                 │                 │                 │            │
│         └─────────────────┴─────────────────┴─────────────────┘            │
│                                     │                                       │
│                          TanStack React Query                               │
│                          (API state management)                             │
└─────────────────────────────────────────────────────────────────────────────┘
                                      │
                                      │ HTTP / SSE
                                      ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                           SERVER (Express.js v5)                           │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐   │
│  │  REST API    │  │  YouTube     │  │  Website     │  │  RLM Engine  │   │
│  │  /api/*      │  │  Import      │  │  Scraper     │  │  (AI Search) │   │
│  └──────────────┘  └──────────────┘  └──────────────┘  └──────────────┘   │
│         │                 │                 │                 │            │
│         └─────────────────┴─────────────────┴─────────────────┘            │
│                                     │                                       │
│                              Storage Layer                                  │
│                         (DatabaseStorage class)                             │
└─────────────────────────────────────────────────────────────────────────────┘
                                      │
                                      │ Drizzle ORM
                                      ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                           PostgreSQL Database                               │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐                      │
│  │    users     │  │  documents   │  │   queries    │                      │
│  │  (auth)      │  │  (content)   │  │  (searches)  │                      │
│  └──────────────┘  └──────────────┘  └──────────────┘                      │
└─────────────────────────────────────────────────────────────────────────────┘
                                      │
                                      │ API Calls
                                      ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                           OpenAI API (via Replit)                          │
│                    AI_INTEGRATIONS_OPENAI_API_KEY                          │
│                    AI_INTEGRATIONS_OPENAI_BASE_URL                         │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Directory Structure

```
/
├── client/                    # Frontend React application
│   └── src/
│       ├── components/        # React components
│       │   ├── ui/            # shadcn/ui primitives (Button, Card, etc.)
│       │   ├── document-upload.tsx    # File upload + YouTube/Website import
│       │   ├── query-interface.tsx    # Search input and history
│       │   ├── search-visualization.tsx # Real-time search step display
│       │   └── theme-toggle.tsx       # Dark/light mode
│       ├── hooks/             # Custom React hooks
│       ├── lib/               # Utilities (queryClient, utils)
│       ├── pages/             # Route pages
│       │   ├── home.tsx       # Main application page
│       │   └── not-found.tsx  # 404 page
│       ├── App.tsx            # Root component with routing
│       └── main.tsx           # Entry point
│
├── server/                    # Backend Express application
│   ├── index.ts               # Server entry point
│   ├── routes.ts              # API route definitions
│   ├── storage.ts             # DatabaseStorage class (Drizzle ORM)
│   ├── rlm-engine.ts          # Recursive search engine with OpenAI
│   ├── youtube-import.ts      # YouTube transcript extraction
│   ├── website-import.ts      # Website scraping with SSRF protection
│   ├── vite.ts                # Vite dev server integration
│   ├── static.ts              # Static file serving for production
│   └── replit_integrations/   # Pre-built AI integrations
│
├── shared/                    # Shared code between client/server
│   ├── schema.ts              # Drizzle schema + Zod validation
│   └── models/
│       └── chat.ts            # Chat-related types
│
├── docs/                      # Documentation (this folder)
│
├── drizzle.config.ts          # Drizzle ORM configuration
├── tailwind.config.ts         # Tailwind CSS configuration
├── vite.config.ts             # Vite build configuration
└── package.json               # Dependencies and scripts
```

## Core Files Explained

### 1. Database Schema (`shared/schema.ts`)

Defines three main tables:

```typescript
// Users - basic auth support
users: { id, username, password }

// Documents - uploaded/imported content
documents: { 
  id, name, content, type, size, language,
  sourceType,    // 'upload' | 'youtube' | 'website'
  sourceUrl,     // Original URL for imports
  sourceTitle,   // Video/page title
  createdAt 
}

// Queries - search queries and results
queries: { 
  id, documentId, question, answer,
  searchHistory,  // Array of SearchStep objects
  status,         // 'pending' | 'processing' | 'completed' | 'error'
  totalDepth, totalDuration, createdAt 
}
```

### 2. Storage Layer (`server/storage.ts`)

Uses Drizzle ORM with PostgreSQL:

```typescript
class DatabaseStorage implements IStorage {
  // User CRUD
  getUser(id) / getUserByUsername(username) / createUser(user)
  
  // Document CRUD
  getDocument(id) / getAllDocuments() / createDocument(doc) / deleteDocument(id)
  
  // Query CRUD
  getQuery(id) / getQueriesByDocument(docId) / createQuery(query) / updateQuery(id, updates)
}
```

### 3. API Routes (`server/routes.ts`)

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/documents` | List all documents |
| GET | `/api/documents/:id` | Get single document |
| POST | `/api/documents` | Upload new document |
| DELETE | `/api/documents/:id` | Delete document |
| GET | `/api/documents/:id/queries` | Get queries for document |
| POST | `/api/queries` | Create query (starts RLM search) |
| GET | `/api/queries/:id/stream` | SSE stream for real-time search updates |
| POST | `/api/import/youtube` | Import YouTube video transcript |
| POST | `/api/import/website` | Scrape website content |

### 4. RLM Engine (`server/rlm-engine.ts`)

The heart of the system - implements recursive search:

```typescript
class RLMEngine {
  // Main entry point - streams search steps via callback
  async processQuery(document, question, onStep): Promise<string>
  
  // Core recursive loop
  async recursiveSearch(content, question, depth, onStep): Promise<SearchResult>
  
  // Individual search operations
  executeSearch(content, pattern): SearchResult[]
  analyzeResults(results, question): Analysis
}
```

**Search Step Structure:**
```typescript
interface SearchStep {
  depth: number;           // Recursion depth (0, 1, 2...)
  action: string;          // 'search' | 'read' | 'refine' | 'analyze'
  pattern?: string;        // Regex pattern used
  query: string;           // What we're looking for
  results: Array<{
    lineNumber?: number;
    content: string;
    relevance?: number;
  }>;
  reasoning?: string;      // AI's explanation
  duration?: number;       // Time in ms
}
```

### 5. YouTube Import (`server/youtube-import.ts`)

Extracts transcripts without API keys:

```typescript
// Scrapes YouTube's player API for caption data
async function extractTranscript(url: string): Promise<TranscriptResult>

// Parses various YouTube URL formats
function parseYouTubeUrl(url: string): string | null  // Returns video ID

// POST /api/import/youtube
// Body: { url: "https://youtube.com/watch?v=..." }
// Returns: Document with transcript as content
```

### 6. Website Scraper (`server/website-import.ts`)

Scrapes websites with security protections:

```typescript
// Main scraper with depth-limited crawling
async function scrapeWebsite(url: string, options?: ScrapeOptions): Promise<ScrapeResult>

// SSRF Protection - blocks dangerous URLs
function isPrivateOrReservedHostname(hostname: string): boolean
// Blocks: localhost, 127.0.0.1, 10.x.x.x, 172.16-31.x.x, 192.168.x.x,
//         169.254.x.x (link-local), metadata endpoints, IPv6 loopback

// Options
interface ScrapeOptions {
  maxPages?: number;   // Default: 10
  maxDepth?: number;   // Default: 2
  timeout?: number;    // Per-request timeout
}
```

### 7. Frontend Components

**DocumentUpload (`client/src/components/document-upload.tsx`):**
- 4 tabs: File Drop, Paste Content, YouTube URL, Website URL
- Drag-and-drop file upload with 500MB limit
- Mobile-optimized with 44px touch targets

**QueryInterface (`client/src/components/query-interface.tsx`):**
- Search input for asking questions about documents
- Query history display
- Real-time status updates

**SearchVisualization (`client/src/components/search-visualization.tsx`):**
- Animated display of recursive search steps
- Shows depth, patterns, results, and reasoning
- Uses Framer Motion for animations

## Data Flow

### Document Upload Flow
```
User drops file → Frontend validates → POST /api/documents → 
Storage.createDocument() → PostgreSQL INSERT → Return document
```

### YouTube Import Flow
```
User enters URL → POST /api/import/youtube → parseYouTubeUrl() → 
Fetch YouTube page → Extract captions JSON → Parse transcript →
Storage.createDocument(sourceType: 'youtube') → Return document
```

### Website Import Flow
```
User enters URL → POST /api/import/website → validateUrl() →
SSRF check → Fetch page → Extract text → Crawl links (depth-limited) →
Storage.createDocument(sourceType: 'website') → Return document
```

### Query/Search Flow
```
User asks question → POST /api/queries → Create pending query →
RLMEngine.processQuery() → Recursive search loop:
  1. AI analyzes content, generates search pattern
  2. executeSearch() finds matches
  3. AI analyzes results, decides next step
  4. Repeat until confident or max depth reached
→ Stream steps via SSE → Update query with answer → Return
```

## Environment Variables

| Variable | Purpose |
|----------|---------|
| `DATABASE_URL` | PostgreSQL connection string |
| `AI_INTEGRATIONS_OPENAI_API_KEY` | OpenAI API key (via Replit) |
| `AI_INTEGRATIONS_OPENAI_BASE_URL` | OpenAI API base URL |
| `SESSION_SECRET` | Express session secret |

## Key Technologies

- **Frontend:** React 18, Vite, TanStack Query, Tailwind CSS, shadcn/ui, Framer Motion
- **Backend:** Express.js v5, TypeScript, Drizzle ORM
- **Database:** PostgreSQL (Neon-backed on Replit)
- **AI:** OpenAI API (GPT models for recursive search logic)
- **Routing:** wouter (client-side)

## Mobile Optimization

- Viewport with `viewport-fit=cover` for safe areas
- 44px minimum touch targets
- Auto-collapsing sidebar on mobile
- PWA-ready with manifest
- Mobile-first responsive design

## Security Features

1. **SSRF Protection:** Blocks internal/private/metadata URLs in website scraper
2. **Input Validation:** Zod schemas validate all API inputs
3. **URL Validation:** Only HTTP/HTTPS protocols allowed
4. **Size Limits:** 500MB file upload limit
5. **Depth Limits:** Website crawling limited to prevent abuse

## Scripts

```bash
npm run dev      # Start development server
npm run build    # Build for production
npm run db:push  # Push schema to database
```
