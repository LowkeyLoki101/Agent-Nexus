# RLM Explorer - API Reference

Complete API documentation for all endpoints.

## Base URL

Development: `http://localhost:5000`

## Documents API

### List All Documents

```http
GET /api/documents
```

**Response:**
```json
[
  {
    "id": 1,
    "name": "example.txt",
    "content": "File content here...",
    "type": "text",
    "size": 1234,
    "language": null,
    "sourceType": "upload",
    "sourceUrl": null,
    "sourceTitle": null,
    "createdAt": "2026-01-19T02:00:00.000Z"
  }
]
```

### Get Single Document

```http
GET /api/documents/:id
```

**Response:** Single document object or 404

### Create Document (File Upload)

```http
POST /api/documents
Content-Type: application/json
```

**Request Body:**
```json
{
  "name": "myfile.txt",
  "content": "File content as string",
  "type": "text",
  "size": 1234,
  "language": "javascript"  // optional
}
```

**Response:** Created document object

### Delete Document

```http
DELETE /api/documents/:id
```

**Response:** `{ "success": true }`

---

## Queries API

### Get Queries for Document

```http
GET /api/documents/:id/queries
```

**Response:**
```json
[
  {
    "id": 1,
    "documentId": 1,
    "question": "What is the main function?",
    "answer": "The main function initializes...",
    "searchHistory": [...],
    "status": "completed",
    "totalDepth": 3,
    "totalDuration": 5234,
    "createdAt": "2026-01-19T02:00:00.000Z"
  }
]
```

### Create Query (Start RLM Search)

```http
POST /api/queries
Content-Type: application/json
```

**Request Body:**
```json
{
  "documentId": 1,
  "question": "What does this code do?"
}
```

**Response:** Created query object (status: "pending")

### Stream Query Results (SSE)

```http
GET /api/queries/:id/stream
```

**Response:** Server-Sent Events stream

**Event Types:**
```
event: step
data: {"depth":0,"action":"search","pattern":"function.*main","query":"Looking for main function","results":[...],"reasoning":"Starting with broad search"}

event: complete
data: {"answer":"The code implements...","totalDepth":3,"totalDuration":5234}

event: error
data: {"message":"Error description"}
```

---

## Import API

### Import YouTube Transcript

```http
POST /api/import/youtube
Content-Type: application/json
```

**Request Body:**
```json
{
  "url": "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
}
```

**Supported URL Formats:**
- `https://www.youtube.com/watch?v=VIDEO_ID`
- `https://youtu.be/VIDEO_ID`
- `https://www.youtube.com/embed/VIDEO_ID`
- `https://m.youtube.com/watch?v=VIDEO_ID`

**Response:**
```json
{
  "id": 2,
  "name": "Video Title",
  "content": "Transcript text here...",
  "type": "text",
  "size": 5678,
  "language": null,
  "sourceType": "youtube",
  "sourceUrl": "https://www.youtube.com/watch?v=VIDEO_ID",
  "sourceTitle": "Video Title",
  "createdAt": "2026-01-19T02:00:00.000Z"
}
```

**Error Responses:**
- `400`: Invalid YouTube URL
- `404`: No transcript available for this video
- `500`: Failed to extract transcript

### Import Website Content

```http
POST /api/import/website
Content-Type: application/json
```

**Request Body:**
```json
{
  "url": "https://example.com",
  "maxPages": 10,    // optional, default: 10
  "maxDepth": 2      // optional, default: 2
}
```

**Response:**
```json
{
  "id": 3,
  "name": "Example Domain",
  "content": "### Example Domain\n\n## Content\n...",
  "type": "text",
  "size": 213,
  "language": null,
  "sourceType": "website",
  "sourceUrl": "https://example.com",
  "sourceTitle": "Example Domain",
  "createdAt": "2026-01-19T02:00:00.000Z"
}
```

**SSRF Protection - Blocked URLs:**
- `localhost`, `127.0.0.1`
- Private IP ranges: `10.x.x.x`, `172.16-31.x.x`, `192.168.x.x`
- Link-local: `169.254.x.x`
- Cloud metadata: `169.254.169.254`, `metadata.google.internal`
- IPv6 loopback: `::1`

**Error Responses:**
- `400`: Invalid URL format or protocol
- `403`: SSRF blocked (internal/private URL)
- `500`: Failed to scrape website

---

## Error Response Format

All errors follow this format:

```json
{
  "message": "Human-readable error message",
  "code": "ERROR_CODE"
}
```

Common error codes:
- `INVALID_URL` - Malformed URL
- `INVALID_PROTOCOL` - Non-HTTP/HTTPS URL
- `SSRF_BLOCKED` - Internal/private URL blocked
- `NO_TRANSCRIPT` - YouTube video has no captions
- `NOT_FOUND` - Resource doesn't exist
- `VALIDATION_ERROR` - Request body validation failed

---

## Search Step Schema

Each search step in `searchHistory` follows this structure:

```typescript
interface SearchStep {
  depth: number;        // 0, 1, 2... (recursion level)
  action: string;       // 'search' | 'read' | 'refine' | 'analyze'
  pattern?: string;     // Regex pattern used (for 'search' action)
  query: string;        // What we're looking for
  results: Array<{
    lineNumber?: number;
    content: string;
    relevance?: number; // 0-1 score
  }>;
  reasoning?: string;   // AI's explanation of this step
  duration?: number;    // Milliseconds taken
}
```

---

## Rate Limits & Constraints

| Constraint | Value |
|------------|-------|
| Max file upload size | 500 MB |
| Max website pages to crawl | 10 (configurable) |
| Max website crawl depth | 2 (configurable) |
| SSE connection timeout | 5 minutes |
| API request timeout | 30 seconds |
