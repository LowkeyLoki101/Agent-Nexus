import { Plus, Search, FileCode, History, Settings, Layers, FileStack, Files } from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarFooter,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
} from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { DocumentList } from "./document-list";
import { DocumentUpload } from "./document-upload";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import type { Document } from "@shared/schema";
import type { ChatMode } from "@/App";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

interface AppSidebarProps {
  selectedDocumentId: number | null;
  onSelectDocument: (id: number) => void;
  selectedDocumentIds: Set<number>;
  onToggleSelection: (id: number) => void;
  chatMode: ChatMode;
  onChatModeChange: (mode: ChatMode) => void;
}

export function AppSidebar({ 
  selectedDocumentId, 
  onSelectDocument,
  selectedDocumentIds,
  onToggleSelection,
  chatMode,
  onChatModeChange,
}: AppSidebarProps) {
  const [uploadOpen, setUploadOpen] = useState(false);

  const { data: documents = [], isLoading } = useQuery<Document[]>({
    queryKey: ["/api/documents"],
  });

  return (
    <Sidebar className="border-r">
      <SidebarHeader className="border-b p-4">
        <div className="flex items-center gap-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-md bg-primary text-primary-foreground">
            <Layers className="h-5 w-5" />
          </div>
          <div>
            <h1 className="font-semibold text-sm">RLM Explorer</h1>
            <p className="text-xs text-muted-foreground">Recursive Language Model</p>
          </div>
        </div>
      </SidebarHeader>

      <SidebarContent>
        {/* Chat Mode Selector */}
        <SidebarGroup>
          <SidebarGroupLabel className="text-xs px-2">Chat Mode</SidebarGroupLabel>
          <SidebarGroupContent className="px-2 pb-2">
            <div className="flex flex-col gap-1">
              <Button
                variant={chatMode === "single" ? "default" : "ghost"}
                size="sm"
                className="justify-start"
                onClick={() => onChatModeChange("single")}
                data-testid="button-mode-single"
              >
                <FileCode className="h-4 w-4 mr-2" />
                This Document
              </Button>
              <Button
                variant={chatMode === "selected" ? "default" : "ghost"}
                size="sm"
                className="justify-start"
                onClick={() => onChatModeChange("selected")}
                disabled={selectedDocumentIds.size === 0}
                data-testid="button-mode-selected"
              >
                <FileStack className="h-4 w-4 mr-2" />
                Selected ({selectedDocumentIds.size})
              </Button>
              <Button
                variant={chatMode === "all" ? "default" : "ghost"}
                size="sm"
                className="justify-start"
                onClick={() => onChatModeChange("all")}
                disabled={documents.length === 0}
                data-testid="button-mode-all"
              >
                <Files className="h-4 w-4 mr-2" />
                All Documents ({documents.length})
              </Button>
            </div>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          <div className="flex items-center justify-between px-2 py-1">
            <SidebarGroupLabel className="text-xs">Documents</SidebarGroupLabel>
            <Badge variant="secondary" className="text-xs">
              {documents.length}
            </Badge>
          </div>

          <SidebarGroupContent>
            <Dialog open={uploadOpen} onOpenChange={setUploadOpen}>
              <DialogTrigger asChild>
                <Button
                  variant="outline"
                  size="sm"
                  className="w-full mx-2 mb-2"
                  data-testid="button-add-document"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Add Document
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[500px]">
                <DialogHeader>
                  <DialogTitle>Add Document</DialogTitle>
                </DialogHeader>
                <DocumentUpload
                  onDocumentCreated={(id) => {
                    setUploadOpen(false);
                    onSelectDocument(id);
                  }}
                />
              </DialogContent>
            </Dialog>

            <DocumentList
              documents={documents}
              selectedId={selectedDocumentId}
              onSelect={onSelectDocument}
              selectedIds={selectedDocumentIds}
              onToggleSelection={onToggleSelection}
              isLoading={isLoading}
            />
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup className="mt-auto">
          <SidebarGroupLabel className="text-xs">Quick Links</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              <SidebarMenuItem>
                <SidebarMenuButton asChild>
                  <a href="#" className="flex items-center gap-2">
                    <History className="h-4 w-4" />
                    <span>Query History</span>
                  </a>
                </SidebarMenuButton>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton asChild>
                  <a href="#" className="flex items-center gap-2">
                    <Search className="h-4 w-4" />
                    <span>Pattern Library</span>
                  </a>
                </SidebarMenuButton>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="border-t p-4">
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <FileCode className="h-4 w-4" />
          <span>Process 10M+ tokens efficiently</span>
        </div>
      </SidebarFooter>
    </Sidebar>
  );
}
