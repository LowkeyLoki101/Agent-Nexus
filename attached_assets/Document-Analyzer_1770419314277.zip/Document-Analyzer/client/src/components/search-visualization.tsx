import { Search, ChevronRight, Code, FileSearch, Zap, Clock, CheckCircle2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { motion, AnimatePresence } from "framer-motion";
import type { SearchStep } from "@shared/schema";

interface SearchVisualizationProps {
  steps: SearchStep[];
  isStreaming: boolean;
}

function getActionIcon(action: string) {
  switch (action) {
    case "search":
      return <Search className="h-4 w-4" />;
    case "read":
      return <FileSearch className="h-4 w-4" />;
    case "refine":
      return <ChevronRight className="h-4 w-4" />;
    case "analyze":
      return <Zap className="h-4 w-4" />;
    default:
      return <Code className="h-4 w-4" />;
  }
}

function getActionColor(action: string) {
  switch (action) {
    case "search":
      return "bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/20";
    case "read":
      return "bg-green-500/10 text-green-600 dark:text-green-400 border-green-500/20";
    case "refine":
      return "bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/20";
    case "analyze":
      return "bg-purple-500/10 text-purple-600 dark:text-purple-400 border-purple-500/20";
    default:
      return "bg-muted text-muted-foreground";
  }
}

function SearchStepCard({
  step,
  index,
  isLast,
  isStreaming,
}: {
  step: SearchStep;
  index: number;
  isLast: boolean;
  isStreaming: boolean;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: index * 0.1 }}
      className="relative"
    >
      {/* Connection line */}
      {!isLast && (
        <div className="absolute left-5 top-12 bottom-0 w-0.5 bg-border" />
      )}

      <div className="flex gap-3">
        {/* Depth indicator */}
        <div
          className={`flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center border-2 ${
            isLast && isStreaming
              ? "border-primary bg-primary/10 animate-pulse"
              : "border-muted bg-card"
          }`}
        >
          <span className="text-xs font-bold">{step.depth}</span>
        </div>

        {/* Step content */}
        <div className="flex-1 pb-6">
          <div className="flex items-center gap-2 mb-2">
            <Badge
              variant="outline"
              className={`flex items-center gap-1 ${getActionColor(step.action)}`}
            >
              {getActionIcon(step.action)}
              {step.action}
            </Badge>
            {step.duration && (
              <span className="text-xs text-muted-foreground flex items-center gap-1">
                <Clock className="h-3 w-3" />
                {step.duration}ms
              </span>
            )}
          </div>

          <p className="text-sm mb-2">{step.query}</p>

          {step.pattern && (
            <div className="mb-2">
              <code className="text-xs bg-muted px-2 py-1 rounded font-mono">
                {step.pattern}
              </code>
            </div>
          )}

          {step.results.length > 0 && (
            <div className="bg-muted/30 rounded-md p-3 space-y-2">
              <p className="text-xs text-muted-foreground font-medium">
                Found {step.results.length} result{step.results.length !== 1 ? "s" : ""}
              </p>
              <div className="space-y-1">
                {step.results.slice(0, 3).map((result, i) => (
                  <div
                    key={i}
                    className="text-xs font-mono bg-background/50 rounded p-2 overflow-hidden"
                  >
                    {result.lineNumber && (
                      <span className="text-muted-foreground mr-2">
                        L{result.lineNumber}:
                      </span>
                    )}
                    <span className="truncate">{result.content.slice(0, 100)}</span>
                    {result.content.length > 100 && "..."}
                  </div>
                ))}
                {step.results.length > 3 && (
                  <p className="text-xs text-muted-foreground">
                    +{step.results.length - 3} more results
                  </p>
                )}
              </div>
            </div>
          )}

          {step.reasoning && (
            <p className="text-xs text-muted-foreground mt-2 italic">
              {step.reasoning}
            </p>
          )}
        </div>
      </div>
    </motion.div>
  );
}

export function SearchVisualization({ steps, isStreaming }: SearchVisualizationProps) {
  const totalDuration = steps.reduce((acc, s) => acc + (s.duration || 0), 0);
  const maxDepth = Math.max(...steps.map((s) => s.depth), 0);

  return (
    <Card>
      <CardHeader className="pb-2 sm:pb-3 px-3 sm:px-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
          <CardTitle className="text-sm sm:text-base flex items-center gap-2 flex-wrap">
            <Search className="h-4 w-4 text-primary flex-shrink-0" />
            <span>Recursive Search</span>
            {isStreaming && (
              <Badge variant="secondary" className="animate-pulse text-xs">
                Processing...
              </Badge>
            )}
            {!isStreaming && steps.length > 0 && (
              <Badge variant="outline" className="flex items-center gap-1 text-xs">
                <CheckCircle2 className="h-3 w-3 text-green-500" />
                Done
              </Badge>
            )}
          </CardTitle>

          <div className="flex items-center gap-3 sm:gap-4 text-[10px] sm:text-xs text-muted-foreground">
            <span>Depth: {maxDepth}</span>
            <span>Steps: {steps.length}</span>
            {totalDuration > 0 && <span>{(totalDuration / 1000).toFixed(1)}s</span>}
          </div>
        </div>
      </CardHeader>

      <CardContent className="px-3 sm:px-6">
        <ScrollArea className="max-h-[300px] sm:max-h-[400px] pr-2 sm:pr-4">
          <AnimatePresence mode="popLayout">
            {steps.map((step, index) => (
              <SearchStepCard
                key={`${step.depth}-${step.action}-${index}`}
                step={step}
                index={index}
                isLast={index === steps.length - 1}
                isStreaming={isStreaming}
              />
            ))}
          </AnimatePresence>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
