import { useState, useRef, useEffect } from "react";
import { Send, Loader2, Sparkles, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import type { Document, Query, SearchStep } from "@shared/schema";
import type { ChatMode } from "@/App";
import { SearchVisualization } from "./search-visualization";
import { ResultsDisplay } from "./results-display";

interface QueryInterfaceProps {
  documents: Document[];
  chatMode: ChatMode;
}

export function QueryInterface({ documents, chatMode }: QueryInterfaceProps) {
  const [question, setQuestion] = useState("");
  const [submittedQuestion, setSubmittedQuestion] = useState("");
  const [currentQuery, setCurrentQuery] = useState<Query | null>(null);
  const [searchSteps, setSearchSteps] = useState<SearchStep[]>([]);
  const [isStreaming, setIsStreaming] = useState(false);
  const [answer, setAnswer] = useState("");
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const queryMutation = useMutation({
    mutationFn: async (data: { documentIds: number[]; question: string }) => {
      setIsStreaming(true);
      setSearchSteps([]);
      setAnswer("");

      const response = await fetch("/api/queries/multi", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });

      if (!response.ok) {
        throw new Error("Query failed");
      }

      const reader = response.body?.getReader();
      if (!reader) throw new Error("No response body");

      const decoder = new TextDecoder();
      let buffer = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() || "";

        for (const line of lines) {
          if (!line.startsWith("data: ")) continue;

          try {
            const event = JSON.parse(line.slice(6));

            switch (event.type) {
              case "step":
                setSearchSteps((prev) => [...prev, event.data as SearchStep]);
                break;
              case "answer":
                setAnswer((prev) => prev + event.data);
                break;
              case "complete":
                setCurrentQuery(event.query);
                break;
              case "error":
                throw new Error(event.message);
            }
          } catch (e) {
            if (!(e instanceof SyntaxError)) {
              throw e;
            }
          }
        }
      }

      setIsStreaming(false);
    },
    onError: (error) => {
      setIsStreaming(false);
      toast({
        title: "Query failed",
        description: error instanceof Error ? error.message : "An error occurred",
        variant: "destructive",
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/queries"] });
    },
  });

  const handleSubmit = () => {
    if (!question.trim() || isStreaming || documents.length === 0) return;
    const q = question.trim();
    setSubmittedQuestion(q);
    setQuestion("");
    queryMutation.mutate({
      documentIds: documents.map(d => d.id),
      question: q,
    });
  };

  // Auto-scroll when new content arrives
  useEffect(() => {
    if (contentRef.current && (searchSteps.length > 0 || answer)) {
      contentRef.current.scrollTop = contentRef.current.scrollHeight;
    }
  }, [searchSteps, answer]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  const handleReset = () => {
    setQuestion("");
    setSubmittedQuestion("");
    setCurrentQuery(null);
    setSearchSteps([]);
    setAnswer("");
    textareaRef.current?.focus();
  };

  const exampleQuestions = [
    "What are the main functions in this code?",
    "Find all TODO comments",
    "What patterns are used here?",
    "Summarize the structure",
  ];

  const totalSize = documents.reduce((sum, d) => sum + d.size, 0);
  const modeLabel = chatMode === "all" ? "All Documents" : chatMode === "selected" ? "Selected Documents" : "Single Document";
  const firstDoc = documents[0];

  if (documents.length === 0) {
    return <div className="flex items-center justify-center h-full text-muted-foreground">No documents selected</div>;
  }

  return (
    <div className="flex flex-col h-full">
      {/* Header - Mobile optimized */}
      <div className="flex-shrink-0 border-b p-3 sm:p-4">
        <div className="flex items-center justify-between gap-2 sm:gap-4">
          <div className="flex-1 min-w-0">
            <h2 className="text-base sm:text-lg font-semibold truncate">
              {documents.length === 1 ? firstDoc.name : `${documents.length} Documents`}
            </h2>
            <div className="flex items-center gap-1.5 sm:gap-2 mt-1 flex-wrap">
              <Badge variant="secondary" className="text-xs">{modeLabel}</Badge>
              {documents.length === 1 && firstDoc.language && (
                <Badge variant="outline" className="text-xs">{firstDoc.language}</Badge>
              )}
              <span className="text-[10px] sm:text-xs text-muted-foreground">
                {totalSize.toLocaleString()} chars
              </span>
            </div>
          </div>
          {(currentQuery || searchSteps.length > 0 || submittedQuestion) && (
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={handleReset} 
              data-testid="button-reset-query"
              className="min-h-[44px] min-w-[44px] px-2 sm:px-3"
            >
              <RotateCcw className="h-4 w-4 sm:mr-1" />
              <span className="hidden sm:inline">New Query</span>
            </Button>
          )}
        </div>
      </div>

      {/* Main Content - Mobile optimized */}
      <div ref={contentRef} className="flex-1 overflow-auto p-3 sm:p-4 space-y-3 sm:space-y-4">
        {/* Empty State - Mobile optimized */}
        {!submittedQuestion && searchSteps.length === 0 && !answer && (
          <Card className="border-dashed">
            <CardHeader className="pb-2 px-3 sm:px-6">
              <CardTitle className="text-sm sm:text-base flex items-center gap-2">
                <Sparkles className="h-4 w-4 text-primary" />
                Recursive Language Model
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 sm:space-y-4 px-3 sm:px-6">
              <p className="text-xs sm:text-sm text-muted-foreground">
                Ask questions about your document. The AI will recursively search
                through the content to find comprehensive answers.
              </p>

              <div className="flex flex-col sm:flex-row sm:flex-wrap gap-2">
                {exampleQuestions.map((q) => (
                  <Button
                    key={q}
                    variant="outline"
                    size="default"
                    className="text-xs sm:text-sm min-h-[44px] justify-start sm:justify-center text-left sm:text-center"
                    onClick={() => setQuestion(q)}
                    data-testid={`button-example-${q.slice(0, 10)}`}
                  >
                    {q}
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* User Message Bubble */}
        {submittedQuestion && (
          <div className="flex justify-end" data-testid="user-message">
            <div className="bg-primary text-primary-foreground rounded-2xl rounded-tr-md px-4 py-2.5 max-w-[85%] sm:max-w-[75%]">
              <p className="text-sm sm:text-base whitespace-pre-wrap">{submittedQuestion}</p>
            </div>
          </div>
        )}

        {/* AI Response Section */}
        {submittedQuestion && (
          <div className="space-y-3">
            {/* Thinking/Processing Indicator */}
            {isStreaming && searchSteps.length === 0 && !answer && (
              <div className="flex items-center gap-2 text-muted-foreground" data-testid="ai-thinking">
                <Loader2 className="h-4 w-4 animate-spin" />
                <span className="text-sm">Analyzing document...</span>
              </div>
            )}

            {/* Search Visualization */}
            {searchSteps.length > 0 && (
              <SearchVisualization steps={searchSteps} isStreaming={isStreaming} />
            )}

            {/* Results */}
            {(answer || currentQuery?.answer) && (
              <ResultsDisplay
                answer={answer || currentQuery?.answer || ""}
                query={currentQuery}
                isStreaming={isStreaming}
              />
            )}
          </div>
        )}
      </div>

      {/* Query Input - Mobile optimized with larger touch targets */}
      <div className="flex-shrink-0 border-t p-3 sm:p-4 bg-background safe-area-inset-bottom">
        <div className="flex gap-2">
          <Textarea
            ref={textareaRef}
            placeholder="Ask a question about this document..."
            className="min-h-[56px] sm:min-h-[60px] max-h-[120px] resize-none text-base"
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            onKeyDown={handleKeyDown}
            disabled={isStreaming}
            data-testid="textarea-query-input"
          />
          <Button
            size="icon"
            className="h-[56px] w-[56px] sm:h-[60px] sm:w-[60px] min-h-[44px] min-w-[44px] flex-shrink-0"
            onClick={handleSubmit}
            disabled={!question.trim() || isStreaming}
            data-testid="button-submit-query"
          >
            <Send className="h-5 w-5" />
          </Button>
        </div>
        <p className="text-[10px] sm:text-xs text-muted-foreground mt-2 hidden sm:block">
          Press Enter to send, Shift+Enter for new line
        </p>
      </div>
    </div>
  );
}
