import { CheckCircle2, Copy, Clock, Layers, Route } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import ReactMarkdown from "react-markdown";
import type { Query } from "@shared/schema";

interface ResultsDisplayProps {
  answer: string;
  query: Query | null;
  isStreaming: boolean;
}

export function ResultsDisplay({ answer, query, isStreaming }: ResultsDisplayProps) {
  const { toast } = useToast();

  const handleCopy = () => {
    navigator.clipboard.writeText(answer);
    toast({ title: "Copied to clipboard" });
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2">
            <CheckCircle2 className="h-4 w-4 text-green-500" />
            Answer
            {isStreaming && (
              <Badge variant="secondary" className="animate-pulse">
                Generating...
              </Badge>
            )}
          </CardTitle>

          <div className="flex items-center gap-2">
            {query && (
              <div className="flex items-center gap-4 text-xs text-muted-foreground mr-2">
                {query.totalDepth !== null && query.totalDepth > 0 && (
                  <span className="flex items-center gap-1">
                    <Layers className="h-3 w-3" />
                    {query.totalDepth} depth
                  </span>
                )}
                {query.totalDuration && (
                  <span className="flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    {(query.totalDuration / 1000).toFixed(1)}s
                  </span>
                )}
                {query.searchHistory && (
                  <span className="flex items-center gap-1">
                    <Route className="h-3 w-3" />
                    {query.searchHistory.length} steps
                  </span>
                )}
              </div>
            )}
            <Button
              variant="ghost"
              size="icon"
              onClick={handleCopy}
              disabled={isStreaming}
              data-testid="button-copy-answer"
            >
              <Copy className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardHeader>

      <CardContent>
        <div className="prose prose-sm dark:prose-invert max-w-none">
          <ReactMarkdown
            components={{
              h1: ({ children }) => <h1 className="text-xl font-bold mt-4 mb-2">{children}</h1>,
              h2: ({ children }) => <h2 className="text-lg font-bold mt-4 mb-2">{children}</h2>,
              h3: ({ children }) => <h3 className="text-base font-semibold mt-3 mb-1">{children}</h3>,
              p: ({ children }) => <p className="mb-2 leading-relaxed">{children}</p>,
              ul: ({ children }) => <ul className="list-disc pl-5 mb-2 space-y-1">{children}</ul>,
              ol: ({ children }) => <ol className="list-decimal pl-5 mb-2 space-y-1">{children}</ol>,
              li: ({ children }) => <li className="leading-relaxed">{children}</li>,
              strong: ({ children }) => <strong className="font-semibold">{children}</strong>,
              em: ({ children }) => <em className="italic">{children}</em>,
              code: ({ className, children }) => {
                const isBlock = className?.includes("language-");
                if (isBlock) {
                  return (
                    <pre className="my-3 p-4 bg-muted/50 rounded-md overflow-x-auto text-sm">
                      <code className="font-mono">{children}</code>
                    </pre>
                  );
                }
                return (
                  <code className="px-1.5 py-0.5 bg-muted rounded text-sm font-mono">
                    {children}
                  </code>
                );
              },
              pre: ({ children }) => <>{children}</>,
            }}
          >
            {answer}
          </ReactMarkdown>
          {isStreaming && (
            <span className="inline-block w-2 h-4 bg-primary animate-pulse ml-0.5" />
          )}
        </div>
      </CardContent>
    </Card>
  );
}
