import { FileCode, FileJson, FileText, File, Trash2, Clock, Database, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Document } from "@shared/schema";

interface DocumentListProps {
  documents: Document[];
  selectedId: number | null;
  onSelect: (id: number) => void;
  selectedIds: Set<number>;
  onToggleSelection: (id: number) => void;
  isLoading?: boolean;
}

function getDocumentIcon(type: string) {
  switch (type) {
    case "code":
      return <FileCode className="h-4 w-4" />;
    case "json":
      return <FileJson className="h-4 w-4" />;
    case "markdown":
      return <FileText className="h-4 w-4" />;
    default:
      return <File className="h-4 w-4" />;
  }
}

function formatSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function formatDate(date: Date | string): string {
  const d = new Date(date);
  return d.toLocaleDateString(undefined, { month: "short", day: "numeric" });
}

export function DocumentList({
  documents,
  selectedId,
  onSelect,
  selectedIds,
  onToggleSelection,
  isLoading,
}: DocumentListProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/documents/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/documents"] });
      toast({ title: "Document deleted" });
    },
    onError: () => {
      toast({
        title: "Delete failed",
        description: "Could not delete the document.",
        variant: "destructive",
      });
    },
  });

  if (isLoading) {
    return (
      <div className="flex flex-col gap-2 p-2">
        {[1, 2, 3].map((i) => (
          <div
            key={i}
            className="h-16 rounded-md bg-muted/50 animate-pulse"
          />
        ))}
      </div>
    );
  }

  if (documents.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-12 px-4 text-center">
        <Database className="h-10 w-10 text-muted-foreground/40 mb-3" />
        <p className="text-sm font-medium text-muted-foreground">No documents yet</p>
        <p className="text-xs text-muted-foreground/70 mt-1">
          Upload a file or paste content to get started
        </p>
      </div>
    );
  }

  return (
    <ScrollArea className="h-[calc(100vh-380px)]">
      <div className="flex flex-col gap-1 p-2">
        {documents.map((doc) => (
          <div
            key={doc.id}
            className={`group relative flex items-start gap-2 p-3 rounded-md cursor-pointer transition-colors hover-elevate ${
              selectedId === doc.id
                ? "bg-primary/10 border border-primary/20"
                : selectedIds.has(doc.id)
                ? "bg-muted/70 border border-muted-foreground/20"
                : "hover:bg-muted/50"
            }`}
            onClick={() => onSelect(doc.id)}
            data-testid={`document-item-${doc.id}`}
          >
            <Checkbox
              checked={selectedIds.has(doc.id)}
              onCheckedChange={() => onToggleSelection(doc.id)}
              onClick={(e) => e.stopPropagation()}
              className="mt-1 flex-shrink-0"
              data-testid={`checkbox-document-${doc.id}`}
            />
            
            <div
              className={`flex-shrink-0 p-2 rounded-md ${
                selectedId === doc.id
                  ? "bg-primary/20 text-primary"
                  : "bg-muted text-muted-foreground"
              }`}
            >
              {getDocumentIcon(doc.type)}
            </div>

            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">{doc.name}</p>
              <div className="flex items-center gap-2 mt-1">
                <Badge variant="secondary" className="text-xs">
                  {doc.type}
                </Badge>
                {doc.language && (
                  <Badge variant="outline" className="text-xs">
                    {doc.language}
                  </Badge>
                )}
              </div>
              <div className="flex items-center gap-3 mt-2 text-xs text-muted-foreground">
                <span>{formatSize(doc.size)}</span>
                <span className="flex items-center gap-1">
                  <Clock className="h-3 w-3" />
                  {formatDate(doc.createdAt)}
                </span>
              </div>
            </div>

            <Button
              variant="ghost"
              size="icon"
              className="opacity-0 group-hover:opacity-100 transition-opacity absolute top-2 right-2"
              onClick={(e) => {
                e.stopPropagation();
                deleteMutation.mutate(doc.id);
              }}
              disabled={deleteMutation.isPending}
              data-testid={`button-delete-document-${doc.id}`}
            >
              <Trash2 className="h-4 w-4 text-destructive" />
            </Button>
          </div>
        ))}
      </div>
    </ScrollArea>
  );
}
