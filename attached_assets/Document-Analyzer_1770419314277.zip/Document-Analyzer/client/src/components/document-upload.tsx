import { useState, useRef, useCallback } from "react";
import { Upload, FileCode, FileText, FileJson, X, Loader2, Youtube, Globe, Archive } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface DocumentUploadProps {
  onDocumentCreated?: (id: number) => void;
}

function detectLanguage(filename: string): string | null {
  const ext = filename.split(".").pop()?.toLowerCase();
  const languageMap: Record<string, string> = {
    js: "javascript",
    jsx: "javascript",
    ts: "typescript",
    tsx: "typescript",
    py: "python",
    rb: "ruby",
    go: "go",
    rs: "rust",
    java: "java",
    cpp: "cpp",
    c: "c",
    cs: "csharp",
    php: "php",
    swift: "swift",
    kt: "kotlin",
    scala: "scala",
    sql: "sql",
    sh: "bash",
    bash: "bash",
    zsh: "zsh",
    yml: "yaml",
    yaml: "yaml",
    json: "json",
    xml: "xml",
    html: "html",
    css: "css",
    scss: "scss",
    less: "less",
    md: "markdown",
    vue: "vue",
    svelte: "svelte",
  };
  return languageMap[ext || ""] || null;
}

function detectType(filename: string): string {
  const ext = filename.split(".").pop()?.toLowerCase();
  if (ext === "json") return "json";
  if (ext === "md" || ext === "markdown") return "markdown";
  const codeExtensions = [
    "js", "jsx", "ts", "tsx", "py", "rb", "go", "rs", "java",
    "cpp", "c", "cs", "php", "swift", "kt", "scala", "sql",
    "sh", "bash", "zsh", "vue", "svelte", "html", "css", "scss", "less",
  ];
  if (codeExtensions.includes(ext || "")) return "code";
  return "text";
}

function formatFileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  return `${(bytes / (1024 * 1024 * 1024)).toFixed(2)} GB`;
}

export function DocumentUpload({ onDocumentCreated }: DocumentUploadProps) {
  const [activeTab, setActiveTab] = useState<string>("upload");
  const [dragActive, setDragActive] = useState(false);
  const [pastedContent, setPastedContent] = useState("");
  const [pastedName, setPastedName] = useState("");
  const [youtubeUrl, setYoutubeUrl] = useState("");
  const [websiteUrl, setWebsiteUrl] = useState("");
  const [uploadProgress, setUploadProgress] = useState<string>("");
  const [selectedFile, setSelectedFile] = useState<{ name: string; size: number } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const uploadMutation = useMutation({
    mutationFn: async (data: {
      name: string;
      content: string;
      type: string;
      size: number;
      language: string | null;
    }) => {
      setUploadProgress("Uploading...");
      const res = await apiRequest("POST", "/api/documents", data);
      setUploadProgress("");
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/documents"] });
      const sizeStr = formatFileSize(data.size);
      toast({
        title: "Document uploaded",
        description: `"${data.name}" (${sizeStr}) is ready for analysis.`,
      });
      onDocumentCreated?.(data.id);
      setPastedContent("");
      setPastedName("");
      setSelectedFile(null);
    },
    onError: () => {
      setUploadProgress("");
      setSelectedFile(null);
      toast({
        title: "Upload failed",
        description: "Could not upload the document. Please try again.",
        variant: "destructive",
      });
    },
  });

  const youtubeMutation = useMutation({
    mutationFn: async (url: string) => {
      const res = await apiRequest("POST", "/api/import/youtube", { url });
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/documents"] });
      toast({
        title: "YouTube video imported",
        description: `"${data.name}" is ready for analysis.`,
      });
      onDocumentCreated?.(data.id);
      setYoutubeUrl("");
    },
    onError: (error: any) => {
      toast({
        title: "Import failed",
        description: error.message || "Could not import YouTube video.",
        variant: "destructive",
      });
    },
  });

  const websiteMutation = useMutation({
    mutationFn: async (url: string) => {
      // Auto-add https:// if missing
      let normalizedUrl = url.trim();
      if (!normalizedUrl.startsWith('http://') && !normalizedUrl.startsWith('https://')) {
        normalizedUrl = 'https://' + normalizedUrl;
      }
      const res = await apiRequest("POST", "/api/import/website", { url: normalizedUrl });
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/documents"] });
      toast({
        title: "Website imported",
        description: `"${data.name}" is ready for analysis.`,
      });
      onDocumentCreated?.(data.id);
      setWebsiteUrl("");
    },
    onError: (error: any) => {
      toast({
        title: "Import failed",
        description: error.message || "Could not import website.",
        variant: "destructive",
      });
    },
  });

  const zipMutation = useMutation({
    mutationFn: async (file: File) => {
      setUploadProgress("Reading zip file...");
      const arrayBuffer = await file.arrayBuffer();
      const base64 = btoa(
        new Uint8Array(arrayBuffer).reduce((data, byte) => data + String.fromCharCode(byte), "")
      );
      setUploadProgress("Extracting files...");
      const res = await apiRequest("POST", "/api/import/zip", { 
        data: base64, 
        filename: file.name 
      });
      setUploadProgress("");
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/documents"] });
      toast({
        title: "Zip imported",
        description: `Extracted ${data.count} files${data.skipped > 0 ? ` (${data.skipped} skipped)` : ""}.`,
      });
      if (data.documents?.length > 0) {
        onDocumentCreated?.(data.documents[0].id);
      }
      setSelectedFile(null);
    },
    onError: (error: any) => {
      setUploadProgress("");
      setSelectedFile(null);
      toast({
        title: "Zip import failed",
        description: error.message || "Could not extract zip file.",
        variant: "destructive",
      });
    },
  });

  const handleFiles = useCallback(
    async (files: FileList | null) => {
      if (!files || files.length === 0) return;

      const file = files[0];
      setSelectedFile({ name: file.name, size: file.size });
      
      // Check if it's a zip file
      const ext = file.name.split(".").pop()?.toLowerCase();
      if (ext === "zip") {
        zipMutation.mutate(file);
        return;
      }
      
      setUploadProgress(`Reading ${formatFileSize(file.size)}...`);
      
      const content = await file.text();
      const type = detectType(file.name);
      const language = detectLanguage(file.name);

      uploadMutation.mutate({
        name: file.name,
        content,
        type,
        size: content.length,
        language,
      });
    },
    [uploadMutation, zipMutation]
  );

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  }, []);

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      e.stopPropagation();
      setDragActive(false);
      handleFiles(e.dataTransfer.files);
    },
    [handleFiles]
  );

  const handlePasteSubmit = () => {
    if (!pastedContent.trim()) {
      toast({
        title: "No content",
        description: "Please paste some content first.",
        variant: "destructive",
      });
      return;
    }

    const name = pastedName.trim() || `Pasted content - ${new Date().toLocaleDateString()}`;
    const type = detectType(name);
    const language = detectLanguage(name);

    uploadMutation.mutate({
      name,
      content: pastedContent,
      type,
      size: pastedContent.length,
      language,
    });
  };

  const isLoading = uploadMutation.isPending || youtubeMutation.isPending || websiteMutation.isPending || zipMutation.isPending;

  return (
    <Card className="border-dashed">
      <CardContent className="p-3 sm:p-4">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-4 mb-3 sm:mb-4 h-11">
            <TabsTrigger value="upload" data-testid="tab-upload" className="min-h-[44px] text-xs sm:text-sm">
              <Upload className="h-4 w-4 mr-1" />
              <span className="hidden sm:inline">Upload</span>
            </TabsTrigger>
            <TabsTrigger value="paste" data-testid="tab-paste" className="min-h-[44px] text-xs sm:text-sm">
              <FileText className="h-4 w-4 mr-1" />
              <span className="hidden sm:inline">Paste</span>
            </TabsTrigger>
            <TabsTrigger value="youtube" data-testid="tab-youtube" className="min-h-[44px] text-xs sm:text-sm">
              <Youtube className="h-4 w-4 mr-1" />
              <span className="hidden sm:inline">YouTube</span>
            </TabsTrigger>
            <TabsTrigger value="website" data-testid="tab-website" className="min-h-[44px] text-xs sm:text-sm">
              <Globe className="h-4 w-4 mr-1" />
              <span className="hidden sm:inline">Website</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="upload" className="mt-0">
            <div
              className={`relative border-2 border-dashed rounded-md p-6 sm:p-8 text-center transition-colors ${
                dragActive
                  ? "border-primary bg-primary/5"
                  : "border-muted-foreground/25 active:border-primary"
              }`}
              onDragEnter={handleDrag}
              onDragLeave={handleDrag}
              onDragOver={handleDrag}
              onDrop={handleDrop}
              onClick={() => !isLoading && fileInputRef.current?.click()}
            >
              <input
                ref={fileInputRef}
                type="file"
                className="hidden"
                onChange={(e) => handleFiles(e.target.files)}
                accept=".js,.jsx,.ts,.tsx,.py,.rb,.go,.rs,.java,.cpp,.c,.cs,.php,.swift,.kt,.scala,.sql,.sh,.bash,.json,.yml,.yaml,.xml,.html,.css,.scss,.less,.md,.txt,.vue,.svelte,.zip"
                data-testid="input-file-upload"
              />

              {isLoading ? (
                <div className="flex flex-col items-center gap-3">
                  <Loader2 className="h-8 w-8 sm:h-10 sm:w-10 text-primary animate-spin" />
                  <p className="text-xs sm:text-sm text-muted-foreground">Processing file...</p>
                </div>
              ) : (
                <div className="flex flex-col items-center gap-2 sm:gap-3">
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <FileCode className="h-6 w-6 sm:h-8 sm:w-8" />
                    <FileJson className="h-6 w-6 sm:h-8 sm:w-8" />
                    <FileText className="h-6 w-6 sm:h-8 sm:w-8" />
                  </div>
                  <div>
                    <p className="text-xs sm:text-sm font-medium">
                      Tap to select a file
                    </p>
                    <p className="text-[10px] sm:text-xs text-muted-foreground mt-1">
                      Code, JSON, Markdown, text files
                    </p>
                  </div>
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="paste" className="mt-0 space-y-2 sm:space-y-3">
            <Input
              placeholder="Document name (optional)"
              value={pastedName}
              onChange={(e) => setPastedName(e.target.value)}
              data-testid="input-document-name"
              className="min-h-[44px] text-base"
            />
            <Textarea
              placeholder="Paste your code, text, or data here..."
              className="min-h-[150px] sm:min-h-[200px] font-mono text-sm"
              value={pastedContent}
              onChange={(e) => setPastedContent(e.target.value)}
              data-testid="textarea-paste-content"
            />
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <p className="text-[10px] sm:text-xs text-muted-foreground">
                {pastedContent.length.toLocaleString()} chars
              </p>
              <div className="flex gap-2">
                {pastedContent && (
                  <Button
                    variant="ghost"
                    size="default"
                    onClick={() => {
                      setPastedContent("");
                      setPastedName("");
                    }}
                    data-testid="button-clear-paste"
                    className="min-h-[44px]"
                  >
                    <X className="h-4 w-4 mr-1" />
                    Clear
                  </Button>
                )}
                <Button
                  size="default"
                  onClick={handlePasteSubmit}
                  disabled={isLoading || !pastedContent.trim()}
                  data-testid="button-submit-paste"
                  className="min-h-[44px]"
                >
                  {isLoading ? (
                    <Loader2 className="h-4 w-4 mr-1 animate-spin" />
                  ) : (
                    <Upload className="h-4 w-4 mr-1" />
                  )}
                  Add
                </Button>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="youtube" className="mt-0 space-y-2 sm:space-y-3">
            <div className="space-y-2">
              <Input
                placeholder="Paste YouTube URL (e.g., youtube.com/watch?v=...)"
                value={youtubeUrl}
                onChange={(e) => setYoutubeUrl(e.target.value)}
                data-testid="input-youtube-url"
                className="min-h-[44px] text-base"
              />
              <p className="text-[10px] sm:text-xs text-muted-foreground">
                Extracts the video transcript for AI analysis
              </p>
            </div>
            <div className="flex justify-end">
              <Button
                size="default"
                onClick={() => youtubeMutation.mutate(youtubeUrl)}
                disabled={youtubeMutation.isPending || !youtubeUrl.trim()}
                data-testid="button-import-youtube"
                className="min-h-[44px]"
              >
                {youtubeMutation.isPending ? (
                  <Loader2 className="h-4 w-4 mr-1 animate-spin" />
                ) : (
                  <Youtube className="h-4 w-4 mr-1" />
                )}
                Import
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="website" className="mt-0 space-y-2 sm:space-y-3">
            <div className="space-y-2">
              <Input
                placeholder="Enter website URL (e.g., https://example.com)"
                value={websiteUrl}
                onChange={(e) => setWebsiteUrl(e.target.value)}
                data-testid="input-website-url"
                className="min-h-[44px] text-base"
              />
              <p className="text-[10px] sm:text-xs text-muted-foreground">
                Scrapes and extracts text content from the website
              </p>
            </div>
            <div className="flex justify-end">
              <Button
                size="default"
                onClick={() => websiteMutation.mutate(websiteUrl)}
                disabled={websiteMutation.isPending || !websiteUrl.trim()}
                data-testid="button-import-website"
                className="min-h-[44px]"
              >
                {websiteMutation.isPending ? (
                  <Loader2 className="h-4 w-4 mr-1 animate-spin" />
                ) : (
                  <Globe className="h-4 w-4 mr-1" />
                )}
                Import
              </Button>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}
