import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Layers, FileCode, Sparkles, Zap, Search, ArrowRight } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { QueryInterface } from "@/components/query-interface";
import { DocumentUpload } from "@/components/document-upload";
import type { Document } from "@shared/schema";
import type { ChatMode } from "@/App";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

interface HomeProps {
  selectedDocumentId: number | null;
  onSelectDocument: (id: number) => void;
  selectedDocumentIds: Set<number>;
  chatMode: ChatMode;
}

function EmptyState({ onUpload }: { onUpload: () => void }) {
  const features = [
    {
      icon: Layers,
      title: "Infinite Context",
      description: "Process 10M+ tokens without quality loss",
    },
    {
      icon: Search,
      title: "Recursive Search",
      description: "AI iteratively drills down to find answers",
    },
    {
      icon: Zap,
      title: "Cost Efficient",
      description: "Only processes relevant sections",
    },
  ];

  return (
    <div className="flex flex-col items-center justify-center h-full p-4 sm:p-8 overflow-auto">
      <div className="max-w-2xl text-center w-full">
        <div className="inline-flex items-center justify-center w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-primary/10 mb-4 sm:mb-6">
          <Sparkles className="h-6 w-6 sm:h-8 sm:w-8 text-primary" />
        </div>

        <h2 className="text-xl sm:text-2xl font-bold mb-2 sm:mb-3">
          RLM Explorer
        </h2>
        <p className="text-sm sm:text-base text-muted-foreground mb-6 sm:mb-8 max-w-md mx-auto px-2">
          Upload codebases or documents. Ask questions and watch the AI
          recursively search to find precise answers.
        </p>

        <div className="grid gap-3 sm:gap-4 grid-cols-1 sm:grid-cols-3 mb-6 sm:mb-8">
          {features.map((feature) => (
            <Card key={feature.title} className="text-left">
              <CardHeader className="pb-2 p-3 sm:p-4">
                <div className="flex items-center gap-2">
                  <div className="p-1.5 rounded-md bg-primary/10 flex-shrink-0">
                    <feature.icon className="h-4 w-4 text-primary" />
                  </div>
                  <CardTitle className="text-xs sm:text-sm">{feature.title}</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="p-3 sm:p-4 pt-0 sm:pt-0">
                <p className="text-[11px] sm:text-xs text-muted-foreground">
                  {feature.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>

        <Button 
          size="lg" 
          onClick={onUpload} 
          data-testid="button-get-started"
          className="min-h-[48px] w-full sm:w-auto text-sm sm:text-base px-6"
        >
          <FileCode className="h-4 w-4 mr-2" />
          Upload Document
          <ArrowRight className="h-4 w-4 ml-2" />
        </Button>
      </div>
    </div>
  );
}

export default function Home({ selectedDocumentId, onSelectDocument, selectedDocumentIds, chatMode }: HomeProps) {
  const [uploadOpen, setUploadOpen] = useState(false);

  const { data: document } = useQuery<Document>({
    queryKey: ["/api/documents", selectedDocumentId],
    enabled: !!selectedDocumentId,
  });

  const { data: allDocuments = [] } = useQuery<Document[]>({
    queryKey: ["/api/documents"],
  });

  // Determine which documents to use based on chat mode
  const getActiveDocuments = (): Document[] => {
    if (chatMode === "all") {
      return allDocuments;
    } else if (chatMode === "selected") {
      return allDocuments.filter(d => selectedDocumentIds.has(d.id));
    } else if (document) {
      return [document];
    }
    return [];
  };

  const activeDocuments = getActiveDocuments();
  const hasActiveDocuments = activeDocuments.length > 0;
  const hasAnyDocuments = allDocuments.length > 0;

  // Show "select documents" message in selected mode with no selections
  if (!hasActiveDocuments && chatMode === "selected" && hasAnyDocuments) {
    return (
      <div className="flex flex-col items-center justify-center h-full p-4 sm:p-8 text-center">
        <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-primary/10 mb-4">
          <Layers className="h-6 w-6 text-primary" />
        </div>
        <h2 className="text-lg font-semibold mb-2">No Documents Selected</h2>
        <p className="text-sm text-muted-foreground max-w-sm">
          Use the checkboxes in the sidebar to select documents for multi-document chat.
        </p>
      </div>
    );
  }

  if (!hasActiveDocuments) {
    return (
      <>
        <EmptyState onUpload={() => setUploadOpen(true)} />
        <Dialog open={uploadOpen} onOpenChange={setUploadOpen}>
          <DialogContent className="w-[calc(100vw-2rem)] max-w-[500px] max-h-[85vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Add Document</DialogTitle>
            </DialogHeader>
            <DocumentUpload
              onDocumentCreated={(id) => {
                setUploadOpen(false);
                onSelectDocument(id);
              }}
            />
          </DialogContent>
        </Dialog>
      </>
    );
  }

  return <QueryInterface documents={activeDocuments} chatMode={chatMode} />;
}
