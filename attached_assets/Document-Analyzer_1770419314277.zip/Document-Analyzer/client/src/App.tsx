import { useState, useEffect } from "react";
import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { SidebarProvider, SidebarTrigger, useSidebar } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/app-sidebar";
import { ThemeToggle } from "@/components/theme-toggle";
import Home from "@/pages/home";
import NotFound from "@/pages/not-found";

export type ChatMode = "single" | "selected" | "all";

function Router({
  selectedDocumentId,
  onSelectDocument,
  selectedDocumentIds,
  chatMode,
}: {
  selectedDocumentId: number | null;
  onSelectDocument: (id: number) => void;
  selectedDocumentIds: Set<number>;
  chatMode: ChatMode;
}) {
  return (
    <Switch>
      <Route path="/">
        <Home
          selectedDocumentId={selectedDocumentId}
          onSelectDocument={onSelectDocument}
          selectedDocumentIds={selectedDocumentIds}
          chatMode={chatMode}
        />
      </Route>
      <Route component={NotFound} />
    </Switch>
  );
}

function MobileHeader() {
  return (
    <header className="flex items-center justify-between h-12 sm:h-14 px-3 sm:px-4 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50">
      <SidebarTrigger data-testid="button-sidebar-toggle" className="h-10 w-10 min-h-[44px] min-w-[44px]" />
      <ThemeToggle />
    </header>
  );
}

function AppContent({
  selectedDocumentId,
  setSelectedDocumentId,
  selectedDocumentIds,
  setSelectedDocumentIds,
  chatMode,
  setChatMode,
}: {
  selectedDocumentId: number | null;
  setSelectedDocumentId: (id: number | null) => void;
  selectedDocumentIds: Set<number>;
  setSelectedDocumentIds: (ids: Set<number>) => void;
  chatMode: ChatMode;
  setChatMode: (mode: ChatMode) => void;
}) {
  const { setOpenMobile } = useSidebar();

  const handleSelectDocument = (id: number) => {
    setSelectedDocumentId(id);
    setChatMode("single");
    setOpenMobile(false);
  };

  const handleToggleDocumentSelection = (id: number) => {
    const newSet = new Set(selectedDocumentIds);
    if (newSet.has(id)) {
      newSet.delete(id);
    } else {
      newSet.add(id);
    }
    setSelectedDocumentIds(newSet);
    if (newSet.size > 0) {
      setChatMode("selected");
    }
  };

  return (
    <>
      <AppSidebar
        selectedDocumentId={selectedDocumentId}
        onSelectDocument={handleSelectDocument}
        selectedDocumentIds={selectedDocumentIds}
        onToggleSelection={handleToggleDocumentSelection}
        chatMode={chatMode}
        onChatModeChange={setChatMode}
      />
      <div className="flex flex-col flex-1 min-w-0">
        <MobileHeader />
        <main className="flex-1 overflow-auto">
          <Router
            selectedDocumentId={selectedDocumentId}
            onSelectDocument={handleSelectDocument}
            selectedDocumentIds={selectedDocumentIds}
            chatMode={chatMode}
          />
        </main>
      </div>
    </>
  );
}

function App() {
  const [selectedDocumentId, setSelectedDocumentId] = useState<number | null>(null);
  const [selectedDocumentIds, setSelectedDocumentIds] = useState<Set<number>>(new Set());
  const [chatMode, setChatMode] = useState<ChatMode>("single");
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const checkMobile = () => setIsMobile(window.innerWidth < 768);
    checkMobile();
    window.addEventListener("resize", checkMobile);
    return () => window.removeEventListener("resize", checkMobile);
  }, []);

  const style = {
    "--sidebar-width": isMobile ? "100vw" : "18rem",
    "--sidebar-width-icon": "3rem",
  };

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <SidebarProvider 
          style={style as React.CSSProperties}
          defaultOpen={!isMobile}
        >
          <div className="flex h-[100dvh] w-full overflow-hidden">
            <AppContent
              selectedDocumentId={selectedDocumentId}
              setSelectedDocumentId={setSelectedDocumentId}
              selectedDocumentIds={selectedDocumentIds}
              setSelectedDocumentIds={setSelectedDocumentIds}
              chatMode={chatMode}
              setChatMode={setChatMode}
            />
          </div>
        </SidebarProvider>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
