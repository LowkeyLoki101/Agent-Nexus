# RLM Explorer

## Recent Changes (January 2026)
- Initial MVP implementation complete
- Document upload via file drop or paste content
- Recursive search visualization with real-time streaming
- Dark/light theme support with sidebar navigation
- Zod validation for API endpoints with SSE client disconnect handling
- **Knowledge Aggregation**: Added YouTube transcript import and website scraping
  - POST /api/import/youtube - extracts video transcripts without API keys
  - POST /api/import/website - scrapes text content with depth-limited crawling
  - SSRF protection to block internal/private/metadata URLs
  - Documents now have sourceType, sourceUrl, sourceTitle fields

## Overview

RLM Explorer is a web application that implements Recursive Language Models (RLMs) for processing large documents and codebases. The application allows users to upload files (code, text, JSON, markdown) and query them using AI-powered recursive search patterns. This approach enables efficient processing of 10M+ tokens without quality degradation by treating the model's context as an external environment that the AI interacts with symbolically through code-driven searches.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript, using Vite as the build tool
- **Routing**: wouter for client-side routing
- **State Management**: TanStack React Query for server state management
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming (light/dark mode support)
- **Path Aliases**: `@/` maps to `client/src/`, `@shared/` maps to `shared/`

### Backend Architecture
- **Framework**: Express.js (v5) with TypeScript
- **API Pattern**: RESTful API with streaming support (SSE for real-time search updates)
- **RLM Engine**: Custom recursive search engine (`server/rlm-engine.ts`) that:
  - Executes regex-based searches on document content
  - Uses OpenAI API for AI-powered query processing
  - Streams search steps and results back to the client in real-time

### Data Layer
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Schema Location**: `shared/schema.ts` contains all database tables and Zod validation schemas
- **Storage Pattern**: Currently uses in-memory storage (`server/storage.ts`) with interface designed for easy database migration
- **Key Entities**:
  - `documents`: Stores uploaded files with content, type, and metadata
  - `queries`: Stores search queries with results, search history, and status
  - `users`: Basic user authentication support

### Build System
- **Development**: TSX for running TypeScript directly
- **Production Build**: Custom build script using esbuild for server and Vite for client
- **Output**: Server bundles to `dist/index.cjs`, client builds to `dist/public`

### AI Integration
- Uses OpenAI API through Replit AI Integrations
- Environment variables: `AI_INTEGRATIONS_OPENAI_API_KEY`, `AI_INTEGRATIONS_OPENAI_BASE_URL`
- Includes pre-built integrations for audio, chat, image generation, and batch processing in `server/replit_integrations/`

## External Dependencies

### AI Services
- **OpenAI API**: Primary AI provider for text processing and recursive search logic
- Configured via `AI_INTEGRATIONS_OPENAI_API_KEY` and `AI_INTEGRATIONS_OPENAI_BASE_URL` environment variables

### Database
- **PostgreSQL**: Primary database (configured via `DATABASE_URL` environment variable)
- Uses Drizzle ORM for type-safe database operations
- Schema migrations stored in `/migrations` directory

### Third-Party Libraries
- **Radix UI**: Accessible component primitives for all UI elements
- **Framer Motion**: Animation library for search visualization
- **TanStack Query**: Async state management and caching
- **Zod**: Schema validation for API inputs and database operations
- **date-fns**: Date formatting utilities

### Replit-Specific
- `@replit/vite-plugin-runtime-error-modal`: Development error overlay
- `@replit/vite-plugin-cartographer`: Development tooling (dev only)
- `@replit/vite-plugin-dev-banner`: Development banner (dev only)