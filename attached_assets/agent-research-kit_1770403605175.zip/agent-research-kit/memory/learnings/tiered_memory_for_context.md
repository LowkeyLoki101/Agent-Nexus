# Tiered Memory for Context Management

**Date:** 2025-02-04
**Source:** MIT CSAIL RLM Research (arxiv 2512.24601)
**Confidence:** High

## Finding

Long context can be managed efficiently by dividing memory into tiers:

1. **Hot tier** — Always loaded (identity, current goals, active state)
2. **Warm tier** — Searchable index with summaries, loaded on demand
3. **Cold tier** — Archived content, compressed, rarely accessed

This pattern achieves O(N) scaling instead of O(N²) for attention-based models.

## Applied To

Built into relay-os memory.py system:
- Hot: Agent diaries (identity, goals)
- Warm: Indexed artifacts (title, tags, summary, location)
- Cold: Archived old entries with auto-summarization

## Result

Agents can maintain context across sessions without overwhelming context windows. Memory is persistent and searchable without loading everything.

## Key Insight

The scratchpad folder structure we already use IS a form of tiered memory — we just needed to make it programmatically accessible.

## Tags

memory, context, scaling, RLM, tiered-storage, architecture
