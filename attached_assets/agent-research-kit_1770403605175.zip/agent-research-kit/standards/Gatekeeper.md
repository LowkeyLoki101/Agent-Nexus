# Gatekeeper Standard

**Every change to architecture, process, or systems must pass these 5 criteria.**

---

## Why This Exists

Without gatekeeping:
- Systems drift in random directions
- Changes accumulate without justification
- Reversibility is lost
- Knowledge of "why" disappears

The Gatekeeper ensures changes are intentional, justified, and undoable.

---

## The 5 Criteria

### 1. Clear Benefit

**Question:** What measurable improvement does this provide?

**Pass if:**
- Specific improvement identified (speed, accuracy, clarity, revenue, etc.)
- Improvement is measurable (not just "feels better")
- Benefit exceeds cost of making the change

**Fail if:**
- Benefit is vague ("it's cleaner")
- No measurement possible
- Benefit is marginal relative to effort

---

### 2. Low Risk

**Question:** What could go wrong, and how bad would it be?

**Pass if:**
- No privacy/security implications
- No destructive potential (data loss, corruption)
- Minimal lock-in (doesn't trap us in a corner)
- Failure mode is recoverable

**Fail if:**
- Could expose private information
- Could destroy or corrupt data
- Creates dependency that's hard to reverse
- Failure would be catastrophic

---

### 3. Fit

**Question:** Does this align with how we work and what we're trying to do?

**Pass if:**
- Works with existing workflow (doesn't fight the grain)
- Aligns with stated goals and priorities
- Doesn't conflict with other active systems
- Makes sense given current context

**Fail if:**
- Requires major workflow changes to accommodate
- Contradicts stated goals
- Conflicts with existing systems
- Solves a problem we don't have

---

### 4. Cost

**Question:** Is the effort justified by the impact?

**Pass if:**
- Implementation time is proportional to benefit
- Complexity added is necessary
- Maintenance burden is acceptable
- Opportunity cost considered (what else could we do instead?)

**Fail if:**
- Massive effort for minor improvement
- Adds complexity without clear need
- Creates ongoing maintenance burden
- Better options exist

---

### 5. Reversible

**Question:** Can we undo this if it doesn't work?

**Pass if:**
- Change can be rolled back
- Rollback plan is documented
- Changes are logged (we know what was done)
- No permanent state changes without backup

**Fail if:**
- Change is one-way
- No rollback path exists
- Changes aren't tracked
- Data would be lost

---

## Using the Gatekeeper

### For Minor Changes (< 1 hour of work)

Quick self-check:
1. Does this clearly help? ✓/✗
2. Could it break something? ✓/✗
3. Can I undo it? ✓/✗

If all ✓, proceed. If any ✗, write a proposal.

### For Major Changes (> 1 hour or affects architecture)

Write a formal proposal using `Proposal_Template.md`:
1. Fill out all sections
2. Self-assess against 5 criteria
3. Submit for human review
4. Wait for approval before implementing

---

## Gatekeeper Overrides

**Only the human operator can override Gatekeeper.**

If a change fails criteria but seems important:
1. Document why criteria aren't met
2. Document why change is still worth doing
3. Explicitly request human override
4. Do not proceed without explicit approval

---

## Examples

### Pass Example

**Change:** Add TF-IDF pattern scanning to daily logs

1. **Clear benefit:** Find recurring issues 50% faster ✓
2. **Low risk:** Read-only analysis, no data changes ✓
3. **Fit:** Logs already exist, aligns with research goals ✓
4. **Cost:** 2 hours to implement, saves time daily ✓
5. **Reversible:** Delete script to remove ✓

**Result:** PASS — Proceed

---

### Fail Example

**Change:** Restructure all folders to new naming convention

1. **Clear benefit:** "More organized" — vague ✗
2. **Low risk:** Moving files could break paths ✗
3. **Fit:** Current structure works, no pressing need ✗
4. **Cost:** 4+ hours, high effort for unclear gain ✗
5. **Reversible:** Would need to track all moves ✗

**Result:** FAIL — Do not proceed without major justification

---

## Gatekeeper Log

Track all Gatekeeper decisions in `CURRENT_STATE.md`:

```
| Date | Change | Criteria | Decision | Outcome |
|------|--------|----------|----------|---------|
| | | 5/5 pass | Approved | |
```

This creates accountability and learning over time.
