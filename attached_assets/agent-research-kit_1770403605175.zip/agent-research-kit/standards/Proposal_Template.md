# Proposal Template

**Use this template for any change that affects architecture, process, or systems.**

---

Copy everything below this line for your proposal:

---

# Proposal: [Title]

**Date:** [YYYY-MM-DD]
**Author:** [Agent name]
**Status:** Draft | Submitted | Approved | Rejected | Implemented

---

## Summary

[2-3 sentences describing the change]

---

## Why Now?

[What triggered this proposal? Why is this needed now rather than later?]

---

## Expected Benefit

[Specific, measurable improvement]

**Metric:** [How we'll measure success]
**Target:** [What number/outcome we're aiming for]

---

## Risks & Mitigations

| Risk | Likelihood | Impact | Mitigation |
|------|------------|--------|------------|
| [What could go wrong] | Low/Med/High | Low/Med/High | [How we prevent or handle it] |

---

## Files/Systems Impacted

- [File or system 1]
- [File or system 2]
- [etc.]

---

## Implementation Plan

1. [Step 1]
2. [Step 2]
3. [Step 3]

**Estimated time:** [Hours/days]

---

## Reversibility Plan

**To undo this change:**
1. [Rollback step 1]
2. [Rollback step 2]

**Data preserved:** [What's backed up / kept safe]

---

## Gatekeeper Assessment

| Criterion | Pass? | Notes |
|-----------|-------|-------|
| Clear benefit | ✓/✗ | |
| Low risk | ✓/✗ | |
| Fit | ✓/✗ | |
| Cost justified | ✓/✗ | |
| Reversible | ✓/✗ | |

**Overall:** PASS / FAIL / NEEDS DISCUSSION

---

## Decision Needed

[What specific approval or decision is required from the human?]

- [ ] Approve as-is
- [ ] Approve with modifications: ____________
- [ ] Reject
- [ ] Need more information: ____________

---

## Approval

**Approved by:** [Name]
**Date:** [YYYY-MM-DD]
**Notes:** [Any conditions or modifications]

---

*After approval, move this to `standards/proposals/approved/` and begin implementation.*
*After implementation, update status and record outcome in CURRENT_STATE.md.*
