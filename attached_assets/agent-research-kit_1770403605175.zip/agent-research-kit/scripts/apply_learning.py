#!/usr/bin/env python3
"""
Learning Applicator
Checks if existing learnings apply to a new context.

Usage:
    python apply_learning.py "I need to analyze customer feedback"
    python apply_learning.py --context "building a dashboard" --problem "data is messy"
"""

import argparse
import json
from pathlib import Path

SCRIPT_DIR = Path(__file__).parent.parent
INDEX_FILE = SCRIPT_DIR / "memory" / "index.json"


def load_index() -> dict:
    """Load the memory index."""
    if not INDEX_FILE.exists():
        print("Memory index not found. Run index_memory.py first.")
        return {"entries": []}

    with open(INDEX_FILE, 'r', encoding='utf-8') as f:
        return json.load(f)


def find_applicable_learnings(context: str, problem: str = "") -> list:
    """Find learnings that might apply to the current context."""
    index = load_index()

    query = f"{context} {problem}".lower()
    query_terms = set(query.split())

    results = []

    for entry in index["entries"]:
        # Skip failures for direct application (but they're still useful for warnings)
        relevance_score = 0
        match_reasons = []

        # Check tags
        matching_tags = [t for t in entry.get("tags", []) if any(term in t for term in query_terms)]
        if matching_tags:
            relevance_score += len(matching_tags) * 3
            match_reasons.append(f"tags: {', '.join(matching_tags)}")

        # Check title
        title_lower = entry.get("title", "").lower()
        matching_title_terms = [t for t in query_terms if t in title_lower]
        if matching_title_terms:
            relevance_score += len(matching_title_terms) * 2
            match_reasons.append(f"title match")

        # Check summary
        summary_lower = entry.get("summary", "").lower()
        matching_summary_terms = [t for t in query_terms if t in summary_lower]
        if matching_summary_terms:
            relevance_score += len(matching_summary_terms)
            match_reasons.append(f"summary match")

        if relevance_score > 0:
            results.append({
                "entry": entry,
                "score": relevance_score,
                "reasons": match_reasons,
                "is_failure": entry.get("type") == "failure"
            })

    # Sort by relevance
    results.sort(key=lambda x: x["score"], reverse=True)

    return results


def format_recommendation(results: list, context: str) -> str:
    """Format results into actionable recommendations."""
    output = []
    output.append(f"\n=== Learning Check for: '{context}' ===\n")

    learnings = [r for r in results if not r["is_failure"]]
    failures = [r for r in results if r["is_failure"]]

    if learnings:
        output.append("## Applicable Learnings\n")
        for i, result in enumerate(learnings[:5], 1):
            entry = result["entry"]
            output.append(f"{i}. **{entry['title']}**")
            output.append(f"   - Confidence: {entry.get('confidence', 'unknown')}")
            output.append(f"   - Why relevant: {', '.join(result['reasons'])}")
            if entry.get('summary'):
                output.append(f"   - Summary: {entry['summary'][:150]}...")
            output.append(f"   - File: {entry['file']}")
            output.append("")
    else:
        output.append("No directly applicable learnings found.\n")

    if failures:
        output.append("## Warnings from Past Failures\n")
        for i, result in enumerate(failures[:3], 1):
            entry = result["entry"]
            output.append(f"⚠️  **{entry['title']}**")
            output.append(f"   - Why relevant: {', '.join(result['reasons'])}")
            if entry.get('summary'):
                output.append(f"   - What failed: {entry['summary'][:150]}...")
            output.append(f"   - File: {entry['file']}")
            output.append("")

    if not learnings and not failures:
        output.append("This appears to be new territory. No matching learnings or failures found.")
        output.append("Consider documenting findings from this work for future reference.")

    output.append("\n---")
    output.append("To see full details, read the files listed above.")
    output.append("After completing this work, add your learnings to memory/learnings/")

    return "\n".join(output)


def interactive_mode():
    """Run in interactive mode for conversation-style queries."""
    print("=== Learning Applicator (Interactive Mode) ===")
    print("Describe your context or problem. Type 'quit' to exit.\n")

    while True:
        context = input("Context/Problem: ").strip()
        if context.lower() in ['quit', 'exit', 'q']:
            break
        if not context:
            continue

        results = find_applicable_learnings(context)
        print(format_recommendation(results, context))
        print()


def main():
    parser = argparse.ArgumentParser(description="Check if learnings apply to current context")
    parser.add_argument("context", nargs="?", type=str, help="Describe your current context or problem")
    parser.add_argument("--problem", type=str, default="", help="Specific problem you're solving")
    parser.add_argument("--interactive", "-i", action="store_true", help="Run in interactive mode")
    args = parser.parse_args()

    if args.interactive:
        interactive_mode()
    elif args.context:
        full_context = args.context
        if args.problem:
            full_context += " " + args.problem
        results = find_applicable_learnings(full_context, args.problem)
        print(format_recommendation(results, full_context))
    else:
        print("Usage: python apply_learning.py 'describe your context'")
        print("   or: python apply_learning.py --interactive")


if __name__ == "__main__":
    main()
