#!/usr/bin/env python3
"""
Pattern Scanner
Applies pattern discovery methods from Methods_Matrix to text data.

Usage:
    python pattern_scan.py <input_folder> [--method tfidf|ngrams|both]
    python pattern_scan.py ./data --method tfidf --top 20
"""

import os
import re
import argparse
import json
from pathlib import Path
from collections import Counter
from datetime import datetime


def load_text_files(folder: Path) -> list:
    """Load all text/markdown files from a folder."""
    documents = []
    for ext in ['*.txt', '*.md', '*.log']:
        for filepath in folder.glob(ext):
            try:
                content = filepath.read_text(encoding='utf-8')
                documents.append({
                    'file': filepath.name,
                    'path': str(filepath),
                    'content': content
                })
            except Exception as e:
                print(f"Warning: Could not read {filepath}: {e}")
    return documents


def tokenize(text: str) -> list:
    """Simple tokenization: lowercase, split on non-alphanumeric."""
    # Remove markdown formatting
    text = re.sub(r'[#*`\[\]()]', ' ', text)
    # Lowercase and split
    tokens = re.findall(r'\b[a-z]{2,}\b', text.lower())
    return tokens


# Common English stopwords
STOPWORDS = set([
    'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for',
    'of', 'with', 'by', 'from', 'as', 'is', 'was', 'are', 'were', 'been',
    'be', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could',
    'should', 'may', 'might', 'must', 'shall', 'can', 'need', 'dare', 'ought',
    'used', 'this', 'that', 'these', 'those', 'it', 'its', 'they', 'them',
    'their', 'we', 'us', 'our', 'you', 'your', 'he', 'him', 'his', 'she',
    'her', 'i', 'me', 'my', 'who', 'which', 'what', 'where', 'when', 'why',
    'how', 'all', 'each', 'every', 'both', 'few', 'more', 'most', 'other',
    'some', 'such', 'no', 'nor', 'not', 'only', 'own', 'same', 'so', 'than',
    'too', 'very', 'just', 'also', 'now', 'here', 'there', 'then', 'if',
    'else', 'while', 'about', 'after', 'before', 'above', 'below', 'between',
    'into', 'through', 'during', 'under', 'again', 'further', 'once', 'any',
    'file', 'folder', 'path', 'name', 'type', 'date', 'status', 'note', 'md'
])


def remove_stopwords(tokens: list) -> list:
    """Remove stopwords from token list."""
    return [t for t in tokens if t not in STOPWORDS]


def compute_tf(tokens: list) -> dict:
    """Compute term frequency for a document."""
    counter = Counter(tokens)
    total = len(tokens)
    return {term: count / total for term, count in counter.items()}


def compute_idf(documents: list) -> dict:
    """Compute inverse document frequency across all documents."""
    import math
    n_docs = len(documents)
    doc_freq = Counter()

    for doc in documents:
        tokens = set(remove_stopwords(tokenize(doc['content'])))
        doc_freq.update(tokens)

    idf = {}
    for term, freq in doc_freq.items():
        idf[term] = math.log(n_docs / (1 + freq))

    return idf


def compute_tfidf(documents: list) -> list:
    """Compute TF-IDF scores for all documents."""
    idf = compute_idf(documents)

    results = []
    for doc in documents:
        tokens = remove_stopwords(tokenize(doc['content']))
        tf = compute_tf(tokens)

        tfidf = {}
        for term, tf_score in tf.items():
            tfidf[term] = tf_score * idf.get(term, 0)

        # Sort by score
        top_terms = sorted(tfidf.items(), key=lambda x: x[1], reverse=True)

        results.append({
            'file': doc['file'],
            'top_terms': top_terms[:20],
            'total_terms': len(tokens)
        })

    return results


def compute_corpus_tfidf(documents: list, top_n: int = 30) -> list:
    """Compute TF-IDF across entire corpus."""
    # Combine all documents
    all_tokens = []
    for doc in documents:
        tokens = remove_stopwords(tokenize(doc['content']))
        all_tokens.extend(tokens)

    # Compute TF for corpus
    tf = compute_tf(all_tokens)

    # Compute IDF
    idf = compute_idf(documents)

    # Combine
    tfidf = {}
    for term, tf_score in tf.items():
        tfidf[term] = tf_score * idf.get(term, 0)

    # Sort and return top N
    top_terms = sorted(tfidf.items(), key=lambda x: x[1], reverse=True)[:top_n]

    return top_terms


def compute_ngrams(documents: list, n: int = 2, top_n: int = 30) -> list:
    """Compute n-grams across all documents."""
    all_ngrams = []

    for doc in documents:
        tokens = remove_stopwords(tokenize(doc['content']))
        for i in range(len(tokens) - n + 1):
            ngram = tuple(tokens[i:i+n])
            all_ngrams.append(ngram)

    # Count
    counter = Counter(all_ngrams)

    # Filter: must appear at least twice
    filtered = [(ng, count) for ng, count in counter.items() if count >= 2]

    # Sort by frequency
    sorted_ngrams = sorted(filtered, key=lambda x: x[1], reverse=True)[:top_n]

    return [(' '.join(ng), count) for ng, count in sorted_ngrams]


def generate_report(documents: list, tfidf_results: list, ngrams_results: list, output_path: Path):
    """Generate a pattern report."""
    report = f"""# Pattern Scan Report

**Date:** {datetime.now().strftime('%Y-%m-%d %H:%M')}
**Documents scanned:** {len(documents)}
**Total tokens:** {sum(r['total_terms'] for r in tfidf_results)}

---

## Top Terms (Corpus TF-IDF)

| Rank | Term | Score |
|------|------|-------|
"""

    corpus_tfidf = compute_corpus_tfidf(documents, 30)
    for i, (term, score) in enumerate(corpus_tfidf, 1):
        report += f"| {i} | {term} | {score:.4f} |\n"

    report += """
---

## Top Bi-grams (2-word sequences)

| Rank | Phrase | Count |
|------|--------|-------|
"""

    for i, (phrase, count) in enumerate(ngrams_results, 1):
        report += f"| {i} | {phrase} | {count} |\n"

    report += """
---

## Per-Document Analysis

"""

    for result in tfidf_results[:10]:
        report += f"### {result['file']}\n\n"
        report += "Top terms: "
        report += ", ".join([f"{term} ({score:.3f})" for term, score in result['top_terms'][:10]])
        report += "\n\n"

    report += """
---

## Interpretation

[AGENT: Add your interpretation of these patterns here]

### Key Themes Identified:
1. [Theme based on top terms]
2. [Theme based on bi-grams]
3. [Theme from document clusters]

### Recommended Actions:
- [Action based on findings]

### Questions for Further Research:
- [What patterns need deeper investigation?]

---

**Tags:** pattern-discovery, tfidf, text-analysis
"""

    output_path.write_text(report, encoding='utf-8')
    print(f"Report saved to: {output_path}")


def main():
    parser = argparse.ArgumentParser(description="Pattern Scanner for Text Data")
    parser.add_argument("input_folder", type=str, help="Folder containing text files to scan")
    parser.add_argument("--method", choices=['tfidf', 'ngrams', 'both'], default='both',
                        help="Pattern discovery method")
    parser.add_argument("--top", type=int, default=30, help="Number of top results")
    parser.add_argument("--output", type=str, help="Output report path")
    args = parser.parse_args()

    input_folder = Path(args.input_folder)
    if not input_folder.exists():
        print(f"Error: Folder not found: {input_folder}")
        return

    print(f"Scanning: {input_folder}")
    documents = load_text_files(input_folder)
    print(f"Found {len(documents)} documents")

    if len(documents) == 0:
        print("No documents found.")
        return

    tfidf_results = []
    ngrams_results = []

    if args.method in ['tfidf', 'both']:
        print("\nRunning TF-IDF analysis...")
        tfidf_results = compute_tfidf(documents)

        print("\nTop corpus terms:")
        corpus_top = compute_corpus_tfidf(documents, args.top)
        for term, score in corpus_top[:15]:
            print(f"  {term}: {score:.4f}")

    if args.method in ['ngrams', 'both']:
        print("\nRunning n-gram analysis...")
        ngrams_results = compute_ngrams(documents, n=2, top_n=args.top)

        print("\nTop bi-grams:")
        for phrase, count in ngrams_results[:15]:
            print(f"  {phrase}: {count}")

    # Generate report
    if args.output:
        output_path = Path(args.output)
    else:
        output_path = input_folder / f"pattern_report_{datetime.now().strftime('%Y%m%d_%H%M')}.md"

    generate_report(documents, tfidf_results, ngrams_results, output_path)


if __name__ == "__main__":
    main()
