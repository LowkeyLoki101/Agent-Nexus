#!/usr/bin/env python3
"""
Memory Indexer
Scans learnings/ and failures/ folders, extracts metadata, builds searchable index.

Usage:
    python index_memory.py          # Rebuild index
    python index_memory.py --stats  # Show stats only
    python index_memory.py --search "query"  # Search index
"""

import os
import json
import re
import argparse
from datetime import datetime
from pathlib import Path

# Paths relative to this script
SCRIPT_DIR = Path(__file__).parent.parent
MEMORY_DIR = SCRIPT_DIR / "memory"
LEARNINGS_DIR = MEMORY_DIR / "learnings"
FAILURES_DIR = MEMORY_DIR / "failures"
INDEX_FILE = MEMORY_DIR / "index.json"


def extract_metadata(filepath: Path) -> dict:
    """Extract metadata from a markdown file."""
    content = filepath.read_text(encoding='utf-8')

    metadata = {
        "file": str(filepath.relative_to(MEMORY_DIR)),
        "type": "learning" if "learnings" in str(filepath) else "failure",
        "title": filepath.stem.replace("_", " ").replace("-", " ").title(),
        "date": None,
        "confidence": None,
        "tags": [],
        "summary": "",
        "applied": False
    }

    # Extract date
    date_match = re.search(r'\*\*Date:\*\*\s*(\d{4}-\d{2}-\d{2})', content)
    if date_match:
        metadata["date"] = date_match.group(1)

    # Extract confidence
    conf_match = re.search(r'\*\*Confidence:\*\*\s*(High|Medium|Low)', content, re.IGNORECASE)
    if conf_match:
        metadata["confidence"] = conf_match.group(1).lower()

    # Extract tags
    tags_match = re.search(r'\*\*Tags:\*\*\s*(.+)', content)
    if tags_match:
        tags_str = tags_match.group(1)
        metadata["tags"] = [t.strip().lower() for t in re.split(r'[,\s]+', tags_str) if t.strip()]

    # Also extract tags from ## Tags section
    tags_section = re.search(r'## Tags\n(.+?)(?:\n##|\Z)', content, re.DOTALL)
    if tags_section:
        tags_str = tags_section.group(1)
        metadata["tags"].extend([t.strip().lower() for t in re.split(r'[,\s\n]+', tags_str) if t.strip() and t.strip() != '-'])

    metadata["tags"] = list(set(metadata["tags"]))  # Dedupe

    # Extract title from # heading
    title_match = re.search(r'^# (.+)', content, re.MULTILINE)
    if title_match:
        metadata["title"] = title_match.group(1).strip()

    # Extract first paragraph as summary
    # Skip metadata lines, get first real paragraph
    lines = content.split('\n')
    summary_lines = []
    in_content = False
    for line in lines:
        if line.startswith('## ') and not in_content:
            in_content = True
            continue
        if in_content and line.strip() and not line.startswith('**') and not line.startswith('#'):
            summary_lines.append(line.strip())
            if len(' '.join(summary_lines)) > 200:
                break
    metadata["summary"] = ' '.join(summary_lines)[:300]

    # Check if applied
    metadata["applied"] = "applied" in content.lower() and ("yes" in content.lower() or "✓" in content)

    # Add search text (for full-text search)
    metadata["_search"] = content.lower()

    return metadata


def build_index():
    """Scan memory folders and build index."""
    entries = []

    # Index learnings
    if LEARNINGS_DIR.exists():
        for filepath in LEARNINGS_DIR.glob("*.md"):
            if filepath.name.startswith('.'):
                continue
            try:
                metadata = extract_metadata(filepath)
                entries.append(metadata)
            except Exception as e:
                print(f"Warning: Could not index {filepath}: {e}")

    # Index failures
    if FAILURES_DIR.exists():
        for filepath in FAILURES_DIR.glob("*.md"):
            if filepath.name.startswith('.'):
                continue
            try:
                metadata = extract_metadata(filepath)
                entries.append(metadata)
            except Exception as e:
                print(f"Warning: Could not index {filepath}: {e}")

    # Build index
    index = {
        "version": "1.0",
        "last_updated": datetime.now().isoformat(),
        "stats": {
            "total_learnings": len([e for e in entries if e["type"] == "learning"]),
            "total_failures": len([e for e in entries if e["type"] == "failure"]),
            "total_indexed": len(entries)
        },
        "entries": entries
    }

    # Save index
    with open(INDEX_FILE, 'w', encoding='utf-8') as f:
        json.dump(index, f, indent=2)

    return index


def search_index(query: str) -> list:
    """Search the index for matching entries."""
    if not INDEX_FILE.exists():
        print("Index not found. Building...")
        build_index()

    with open(INDEX_FILE, 'r', encoding='utf-8') as f:
        index = json.load(f)

    query_lower = query.lower()
    query_terms = query_lower.split()

    results = []
    for entry in index["entries"]:
        score = 0

        # Check title
        if query_lower in entry["title"].lower():
            score += 10

        # Check tags
        for tag in entry["tags"]:
            if any(term in tag for term in query_terms):
                score += 5

        # Check summary
        if query_lower in entry["summary"].lower():
            score += 3

        # Check full text
        search_text = entry.get("_search", "")
        for term in query_terms:
            if term in search_text:
                score += 1

        if score > 0:
            results.append((score, entry))

    # Sort by score descending
    results.sort(key=lambda x: x[0], reverse=True)

    return [entry for score, entry in results]


def print_stats(index: dict):
    """Print index statistics."""
    stats = index["stats"]
    print("\n=== Memory Index Stats ===")
    print(f"Last updated: {index['last_updated']}")
    print(f"Total learnings: {stats['total_learnings']}")
    print(f"Total failures: {stats['total_failures']}")
    print(f"Total indexed: {stats['total_indexed']}")

    # Tag frequency
    tag_counts = {}
    for entry in index["entries"]:
        for tag in entry["tags"]:
            tag_counts[tag] = tag_counts.get(tag, 0) + 1

    if tag_counts:
        print("\nTop tags:")
        for tag, count in sorted(tag_counts.items(), key=lambda x: x[1], reverse=True)[:10]:
            print(f"  {tag}: {count}")

    # Recent entries
    dated = [(e.get("date", ""), e) for e in index["entries"] if e.get("date")]
    dated.sort(key=lambda x: x[0], reverse=True)

    if dated:
        print("\nMost recent:")
        for date, entry in dated[:5]:
            print(f"  [{date}] {entry['title']}")


def print_search_results(results: list, query: str):
    """Print search results."""
    print(f"\n=== Search: '{query}' ===")
    print(f"Found {len(results)} results\n")

    for entry in results[:10]:
        print(f"[{entry['type'].upper()}] {entry['title']}")
        if entry.get('date'):
            print(f"  Date: {entry['date']}")
        if entry.get('tags'):
            print(f"  Tags: {', '.join(entry['tags'])}")
        if entry.get('summary'):
            print(f"  Summary: {entry['summary'][:100]}...")
        print(f"  File: {entry['file']}")
        print()


def main():
    parser = argparse.ArgumentParser(description="Memory Indexer")
    parser.add_argument("--stats", action="store_true", help="Show stats only")
    parser.add_argument("--search", type=str, help="Search query")
    args = parser.parse_args()

    if args.search:
        results = search_index(args.search)
        print_search_results(results, args.search)
    elif args.stats:
        if INDEX_FILE.exists():
            with open(INDEX_FILE, 'r', encoding='utf-8') as f:
                index = json.load(f)
        else:
            index = build_index()
        print_stats(index)
    else:
        print("Building memory index...")
        index = build_index()
        print_stats(index)
        print("\nIndex saved to memory/index.json")


if __name__ == "__main__":
    main()
