# Current State

**Last Updated:** [AGENT: Update this timestamp every session]
**Updated By:** [AGENT: Your name]

---

## Active Priority

**What's the #1 thing right now?**

[AGENT: Write one sentence describing the most important current focus]

---

## Active Projects

| Project | Status | Owner | Next Action | Blocked By |
|---------|--------|-------|-------------|------------|
| [name] | [status] | [who] | [what's next] | [blocker or "none"] |

**Status options:** research, building, review, ready, blocked, shipped

---

## Recent Learnings (Last 7 Days)

| Date | Learning | Applied To | Result |
|------|----------|------------|--------|
| | | | |

---

## Pending Proposals

| Proposal | Status | Waiting On |
|----------|--------|------------|
| | | |

**Status options:** draft, submitted, approved, rejected, implemented

---

## Blockers

**What's stuck and why?**

| Blocker | Impact | Owner | Resolution Path |
|---------|--------|-------|-----------------|
| | | | |

---

## Memory Stats

- **Total indexed learnings:** [run `python scripts/index_memory.py --stats`]
- **Last memory index:** [timestamp]
- **Unindexed items:** [count]

---

## Session Log

### [DATE] — [AGENT NAME]

**Started with:**
- [State when session began]

**Did:**
- [What you accomplished]

**Learned:**
- [Key insights — add to memory/learnings/ if significant]

**Left for next session:**
- [Explicit next actions]

---

*AGENT: Copy the session log template above for each session. Keep the last 5 sessions visible, archive older ones.*
