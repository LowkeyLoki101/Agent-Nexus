# Agent Research Kit

**Drop this folder into any Replit project to give agents a complete research and learning system.**

This kit teaches agents how to:
1. Research any topic systematically
2. Discover patterns in data
3. Apply learnings to architecture and processes
4. Build recursive knowledge that compounds over time

---

## Quick Start

1. Drop this folder into your Replit project
2. Read `OPERATING_SYSTEM.md` first — it's the master protocol
3. Check `CURRENT_STATE.md` for what's active
4. Start working

---

## What's Inside

```
agent-research-kit/
├── README.md                    ← You are here
├── OPERATING_SYSTEM.md          ← Master protocol (read first)
├── CURRENT_STATE.md             ← Active projects, priorities, blockers
│
├── methods/                     ← HOW to research
│   ├── Methods_Matrix.md        ← Pattern discovery by data type
│   ├── Application_Process.md   ← 7-step process to apply methods
│   ├── Research_Workflow.md     ← Daily research loop
│   └── Quality_Checklist.md     ← Verify before publishing
│
├── standards/                   ← RULES for changes
│   ├── Gatekeeper.md            ← 5 criteria before any change
│   ├── Proposal_Template.md     ← How to propose changes
│   └── Safety_Protocol.md       ← What never to do
│
├── templates/                   ← FORMATS for outputs
│   ├── Research_Brief.md        ← Template for research findings
│   ├── Pattern_Report.md        ← Template for pattern discovery
│   ├── Project_Thread.md        ← Template for project tracking
│   └── Session_Log.md           ← Template for daily logs
│
├── memory/                      ← KNOWLEDGE that persists
│   ├── index.json               ← Searchable index of all learnings
│   ├── learnings/               ← Applied insights (what worked)
│   └── failures/                ← What didn't work (equally valuable)
│
└── scripts/                     ← AUTOMATION
    ├── index_memory.py          ← Build searchable memory index
    ├── pattern_scan.py          ← Run pattern discovery on text
    └── apply_learning.py        ← Check if learning applies to new context
```

---

## The Core Loop

```
┌─────────────────────────────────────────────────────────┐
│                                                         │
│   RESEARCH ──► DISCOVER ──► APPLY ──► MEASURE ──┐      │
│       ▲                                         │      │
│       └─────────────────────────────────────────┘      │
│                                                         │
│   Every cycle makes the next cycle smarter              │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

1. **RESEARCH** — Gather information using Methods_Matrix
2. **DISCOVER** — Find patterns using Application_Process
3. **APPLY** — Implement changes using Gatekeeper approval
4. **MEASURE** — Record what worked in memory/learnings/

Then the next research cycle can search memory first, building on what's known.

---

## Key Principles

### 1. Research Before Build
Never build without researching first. Even 15 minutes of research prevents days of wrong-direction work.

### 2. Apply or Archive
Research that isn't applied within 7 days gets archived. Research exists to change behavior, not to accumulate.

### 3. Memory is Searchable
Every learning gets indexed. Before starting new research, always search memory first.

### 4. Failures are Data
Failed experiments go in memory/failures/ with the same rigor as successes. Knowing what doesn't work is knowing.

### 5. Gatekeeper Everything
No change to architecture, process, or systems without passing the 5 Gatekeeper criteria. This prevents drift.

---

## For Humans

If you're the human operator:
- Check `CURRENT_STATE.md` for what agents are working on
- Proposals in `standards/proposals/` need your approval
- Memory is yours — agents build it, you own it

---

## For Agents

If you're an AI agent:
- Read `OPERATING_SYSTEM.md` completely before any work
- Update `CURRENT_STATE.md` after every session
- Never skip the Gatekeeper check
- Index your learnings — future-you will thank present-you
