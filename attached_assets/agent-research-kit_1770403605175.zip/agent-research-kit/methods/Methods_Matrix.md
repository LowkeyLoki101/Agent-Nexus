# Methods Matrix

**Use this to select the right pattern discovery method for your data type.**

---

## Quick Reference

| Data Type | Goal | Method | When to Use |
|-----------|------|--------|-------------|
| Text | Key terms | TF-IDF | Quick summary, find what's emphasized |
| Text | Themes | Topic modeling (LDA) | Discover what topics exist |
| Text | Similarity | Embeddings + cosine | Find related documents |
| Tabular | Segments | Clustering (k-means) | Group similar items |
| Tabular | Associations | Apriori rules | What co-occurs? |
| Time Series | Trends | Decomposition | Cycles, seasonality |
| Logs/Events | Top issues | TF-IDF on events | What's happening most? |
| Logs/Events | Sequences | N-grams | What follows what? |

---

## Detailed Matrix

### TEXT

**Frequency/Weighting — TF-IDF**
- Prep: Tokenize, remove stopwords
- Best for: Key terms, quick summaries, finding emphasis
- Output: Ranked term list with weights
- Risks: Misses semantic meaning, context-blind
- When to use: First pass on any text corpus

**Topic Discovery — LDA**
- Prep: Normalize text, clean formatting
- Best for: Discovering themes across many documents
- Output: Topic clusters with associated terms
- Risks: Requires tuning, topics can drift
- When to use: 50+ documents, looking for structure

**Similarity — Embeddings**
- Prep: Chunk text, generate embeddings
- Best for: Semantic search, finding related content
- Output: Similarity scores, clusters
- Risks: Compute cost, may blur nuance
- When to use: Need to find "similar" not just "matching"

---

### TABULAR

**Clustering — K-means / DBSCAN**
- Prep: Scale features, remove outliers
- Best for: Segmentation, finding natural groups
- Output: Cluster assignments, centroids
- Risks: Sensitive to parameters, assumes spherical clusters
- When to use: Looking for segments in structured data

**Association Rules — Apriori**
- Prep: Binarize transactions
- Best for: Finding co-occurrence patterns
- Output: Rules like "A → B with 80% confidence"
- Risks: Spurious rules if support threshold too low
- When to use: Transaction data, behavior patterns

**Anomaly Detection — Isolation Forest**
- Prep: Clean nulls, normalize
- Best for: Finding outliers, unusual records
- Output: Anomaly scores
- Risks: False positives in sparse data
- When to use: Looking for exceptions, fraud, errors

---

### TIME SERIES

**Trend/Seasonality — Decomposition**
- Prep: Clean, resample to regular intervals
- Best for: Understanding cycles, long-term trends
- Output: Trend + seasonal + residual components
- Risks: Fragile with irregular sampling
- When to use: Regular time series with suspected patterns

**Sequence Similarity — DTW**
- Prep: Normalize series
- Best for: Comparing patterns across different time scales
- Output: Similarity scores between series
- Risks: Slow on large datasets
- When to use: Comparing multiple time series

---

### LOGS / EVENTS

**Frequency — TF-IDF on Events**
- Prep: Normalize event names/messages
- Best for: Finding top recurring issues
- Output: Ranked event list
- Risks: Can miss rare but critical events
- When to use: First pass on any log corpus

**Sequence Patterns — N-grams**
- Prep: Order events by timestamp
- Best for: Finding what follows what
- Output: Common sequences, transition probabilities
- Risks: Noisy if logs are inconsistent
- When to use: Looking for workflows, error chains

---

### IMAGES

**Feature Similarity — CNN/CLIP Embeddings**
- Prep: Standardize size
- Best for: Visual search, grouping similar images
- Output: Similarity scores, clusters
- Risks: Compute cost, embedding quality varies
- When to use: Image corpus organization

---

### GRAPHS / NETWORKS

**Importance — PageRank**
- Prep: Build clean adjacency graph
- Best for: Finding influential nodes
- Output: Importance scores
- Risks: Bias toward high-degree nodes
- When to use: Network analysis, influence mapping

**Community Detection — Modularity Methods**
- Prep: Build graph with meaningful edges
- Best for: Finding clusters in networks
- Output: Community assignments
- Risks: Parameter sensitivity
- When to use: Social networks, dependency graphs

---

## Method Selection Flowchart

```
What's your data?
│
├─► Text documents
│   └─► How many?
│       ├─► < 50: TF-IDF for key terms
│       └─► 50+: LDA for topics, then TF-IDF within topics
│
├─► Structured/tabular
│   └─► What's the goal?
│       ├─► Find groups: Clustering
│       ├─► Find associations: Apriori
│       └─► Find outliers: Isolation Forest
│
├─► Time series
│   └─► Regular intervals?
│       ├─► Yes: Decomposition
│       └─► No: Clean first, then decomposition
│
├─► Logs/events
│   └─► Start with TF-IDF on events
│   └─► Then N-grams for sequences
│
└─► Images/graphs
    └─► Embeddings + clustering
```

---

## Usage Protocol

1. **Identify data type** from the categories above
2. **Select 1-2 methods** most appropriate for your goal
3. **Run with baseline settings** first (don't over-tune initially)
4. **Document findings** using Pattern_Report template
5. **Index learnings** about what worked/didn't for this data type
