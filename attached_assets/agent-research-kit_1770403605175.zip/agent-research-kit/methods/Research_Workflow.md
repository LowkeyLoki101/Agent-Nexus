# Research Workflow

**Daily loop for continuous research and learning.**

---

## The Daily Research Loop (15-30 min)

```
┌─────────────────────────────────────────────────────┐
│                                                     │
│   SCAN (5 min)                                      │
│   └─► What's new? What changed? What's needed?      │
│                                                     │
│   SEARCH (5 min)                                    │
│   └─► Check memory first. Has this been solved?     │
│                                                     │
│   RESEARCH (10-15 min)                              │
│   └─► Fill gaps. Use Methods_Matrix.                │
│                                                     │
│   SYNTHESIZE (5 min)                                │
│   └─► What did you learn? What action follows?      │
│                                                     │
│   INDEX (2 min)                                     │
│   └─► Add to memory. Update CURRENT_STATE.          │
│                                                     │
└─────────────────────────────────────────────────────┘
```

---

## Scan Phase

**What to scan:**
- Current blockers and priorities (CURRENT_STATE.md)
- Incoming requests or questions
- Recent failures or surprises
- Changes in the environment

**Output:** A clear question or topic to research

**Template:**
```
Research question: [What do we need to know?]
Why now: [What triggered this need?]
Success looks like: [What answer would be useful?]
```

---

## Search Phase

**Before any new research, search existing knowledge:**

1. Check `memory/index.json` for relevant past learnings
2. Check `memory/learnings/` for applied insights
3. Check `memory/failures/` for what didn't work

**If found:** Build on existing knowledge, don't reinvent
**If not found:** Proceed to research phase

---

## Research Phase

**Choose your approach based on the question:**

| Question Type | Approach |
|--------------|----------|
| "How does X work?" | Web search, documentation, first principles |
| "What patterns exist in Y?" | Apply Methods_Matrix to Y |
| "What should we do about Z?" | Research options, evaluate trade-offs |
| "Has anyone solved W?" | Search for prior art, case studies |

**Rule:** Set a timer. Research expands to fill time. 15 minutes is usually enough for a focused question.

**Capture as you go:**
- Key sources (with links)
- Core findings
- Confidence level
- Gaps remaining

---

## Synthesize Phase

**Convert research into actionable insight:**

```
Question: [What we asked]

Finding: [What we learned]

Confidence: [High/Medium/Low]

Implications:
- [What this means for current work]
- [What this changes about our approach]

Action: [Specific next step, or "none - for reference only"]
```

**Rule:** If research doesn't lead to action or indexed knowledge, it was probably too broad. Narrow the question.

---

## Index Phase

**Always end research by updating memory:**

1. **If actionable insight:** Add to `memory/learnings/[topic].md`
2. **If failure/dead-end:** Add to `memory/failures/[topic].md`
3. **Update index:** Run `python scripts/index_memory.py`
4. **Update state:** Add to CURRENT_STATE.md session log

**Format for learnings:**
```markdown
# [Topic]

**Date:** [YYYY-MM-DD]
**Source:** [Where this came from]
**Confidence:** [High/Medium/Low]

## Finding
[What we learned]

## Applied To
[Where/how we used this]

## Result
[What happened when applied]

## Tags
[searchable keywords]
```

---

## Weekly Research Review (30 min)

Once per week, do a deeper review:

1. **What did we learn this week?** (Scan memory/learnings/)
2. **What failed?** (Scan memory/failures/)
3. **What research is stale?** (Not applied within 7 days → archive or apply)
4. **What questions keep recurring?** (These need deeper research)
5. **What's our hit rate?** (% of research that led to applied change)

---

## Research Quality Signals

**Good research:**
- Answers a specific question
- Cites sources
- Acknowledges uncertainty
- Leads to action or indexed knowledge
- Takes < 30 minutes

**Bad research:**
- Vague question ("learn about AI")
- No sources
- Overclaims confidence
- Sits unused
- Spirals without conclusion

---

## Research Anti-Patterns

**Avoid:**

1. **Research rabbit holes** — Set a timer, stick to it
2. **Research as procrastination** — If you're researching instead of shipping, stop
3. **Orphan research** — If it won't be indexed or applied, why do it?
4. **Redundant research** — Always search memory first
5. **Perfection paralysis** — "Good enough to act on" beats "perfect but unused"
