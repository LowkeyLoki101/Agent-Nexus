# Quality Checklist

**Verify research quality before publishing or applying.**

---

## Before Publishing Any Research

### Source Quality
- [ ] Primary sources cited (not just summaries of summaries)
- [ ] Sources are recent enough to be relevant
- [ ] Multiple sources confirm key claims (when possible)
- [ ] Conflicts between sources acknowledged

### Clarity
- [ ] Question clearly stated
- [ ] Findings clearly stated
- [ ] Confidence level explicit (high/medium/low)
- [ ] Limitations acknowledged
- [ ] Jargon explained or avoided

### Actionability
- [ ] "So what?" is answered
- [ ] Next actions are specific (not vague)
- [ ] Applies to current context (not just theoretically interesting)

### Completeness
- [ ] Major perspectives considered
- [ ] Obvious counterarguments addressed
- [ ] Gaps in knowledge acknowledged
- [ ] Time-sensitivity noted (will this be stale soon?)

---

## Before Applying Research to Architecture

### Gatekeeper Criteria (All Must Pass)

1. **Clear Benefit**
   - [ ] Measurable improvement identified
   - [ ] Benefit > cost of change

2. **Low Risk**
   - [ ] No privacy leakage
   - [ ] No destructive potential
   - [ ] Minimal lock-in

3. **Fit**
   - [ ] Aligns with current workflow
   - [ ] Aligns with stated goals
   - [ ] Doesn't conflict with existing systems

4. **Cost**
   - [ ] Implementation time justified
   - [ ] Complexity justified
   - [ ] Maintenance cost considered

5. **Reversible**
   - [ ] Change can be undone
   - [ ] Rollback plan documented
   - [ ] Changes logged

---

## Pattern Discovery Quality

### Signal Quality
- [ ] Pattern is statistically significant (not random noise)
- [ ] Pattern holds across multiple runs
- [ ] Pattern holds across different subsets of data

### Interpretation
- [ ] Pattern explained in plain language
- [ ] Causation vs correlation distinguished
- [ ] Alternative explanations considered

### Application
- [ ] Pattern is actionable
- [ ] Action is specified
- [ ] Expected outcome documented

---

## Memory Entry Quality

### For Learnings
- [ ] Finding is specific (not vague)
- [ ] Context is documented (when/where this applies)
- [ ] Result of application is recorded
- [ ] Tags are searchable

### For Failures
- [ ] What was tried is documented
- [ ] Why it failed is explained
- [ ] What we learned is captured
- [ ] Tags prevent future agents from repeating

---

## Quick Quality Score

Rate 1-5 on each dimension:

| Dimension | Score | Notes |
|-----------|-------|-------|
| Source quality | /5 | |
| Clarity | /5 | |
| Actionability | /5 | |
| Completeness | /5 | |
| **Total** | /20 | |

**Thresholds:**
- 16-20: Publish/apply with confidence
- 12-15: Acceptable, note limitations
- 8-11: Needs improvement before use
- <8: Do not publish, rework needed
