# Pattern Discovery Application Process

**7-step process to go from raw data to applied insights.**

---

## When to Use This

- You have data (text, logs, tables, etc.)
- You want to find patterns
- You want to apply what you learn

---

## The 7 Steps

### Step 1: Select the Dataset

**Ask:**
- What data am I analyzing?
- What type is it? (text / tabular / time series / logs / images)
- Where does it come from?
- What time range does it cover?
- Any access constraints?

**Output:** One paragraph describing the dataset

```
Dataset: [name]
Type: [text/tabular/time series/logs/images]
Source: [where it came from]
Size: [# of records/documents/files]
Time range: [start - end]
Constraints: [any limitations]
```

---

### Step 2: Prep the Dataset

**Minimum prep:**
- Remove duplicates
- Handle missing values (drop or fill)
- Normalize formats (dates, text casing, etc.)
- Basic validation (are values in expected ranges?)

**Create a data profile:**
```
Records: [count]
Fields: [list key fields]
Sparsity: [% missing values]
Quality issues: [any problems found]
```

**Rule:** Don't over-prep. Minimal cleaning, then analyze. You can always clean more later.

---

### Step 3: Choose Methods

**From Methods_Matrix, select 1-3 methods.**

Document your choices:
```
Method 1: [name]
- Why: [reason for choosing]
- Expected output: [what you'll get]

Method 2: [name]
- Why: [reason for choosing]
- Expected output: [what you'll get]
```

**Rule:** Start with the simplest method. Add complexity only if needed.

---

### Step 4: Run Pattern Discovery

**For each method:**

1. Set baseline parameters (don't tune yet)
2. Run the method
3. Capture raw output
4. Write a quick interpretation (what does this mean?)

```
Method: [name]
Parameters: [settings used]
Raw output: [results]
Interpretation: [what this means in plain language]
```

**Rule:** Record everything. Even "nothing interesting" is a finding.

---

### Step 5: Evaluate Quality

**For each finding, assess:**

| Criterion | Score (1-5) | Notes |
|-----------|-------------|-------|
| Signal strength | | Is the pattern clear or noisy? |
| Stability | | Does it hold across different runs? |
| Actionability | | Can we do something with this? |
| Novelty | | Did we already know this? |

**Identify:**
- False positives (patterns that aren't real)
- Edge cases (patterns that only apply sometimes)
- Confidence level (how sure are we?)

---

### Step 6: Synthesize Findings

**Write a summary:**

```
Top Patterns Found:

1. [Pattern description]
   - Evidence: [what data supports this]
   - Confidence: [high/medium/low]
   - Implication: [what this means for action]

2. [Pattern description]
   - Evidence: [...]
   - Confidence: [...]
   - Implication: [...]

Recommended Actions:
- [Specific action based on findings]
- [Another action]

Questions for Further Research:
- [What we still don't know]
```

---

### Step 7: Record and Publish

**Save outputs:**

1. **Pattern Report** → Save using `templates/Pattern_Report.md`
2. **Log entry** → Add to session log in `CURRENT_STATE.md`
3. **Memory index** → Add to `memory/learnings/` if actionable
4. **Proposal** → If findings suggest a change, write a proposal

**Rule:** Unrecorded findings don't exist. Index everything.

---

## Quick Checklist

Before declaring "done":

- [ ] Dataset clearly described
- [ ] Prep documented (even if minimal)
- [ ] Methods chosen with rationale
- [ ] Raw outputs captured
- [ ] Quality evaluated
- [ ] Findings synthesized
- [ ] Pattern Report saved
- [ ] Memory indexed
- [ ] Next actions identified

---

## Time Budget

| Step | Time |
|------|------|
| 1. Select dataset | 5 min |
| 2. Prep | 10-30 min |
| 3. Choose methods | 5 min |
| 4. Run discovery | 15-60 min |
| 5. Evaluate | 10 min |
| 6. Synthesize | 15 min |
| 7. Record | 10 min |

**Total: 1-2 hours for a thorough analysis**

For quick scans, steps 2 and 4 can be shortened. Never skip 6 and 7.
