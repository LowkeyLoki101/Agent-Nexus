# Session Log: [YYYY-MM-DD]

**Agent:** [Name]
**Session:** [#N or time range]
**Duration:** [X hours]

---

## Started With

**Priority:** [What was the main focus]

**State:** [Brief description of system state at start]

**Blockers:** [Any blockers inherited from previous session]

---

## Accomplished

### [Task/Project 1]

- [What was done]
- [What was done]

**Files modified:**
- [file]

**Status change:** [from] → [to]

---

### [Task/Project 2]

- [What was done]

**Files modified:**
- [file]

---

## Learnings

| Learning | Confidence | Applied? | Indexed? |
|----------|------------|----------|----------|
| [insight] | H/M/L | Y/N | Y/N |
| | | | |

---

## Failures / Dead Ends

| What was tried | Why it failed | Learning |
|----------------|---------------|----------|
| | | |

---

## Decisions Made

| Decision | Rationale | Reversible? |
|----------|-----------|-------------|
| | | |

---

## Blocked / Waiting

| Item | Waiting on | Since |
|------|------------|-------|
| | | |

---

## Leaving For Next Session

### Priority for next session:
[What should the next agent focus on first]

### Active work in progress:
- [Project/task and its state]
- [Project/task and its state]

### Context needed:
[Anything the next agent needs to know that isn't obvious from files]

---

## Memory Updates

- [ ] Learnings indexed in memory/learnings/
- [ ] Failures indexed in memory/failures/
- [ ] CURRENT_STATE.md updated
- [ ] Index rebuilt (`python scripts/index_memory.py`)

---

## Notes

[Any other observations, ideas, or context]
