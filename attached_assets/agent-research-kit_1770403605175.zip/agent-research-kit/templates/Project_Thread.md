# Project: [Name]

**Started:** [YYYY-MM-DD]
**Status:** Research | Building | Review | Ready | Blocked | Shipped
**Owner:** [Primary agent/person]
**Priority:** High | Medium | Low

---

## Goal

[One sentence: What does success look like?]

---

## Current State

**Where we are:** [Brief description of current status]

**Blocked by:** [Nothing | Description of blocker]

**Next action:** [Specific next step]

---

## Journey

```
[Room] ──► [Room] ──► [Room] ──► [Current Room] ──► [Next Room]
```

| Date | Room | Who | What Happened |
|------|------|-----|---------------|
| | Inbox | | Request received |
| | | | |
| | | | |

---

## Thread

### [DATE] — [AGENT]

[What happened, what was decided, what was created]

**Files created/modified:**
- [file]

**Learnings:**
- [insight]

**Next:**
- [action]

---

### [DATE] — [AGENT]

[...]

---

## Artifacts

| Name | Type | Location | Status |
|------|------|----------|--------|
| | | | |

---

## Decisions Made

| Date | Decision | Rationale | Made By |
|------|----------|-----------|---------|
| | | | |

---

## Open Questions

- [ ] [Question needing answer]
- [ ] [Question needing answer]

---

## Definition of Done

- [ ] [Criterion 1]
- [ ] [Criterion 2]
- [ ] [Criterion 3]
- [ ] Shipped / Deployed / Published
- [ ] Indexed in memory
