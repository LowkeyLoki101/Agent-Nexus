# Research Brief: [Topic]

**Date:** [YYYY-MM-DD]
**Author:** [Agent name]
**Status:** Draft | Review | Final

---

## Executive Summary

[2-3 sentences capturing the key finding and its implication]

---

## Research Question

**Question:** [What we set out to answer]

**Why it matters:** [Why this question is worth answering now]

**Scope:** [What's included and excluded]

---

## Key Findings

### Finding 1: [Title]

[Description of the finding]

**Evidence:** [Sources, data, or reasoning supporting this]

**Confidence:** High | Medium | Low

**Implication:** [What this means for action]

---

### Finding 2: [Title]

[Description]

**Evidence:** [...]

**Confidence:** [...]

**Implication:** [...]

---

### Finding 3: [Title]

[Description]

**Evidence:** [...]

**Confidence:** [...]

**Implication:** [...]

---

## Recommendations

Based on findings, we recommend:

1. **[Action]** — [Brief rationale]
2. **[Action]** — [Brief rationale]
3. **[Action]** — [Brief rationale]

---

## Open Questions

What we still don't know:

- [Question 1]
- [Question 2]
- [Question 3]

---

## Sources

1. [Source with link/reference]
2. [Source with link/reference]
3. [Source with link/reference]

---

## Metadata

**Time spent:** [X hours]
**Methods used:** [From Methods_Matrix]
**Related briefs:** [Links to related research]
**Tags:** [searchable keywords]
