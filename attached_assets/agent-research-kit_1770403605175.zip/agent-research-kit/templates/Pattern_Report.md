# Pattern Report: [Dataset/Topic]

**Date:** [YYYY-MM-DD]
**Author:** [Agent name]
**Status:** Draft | Review | Final

---

## Dataset

**Name:** [Dataset identifier]
**Type:** Text | Tabular | Time Series | Logs | Images | Graph
**Source:** [Where data came from]
**Size:** [# records/documents/files]
**Time range:** [Start - End, if applicable]

---

## Data Profile

| Metric | Value |
|--------|-------|
| Total records | |
| Key fields | |
| Missing data % | |
| Quality issues | |

---

## Methods Applied

### Method 1: [Name]

**From Methods_Matrix:** [Reference]

**Parameters:**
```
[Settings used]
```

**Raw Output:**
```
[Results]
```

**Interpretation:** [What this means]

---

### Method 2: [Name]

**From Methods_Matrix:** [Reference]

**Parameters:**
```
[Settings used]
```

**Raw Output:**
```
[Results]
```

**Interpretation:** [What this means]

---

## Patterns Discovered

### Pattern 1: [Name/Description]

**Signal strength:** Strong | Moderate | Weak
**Confidence:** High | Medium | Low
**Stability:** Consistent | Variable | Unstable

**Evidence:**
[Data/output supporting this pattern]

**Meaning:**
[Plain language explanation]

**Action:**
[What to do with this insight]

---

### Pattern 2: [Name/Description]

**Signal strength:** [...]
**Confidence:** [...]
**Stability:** [...]

**Evidence:** [...]

**Meaning:** [...]

**Action:** [...]

---

## Quality Assessment

| Pattern | Signal (1-5) | Stability (1-5) | Actionability (1-5) |
|---------|--------------|-----------------|---------------------|
| Pattern 1 | | | |
| Pattern 2 | | | |

**False positives identified:** [List any patterns that seemed real but weren't]

**Edge cases:** [Patterns that only apply in certain conditions]

---

## Synthesis

**Top insight:** [Single most important finding]

**Recommended actions:**
1. [Action]
2. [Action]
3. [Action]

**Further research needed:**
- [Question]
- [Question]

---

## Application

**Has this been applied?** Yes | No | Partially

**If applied:**
- Where: [What system/process]
- Result: [What happened]
- Learning: [What we learned from application]

---

## Metadata

**Time spent:** [X hours]
**Methods from matrix:** [List]
**Data still available:** Yes | No | Archived
**Tags:** [searchable keywords]
